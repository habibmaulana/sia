<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Nilai_kkm extends CI_Controller {

	public function index()
	{
		$this->load->model('model_kkm');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/nilai_kkm/tampil_datanilaikkm';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'Nilai KKM';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"'; 
		$isi['data']		= $this->model_kkm->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/nilai_kkm/form_tambahnilaikkm';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'tambah Nilai KKM';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';
		$isi['id_kkm'] = '';
		$isi['id_mapel'] 	= '';
		$isi['nilai_kkm'] 	= '';
		$isi['semester'] 	= '';
		$isi['id_tahunpelajaran'] 	= '';

		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/nilai_kkm/form_editnilaikkm';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'edit Nilai KKM';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';

		$key = $this->uri->segment(3);

		$this->load->model('model_kkm');
		$query = $this->model_kkm->get($key);
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_kkm'] 	= $row->id_kkm;
				$isi['id_mapel'] 	= $row->id_mapel;
				$isi['nama_mapel'] 	= $row->nama_mapel;
				$isi['nilai_kkm'] 	= $row->nilai_kkm;
				$isi['semester'] 	= $row->semester;
				$isi['tahun_pelajaran'] 	= $row->tahun_pelajaran;
				$isi['id_tahunpelajaran'] 	= $row->id_tahunpelajaran;
			}
		}
		else
		{
			$isi['id_kkm'] 	= '';
			$isi['nama_mapel'] 	= '';
			$isi['nilai'] 	= '';
			$isi['semester'] 	= '';
			$isi['id_tahunpelajaran'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('id_kkm');
		$data['id_kkm']	= $this->input->post('id_kkm');
		$data['id_mapel']	= $this->input->post('id_mapel');
		$data['nilai_kkm']	= $this->input->post('nilai_kkm');
		$data['semester']	= $this->input->post('semester');
		$data['id_tahunpelajaran']	= $this->input->post('id_tahunpelajaran');

		$this->load->model('model_kkm');
		$query = $this->model_kkm->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_kkm->getupdate($key,$data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
			redirect(base_url().'nilai_kkm');
		}
		else
		{
			$this->model_kkm->getinsert($data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Simpan</div>');
			redirect(base_url().'nilai_kkm/tambah');
		}
		
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_kkm');
		$key = $this->uri->segment(3);
		$this->db->where('id_kkm',$key);
		$query = $this->db->get('nilai_kkm');
		if($query->num_rows()>0)
		{
			$this->model_kkm->getdelete($key);
			$this->model_kkm->delete($key);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Berhasil Di Hapus</div>');
		}
		redirect(base_url().'nilai_kkm');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 