<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cetak extends CI_Controller {

	public function index()
	{
		$this->load->model('model_guru');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/cetak/tampil_dataguru';
		$isi['judul']		= 'Cetak';
		$isi['sub_judul']	= 'Guru';
		$isi['icon']		= 'class="ace-icon fa fa-print home-icon"';
		$isi['data']		= $this->model_guru->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

public function siswa()
  {
   
    $this->model_squrity->getsqurity();
    $isi['content']   = 'admin/cetak/tampil_datasiswa';
    $isi['judul']   = 'Cetak';
    $isi['sub_judul'] = 'Siswa';
    $isi['icon']    = 'class="ace-icon fa fa-print home-icon"';
    $isi['data']    = $this->db->get('siswa');
    $this->load->view('admin/tampilan_home',$isi);
  }  

public function kelas()
  {
    $this->model_squrity->getsqurity();
    $this->load->model('model_kelassiswa');
    $isi['content']       = 'admin/cetak/tampil_datakelassiswa';
    $isi['judul']       = 'Cetak';
    $isi['sub_judul']     = 'Data Kelas Siswa';
    $isi['icon']        = 'class="ace-icon fa fa-print home-icon"';
    $isi['id_kelassiswa']     = '';
    $isi['id_kelas']      = '';
    $isi['id_tahunpelajaran']   = '';
    $isi['nip']         = '';
    $isi['nis']         = ''; 
    $isi['data']        = $this->model_kelassiswa->data();
    //$isi['tahun_pelajaran']   = $this->model_kelassiswa->data();
    $this->load->view('admin/tampilan_home',$isi);
  }

	public function excelguru()
	{
		$this->model_squrity->getsqurity();
		$this->load->library('Excel_generator');
		$sql = "SELECT
              guru.*, jabatan.jabatan,
              mapel.nama_mapel
            FROM
              guru
            LEFT JOIN jabatan ON guru.id_jabatan = jabatan.id_jabatan
            LEFT JOIN mapel ON guru.id_mapel = mapel.id_mapel";

		$query = $this->db->query($sql);
		
		
        $this->excel_generator->set_query($query);
        $this->excel_generator->set_header(array('Nama', 'NUPTK/Peg. Id', 'NRG', 'NIP', 'Tempat Lahir', 'Tanggal Lahir', 'Pangk/Gol', 'Jabatan', 'L/P', 'PNS/GTY/GTT', 'TMT', 'Thn.', 'Bln', 'Jenjang', 'Jurusan', 'Tugas Mengajar', 'Jml. Jam Mengajar (jam/siswa)', 'Sudah (Tahun)', 'No. Sertifikasi Pendidik', 'Mapel Sertifikasi', 'Desa', 'Kelurahan', 'Kecamatan', 'Telp. Rumah/HP', 'Pensiun (Tahun)', 'NPWP', 'Ket'));
        $this->excel_generator->set_column(array('nama', 'nuptk', 'nrg', 'nip', 'tempat_lahir', 'tgl_lahir', 'pangkat', 'jabatan', 'jenis_kelamin', 'status_guru', 'tmt', 'masa_tahun', 'masa_bulan', 'jenjang', 'jurusan', 'nama_mapel', 'jml_jam_mengajar', 'tahun_sertifikasi', 'no_sertifikasi', 'mapel_sertifikasi', 'desa', 'kelurahan', 'kecamatan', 'no_telp_rmh', 'pensiun', 'npwp', 'ket'));
        $this->excel_generator->set_width(array(28, 21, 15, 25, 12, 14, 19, 10, 5, 7, 11, 6, 6, 6, 15, 15, 12, 10, 15, 12, 10, 18, 18, 22, 8, 22, 26));
        $this->excel_generator->exportTo2007();
	}

	public function pdf()
	{
       $this->model_squrity->getsqurity();
		   $this->load->library('cfpdf');
       $id        =  $this->uri->segment(3);
       $profileSQL=    "SELECT
                         guru.*, jabatan.jabatan,
                         mapel.nama_mapel
                       FROM
                         guru
                       LEFT JOIN jabatan ON guru.id_jabatan = jabatan.id_jabatan
                       LEFT JOIN mapel ON guru.id_mapel = mapel.id_mapel";
       $profile   = $this->db->query($profileSQL);
       $pdf = new FPDF('L','mm','A4');
       $pdf->AddPage();
       $pdf->SetFont('TIMES','B',15);
       $pdf->Cell(40, 5, 'DAFTAR NAMA GURU', 0, 1);
       $pdf->SetFont('TIMES','b',10);
       $pdf->Cell(20,3,'',0,1);       
       $pdf->Cell(7, 5, 'NO', 1, 0, 'C');
       $pdf->Cell(60, 5, 'NAMA', 1, 0, 'C');
       $pdf->Cell(37, 5, 'NIP', 1, 0, 'C');
       $pdf->Cell(30, 5, 'Tempat Lahir', 1, 0, 'C');
       $pdf->Cell(30, 5, 'Tanggal Lahir', 1, 0, 'C');
       $pdf->Cell(38, 5, 'Pangkat/Gol', 1, 0, 'C');
       $pdf->Cell(34, 5, 'Jabatan', 1, 0, 'C');
       $pdf->Cell(25, 5, 'Jenis Kelamin', 1, 1, 'C');   
       $pdf->SetFont('times','',10);
       $i=1;    
       foreach ($profile->result() as $r)
       {
            $pdf->Cell(7, 5, $i, 1, 0);
            $pdf->Cell(60, 5, strtoupper($r->nama), 1, 0);
            $pdf->Cell(37, 5, strtoupper($r->nip), 1, 0);
            $pdf->Cell(30, 5, strtoupper($r->tempat_lahir), 1, 0);
            $pdf->Cell(30, 5, strtoupper($r->tgl_lahir), 1, 0);
            $pdf->Cell(38, 5, strtoupper($r->pangkat), 1, 0);
            $pdf->Cell(34, 5, strtoupper($r->jabatan), 1, 0);
            $pdf->Cell(25, 5, strtoupper($r->jenis_kelamin), 1, 1);           
            $i++;
       }
      $pdf->ln();
      $pdf->Cell(249.5, 5, 'Semarang, ' .  tgl_indo(waktu()), 0, 1, 'R');
      $pdf->Cell(257, 5, 'Kepala SMP Negeri 40 Semarang', 0, 1, 'R');
      $pdf->ln();
      $pdf->ln();
      $pdf->Cell(240.6, 5, 'Dra. Rani Ernaningsih', 0, 1, 'R');
      $pdf->Cell(250.8, 5, 'NIP. 19640717 198903 2 013', 0, 1, 'R');
      $pdf->Output();
    }

public function datakelas()
  {
       $this->model_squrity->getsqurity();
       $this->load->library('cfpdf');
       $id        =  $this->uri->segment(3);
       $profileSQL=    "SELECT
                         siswa.nama AS siswa,
                         siswa.nis,
                         siswa.agama,
                         siswa.nisn,
                         siswa.jenis_kelamin,
                         kelas.kelas AS kelas,
                         guru.nama AS guru,
                         tahun_pelajaran.tahun_pelajaran,
                         kelas_siswa.id_kelas
                       FROM
                         kelas_siswa
                       RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
                       LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
                       LEFT JOIN guru ON kelas.nip = guru.nip
                       INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
                       WHERE
                         kelas.id_kelas=$id";
       $profile   = $this->db->query($profileSQL)->row_array();
       $query = $this->db->query($profileSQL)->result();
       $pdf = new FPDF('P','mm','A4');
       $pdf->AddPage();
       $pdf->SetFont('TIMES','B',10);
       $pdf->Image(base_url().'/assets/avatars/kota-semarang.jpg', 20, 10, 15);
       $pdf->Cell(0, 5, 'PEMERINTAH KOTA SEMARANG', 0, 1, 'C');
       $pdf->Cell(0, 5, 'DINAS PENDIDIKAN', 0, 1, 'C');
       $pdf->Cell(0, 5, 'SMP NEGERI 40 ', 0, 1, 'C');
       $pdf->Cell(0, 5, 'Jl. Suyudono 130 Telp. (024) 3553930 - 70772937 Semarang 50245', 0, 1, 'C');
       $pdf->line(13, 31, 200, 31);
       $pdf->line(13, 32, 200, 32);
       $pdf->ln();
       $pdf->SetFont('TIMES','B',11);
       $pdf->Cell(0, 5, 'DATA SISWA', 0, 1, 'C');
       $pdf->Cell(0, 5, 'SMP NEGERI 40 SEMARANG', 0, 1, 'C');
       $pdf->Cell(0, 5, 'Tahun Pelajaran '. $profile['tahun_pelajaran'], 0, 1, 'C');
       $pdf->ln();
       $pdf->SetFont('TIMES','B',11);
       $pdf->Cell(30,5,'Kelas',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($profile['kelas']),0,1);
       $pdf->Cell(30,5,'Wali Kelas',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($profile['guru']),0,1);
       $pdf->Cell(30,5,'Tahun Pelajaran',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($profile['tahun_pelajaran']),0,1);
       $pdf->SetFont('TIMES','b',10);
       $pdf->ln();
       $pdf->Cell(48, 5, 'NOMOR', 1, 0, 'C'); 
       $pdf->Cell(80, 5, '','LTR', 0,'C');
       $pdf->Cell(20, 5, '', 'LTR', 0, 'C');
       $pdf->Cell(40, 5, '', 'LTR', 1, 'C');
       $pdf->Cell(9, 7, 'Urt', 1, 0, 'C');
       $pdf->Cell(22, 7, 'NISN', 1, 0, 'C');
       $pdf->Cell(17, 7, 'INDUK', 1, 0, 'C');
       $pdf->setXY(58, 76);
       $pdf->Cell(80, 10, 'NAMA SISWA','LR', 0,'C', 0);
       $pdf->Cell(20, 10, 'AGAMA','LR', 0,'C', 0);
       $pdf->Cell(40, 10, 'JENIS KELAMIN', 'LR', 1, 'C', 0);
       $pdf->Cell(9, 6, '', 'LR', 0, 'C');
       $pdf->Cell(22, 6, '', 'LR', 0, 'C');
       $pdf->Cell(17, 6, '', 'LR', 0, 'C');
       $pdf->Cell(80, 6, '','LR', 0,'C', 0);
       $pdf->Cell(20, 6, '','LR', 0,'C', 0);
       $pdf->Cell(40, 6, '', 'LR', 1, 'C', 0);
       $pdf->setY(87);
       $pdf->SetFont('times','',10);
       $i=1;
       foreach ($query as $r)
       {
            $pdf->Cell(9, 5, $i, 1, 0, 'C');
            $pdf->Cell(22, 5, strtoupper($r->nisn), 1, 0, 'C');
            $pdf->Cell(17, 5, strtoupper($r->nis), 1, 0, 'C');
            $pdf->Cell(80, 5, strtoupper($r->siswa), 1, 0);
            $pdf->Cell(20, 5, strtoupper($r->agama), 1, 0,'C');
            $pdf->Cell(40, 5, strtoupper($r->jenis_kelamin), 1, 1);
            $i++;
       }
      $pdf->ln(); 
      $pdf->Cell(179.1, 5, 'Semarang, '.  tgl_indo(waktu()), 0, 1, 'R');
      $pdf->Cell(187.6, 5, 'Kepala SMP Negeri 40 Semarang ', 0, 1, 'R');
      $pdf->ln(); 
      $pdf->ln(); 
      $pdf->Cell(170.5, 5, 'Dra. Rani Ernaningsih', 0, 1, 'R');
      $pdf->Cell(180.7, 5, 'NIP. 19640717 198903 2 013', 0, 1, 'R');
      $pdf->Output();
    }

public function nilai()
  {
    $this->model_squrity->getsqurity();
    $this->load->library('cfpdf');
    $nis                =  $this->uri->segment(3);
    $id_tahunpelajaran  =  $this->uri->segment(4);
    $id_kelas           =  $this->uri->segment(5);
    $semester           =  $this->uri->segment(6);
    $profileSQL =    "SELECT
                        nilai_akhirsiswa.*,
                        tahun_pelajaran.tahun_pelajaran,
                        siswa.nama,
                        siswa.nis,
                        kelas.kelas,
                        nilai_kkm.nilai_kkm,
                        nilai_kkm.semester,
                        mapel.nama_mapel,
                        kelas_siswa.id_kelas
                      FROM
                        nilai_akhirsiswa
                      INNER JOIN siswa ON nilai_akhirsiswa.nis = siswa.nis
                      INNER JOIN kelas_siswa ON nilai_akhirsiswa.id_kelassiswa = kelas_siswa.id_kelassiswa
                      AND kelas_siswa.nis = siswa.nis
                      INNER JOIN kelas ON kelas_siswa.id_kelas = kelas.id_kelas
                      INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
                      INNER JOIN nilai_kkm ON nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
                      AND nilai_kkm.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
                      LEFT JOIN mapel ON nilai_kkm.id_mapel = mapel.id_mapel
                      WHERE
                        siswa.nis = $nis
                      AND nilai_kkm.semester = '$semester'
                      AND kelas_siswa.id_kelas = $id_kelas
                      AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran 
                      ORDER BY mapel.id_mapel ASC ";
    $profile   = $this->db->query($profileSQL)->row_array();
    $query = $this->db->query($profileSQL)->result();
    $pdf = new FPDF('P','mm','A4');
    $pdf->AddPage();
    $pdf->SetFont('TIMES','B',10);
    $pdf->Cell(20,5,'Nama Sekolah',0,0);
    $pdf->Cell(95,5,'            : SMP NEGERI 40 SEMARANG',0,0);
    $pdf->Cell(20,5,'Kelas',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($profile['kelas']),0,1);
    $pdf->Cell(20,5,'Alamat',0,0);
    $pdf->Cell(95,5,'            : Jl. Suyudono 130 Semarang',0,0);
    $pdf->Cell(20,5,'Semester',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($profile['semester']),0,1);
    $pdf->Cell(20,5,'Nama',0,0);
    $pdf->Cell(95,5,'            : '.  ucwords($profile['nama']),0,0);
    $pdf->Cell(20,5,'Tahun Pelajaran',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($profile['tahun_pelajaran']),0,1);
    $pdf->Cell(20,5,'Nomor Induk',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($profile['nis']),0,1);
    $pdf->SetFont('TIMES','b',10); 
    $pdf->ln();
    $pdf->Cell(9, 6, '','LTR', 0,'C');
    $pdf->Cell(55, 6, '','LTR', 0,'C');
    $pdf->Cell(15, 6, '', 'LTR', 0, 'C');
    $pdf->Cell(45, 6, 'Nilai', 1, 0, 'C'); 
    $pdf->Cell(65, 6, '', 'LTR', 1, 'C');
    $pdf->setY(38);    
    $pdf->Cell(9, 6, 'No', 'LR', 0, 'C');
    $pdf->Cell(55, 6, 'Mata Pelajaran', 'LR', 0, 'C');
    $pdf->Cell(15, 6, 'KKM', 'LR', 0, 'C');
    $pdf->setXY(89, 41);
    $pdf->Cell(15, 6, 'Angka', 'LR', 0,'C');
    $pdf->Cell(30, 6, 'Huruf', 'LR', 0,'C');
    $pdf->setXY(134, 38);
    $pdf->Cell(65, 6, 'Catatan Guru', 'LR', 1, 'C');  
    $pdf->Cell(9, 7, '', 'LR', 0, 'C');
    $pdf->Cell(55, 7, '', 'LR', 0, 'C');
    $pdf->Cell(15, 7, '', 'LR', 0, 'C');
    $pdf->Cell(15, 7, '', 'LR', 0,'C');
    $pdf->Cell(30, 7, '', 'LR', 0,'C');
    $pdf->Cell(65, 7, '', 'LR', 1, 'C'); 
    $pdf->setY(48);
    $pdf->SetFont('times','',10); 
    $no = 1; 
    foreach ($query as $r) {
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        $pdf->cell(9, 14, $no++, 1, 0, 'C');
        $pdf->Rect($x,$y,64,14);
        $pdf->MultiCell(55, 7, ucwords($r->nama_mapel), 0, 'L');
        $pdf->SetXY($x+64,$y);
        $pdf->Cell(15, 14, strtoupper($r->nilai_kkm), 1, 0, 'C');           
        $pdf->Cell(15, 14, strtoupper($r->nilai_akhir), 1, 0, 'C');
        $pdf->Rect($x,$y,124,14);
        $pdf->MultiCell(30,7, ucwords($r->angka),0,'L');
        $pdf->SetXY($x+124,$y);
        $pdf->Rect($x,$y,189,14);
        $pdf->MultiCell(65,5,ucwords($r->catatan_guru),0,'L');
        $pdf->SetXY($x+189,$y);
        $pdf->Cell(65, 14, '', 0, 1, 'L');      
    }
       $pdf->Output();
    }

	public function nilai_kelas()
  {
    $this->model_squrity->getsqurity();
    $this->load->library('cfpdf');
    $nip                =  $this->session->userdata('nip');
    $id_tahunpelajaran  =  $this->uri->segment(4);
    $id_kelas           =  $this->uri->segment(3);
    $semester           =  $this->uri->segment(5);
    $khs        =   "SELECT
                      nilai_kkm.*,
                      guru.nip,
                      guru.nama,
                      mapel.nama_mapel,
                      tahun_pelajaran.tahun_pelajaran
                    FROM
                      nilai_kkm,
                      guru, 
                      mapel,
                      tahun_pelajaran
                    WHERE
                      nilai_kkm.id_mapel = guru.id_mapel 
                    AND nilai_kkm.id_mapel = mapel.id_mapel
                    AND nilai_kkm.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
                    AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran
                    AND nilai_kkm.semester = '$semester'
                    AND guru.nip = $nip";
    $c          =  $this->db->query($khs)->row_array();
   
    $profileSQL =    "SELECT
                          siswa.nisn,
                          siswa.nama,
                          siswa.nis,
                          nilai_kkm.id_mapel,
                          nilai_kkm.nilai_kkm,
                          nilai_kkm.semester,
                          nilai_kkm.id_tahunpelajaran,
                          nilai_akhirsiswa.nilai_harian1,
                          nilai_akhirsiswa.nilai_harian2,
                          nilai_akhirsiswa.nilai_harian3,
                          nilai_akhirsiswa.nilai_harian4,
                          nilai_akhirsiswa.nilai_rataharian,
                          nilai_akhirsiswa.nilai_uts,
                          nilai_akhirsiswa.nilai_uas,
                          nilai_akhirsiswa.nilai_akhir,
                          nilai_akhirsiswa.angka,
                          nilai_akhirsiswa.catatan_guru,
                          kelas.kelas
                        FROM
                          nilai_akhirsiswa,
                          kelas,
                          nilai_kkm,
                          kelas_siswa,
                          siswa
                        WHERE
                         nilai_akhirsiswa.id_kelassiswa = kelas_siswa.id_kelassiswa
                        AND kelas_siswa.id_kelas = kelas.id_kelas
                        AND nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
                        AND kelas_siswa.nis = siswa.nis
                        AND kelas_siswa.id_kelas = $id_kelas
                        AND nilai_akhirsiswa.id_kkm = '$c[id_kkm]'";
    $a          =  $this->db->query($profileSQL)->result();
    $sq =    "SELECT kelas.* FROM kelas_siswa, kelas
                        WHERE
                         kelas_siswa.id_kelas=kelas.id_kelas
                        AND kelas.id_kelas = $id_kelas
                        ";



    $b  =  $this->db->query($sq)->row_array();
    $pdf = new FPDF('L','mm','A4');
    $pdf->AddPage();
    $pdf->SetFont('TIMES','B',10);
    $pdf->Image(base_url().'/assets/avatars/kota-semarang.jpg', 60, 10, 15);
    $pdf->Cell(0, 5, 'PEMERINTAH KOTA SEMARANG', 0, 1, 'C');
    $pdf->Cell(0, 5, 'DINAS PENDIDIKAN', 0, 1, 'C');
    $pdf->Cell(0, 5, 'SMP NEGERI 40 ', 0, 1, 'C');
    $pdf->Cell(0, 5, 'Jl. Suyudono 130 Telp. (024) 3553930 - 70772937 Semarang 50245', 0, 1, 'C');
    $pdf->line(13, 31, 283, 31);
    $pdf->ln();
    $pdf->SetFont('TIMES','B',11);
    $pdf->Cell(0, 5, 'DAFTAR NILAI', 0, 1, 'C');
    $pdf->ln();
    $pdf->SetFont('TIMES','B',11);
    $pdf->Cell(30,5,'Mata Pelajaran',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($c['nama_mapel']),0,1);
    $pdf->Cell(30,5,'KKM',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($c['nilai_kkm']),0,1);
    $pdf->Cell(30,5,'Kelas',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($b['kelas']),0,1);
    $pdf->Cell(30,5,'Semester',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($c['semester']),0,1);
    $pdf->Cell(30,5,'Tahun Pelajaran',0,0);
    $pdf->Cell(20,5,'            : '.  ucwords($c['tahun_pelajaran']),0,1);
    $pdf->SetFont('TIMES','b',10); 
    $pdf->ln();
    $pdf->Cell(48, 5, 'NOMOR', 1, 0, 'C'); 
    $pdf->Cell(80, 5, '','LTR', 0,'C');
    $pdf->Cell(25, 5, '', 'LTR', 0, 'C');
    $pdf->Cell(25, 5, '','LTR', 0,'C');
    $pdf->Cell(25, 5, '', 'LTR', 0, 'C');
    $pdf->Cell(25, 5, '','LTR', 0,'C');
    $pdf->Cell(15, 5, '', 'LTR', 0, 'C');
    $pdf->Cell(12, 5, '','LTR', 0,'C');
    $pdf->Cell(12, 5, '', 'LTR', 0, 'C');
    $pdf->Cell(10, 5, '', 'LTR', 1, 'C');
    $pdf->Cell(9, 7, 'Urt', 1, 0, 'C');
    $pdf->Cell(22, 7, 'NISN', 1, 0, 'C');
    $pdf->Cell(17, 7, 'INDUK', 1, 0, 'C');
    $pdf->setXY(58, 77);
    $pdf->Cell(80, 7, 'NAMA SISWA', 'LR', 0,'C');
    $pdf->Cell(25, 7, 'Nilai Harian 1', 'LR', 0, 'C');
    $pdf->Cell(25, 7, 'Nilai Harian 2', 'LR', 0, 'C');
    $pdf->Cell(25, 7, 'Nilai Harian 3', 'LR', 0,'C');
    $pdf->Cell(25, 7, 'Nilai Harian 4', 'LR', 0,'C');
    $pdf->Cell(15, 7, 'RT2 NH', 'LR', 0, 'C');
    $pdf->Cell(12, 7, 'UTS', 'LR', 0, 'C');
    $pdf->Cell(12, 7, 'UAS', 'LR', 0,'C');
    $pdf->Cell(10, 7, 'NA', 'LR', 1,'C');    
    $pdf->Cell(9, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(22, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(17, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(80, 10, '', 'LBR', 0,'C');
    $pdf->Cell(25, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(25, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(25, 10, '', 'LBR', 0,'C');
    $pdf->Cell(25, 10, '', 'LBR', 0,'C');
    $pdf->Cell(15, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(12, 10, '', 'LBR', 0, 'C');
    $pdf->Cell(12, 10, '', 'LBR', 0,'C');
    $pdf->Cell(10, 10, '', 'LBR', 1,'C');  
    $pdf->setY(87);
    $pdf->SetFont('times','',10);
    $i=1; 
    foreach ($a as $r)
       {
          $pdf->Cell(9, 7, $i, 1, 0, 'C');
          $pdf->Cell(22, 7, ucwords($r->nisn), 1, 0, 'C');
          $pdf->Cell(17, 7, ucwords($r->nis), 1, 0, 'C');
          $pdf->Cell(80, 7, ucwords($r->nama), 1, 0);
          $pdf->Cell(25, 7, ucwords($r->nilai_harian1), 1, 0, 'C');
          $pdf->Cell(25, 7, ucwords($r->nilai_harian2), 1, 0, 'C');
          $pdf->Cell(25, 7, ucwords($r->nilai_harian3), 1, 0,'C');
          $pdf->Cell(25, 7, ucwords($r->nilai_harian4), 1, 0,'C');
          $pdf->Cell(15, 7, ucwords($r->nilai_rataharian), 1, 0, 'C');
          $pdf->Cell(12, 7, ucwords($r->nilai_uts), 1, 0, 'C');
          $pdf->Cell(12, 7, ucwords($r->nilai_uas), 1, 0,'C');
          $pdf->Cell(10, 7, ucwords($r->nilai_akhir), 1, 1,'C');  
          $i++;
       }
    $pdf->ln();
    $pdf->Cell(20, 5, '', 0, 0);
    $pdf->Cell(200, 5, 'Mengetahui, ', 0, 0); 
    $pdf->Cell(0, 5, 'Semarang, '.  tgl_indo(waktu()), 0, 1);
    $pdf->Cell(20, 5, '', 0, 0);
    $pdf->Cell(200, 5, 'Kepala SMP Negeri 40 Semarang', 0, 0);
    $pdf->Cell(0, 5, 'Guru Mata Pelajaran', 0, 1);
    $pdf->ln(); 
    $pdf->ln(); 
    $pdf->Cell(20, 5, '', 0, 0);
    $pdf->Cell(200, 5, 'Dra. Rani Ernaningsih', 0, 0);
    $pdf->Cell(0, 5, $c['nama'], 0, 1);
    $pdf->Cell(20, 5, '', 0, 0);
    $pdf->Cell(200, 5, 'NIP. 19640717 198903 2 013', 0, 0);
    $pdf->Cell(0, 5, 'NIP. '.$c['nip'], 0, 1);
    $pdf->Output();
  }

	public function datasiswa()
	{
       $this->model_squrity->getsqurity();
		   $this->load->library('cfpdf');
       $nis  =   $this->uri->segment(3);
       $sqlMHS     =   "SELECT
                          siswa.*,
                          kelas.kelas
                        FROM
                          siswa
                        LEFT JOIN kelas ON siswa.id_kelas = kelas.id_kelas
                        WHERE
                          siswa.nis = $nis";
       $m          =  $this->db->query($sqlMHS)->row_array();
       $pdf = new FPDF('p','mm','A5');
       $pdf->AddPage();     
       $pdf->SetFont('TIMES','B',9);
       $pdf->Cell(130, 5, 'KETERANGAN TENTANG DIRI SISWA', 0, 1, 'C');
       $pdf->SetFont('TIMES','',8);
       $pdf->Cell(20,3,'',0,1);
       $pdf->Cell(30,5,'1.   Nama Siswa (Lengkap)',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['nama']),0,1);
       $pdf->Cell(30,5,'2.   Nomor Induk',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['nis']),0,1);
       $pdf->Cell(30,5,'3.   Tempat dan Tanggal Lahir',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['tempat_lahir']).', '. tgl_indo($m['tgl_lahir']),0,1);
       $pdf->Cell(30,5,'4.   Jenis Kelamin ',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['jenis_kelamin']),0,1);
       $pdf->Cell(30,5,'5.   Agama',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['agama']),0,1);
       $pdf->Cell(30,5,'6.   Status dalam Keluarga',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['status_dalam_keluarga']),0,1);
       $pdf->Cell(30,5,'7.   Anak Ke',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['anak_ke']),0,1);
       $pdf->Cell(30,5,'8.   Alamat Siswa',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['alamat_siswa']),0,1);
       $pdf->Cell(30,5,'',0,1);
       $pdf->Cell(30,5,'      Telepon ',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['no_telp_siswa']),0,1);
       $pdf->Cell(30,5,'9.   Sekolah Asal',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['sekolah_asal']),0,1);
       $pdf->Cell(30,5,'10. Diterima di Sekolah ini',0,1);
       $pdf->Cell(30,5,'      Di Kelas',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['kelas']),0,1);
       $pdf->Cell(30,5,'      Pada Tanggal',0,0);
       $pdf->Cell(20,5,'            : '.  tgl_indo($m['pada_tanggal']),0,1);
       $pdf->Cell(30,5,'11. Nama Orang Tua',0,1);
       $pdf->Cell(30,5,'      a. Ayah',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['nama_ayah']),0,1);
       $pdf->Cell(30,5,'      b. Ibu',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['nama_ibu']),0,1);
       $pdf->Cell(30,5,'12. Alamat Orang Tua',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords ($m['alamat_ortu']),0,1);
       $pdf->Cell(30,5,'',0,1);
       $pdf->Cell(30,5,'      Telepon ',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['no_telp_ortu']),0,1);
       $pdf->Cell(30,5,'13. Pekerjaan orang Tua',0,1);
       $pdf->Cell(30,5,'      a. Ayah',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['pekerjaan_ayah']),0,1);
       $pdf->Cell(30,5,'      b. Ibu',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['pekerjaan_ibu']),0,1);
       $pdf->Cell(30,5,'14. Nama Wali',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['nama_wali']),0,1);
       $pdf->Cell(30,5,'15. Alamat Wali',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['alamat_wali']),0,1);
       $pdf->Cell(30,5,'',0,1);
       $pdf->Cell(30,5,'      Telepon ',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['no_telp_wali']),0,1);
       $pdf->Cell(30,5,'16. Pekerjaan Wali ',0,0);
       $pdf->Cell(20,5,'            : '.  ucwords($m['pekerjaan_wali']),0,1);
       $pdf->Cell(0, 1, '', 0, 1);
       $pdf->Image(base_url().'/assets/avatars/pas-foto.jpg', 62, 160, 20);
       $pdf->Cell(84, 15, '', 0, 0);
       $pdf->Cell(25, 5, 'Semarang, '. tgl_indo(waktu()), 0, 1);
       $pdf->Cell(90, 5, '', 0, 0);
       $pdf->Cell(25, 5, 'Kepala Sekolah', 0, 1);
       $pdf->Cell(95, 10, '', 0, 0);
       $pdf->Cell(25, 10, '', 0, 1);
       $pdf->Cell(84, 5, '', 0, 0);
       $pdf->Cell(20, 5, '..............................................', 0, 1);
       $pdf->line(95, 183, 128, 183);
       $pdf->Cell(84, 5, '', 0, 0);
       $pdf->Cell(20, 5, 'NIP. .....................................', 0, 1);
       $pdf->Output();

	}

  public function excelsiswa()
  {
    $this->model_squrity->getsqurity();
    
    $this->load->library('Excel_generator');
    
    $query = $this->db->get('siswa');
    $this->excel_generator->set_query($query);
    $this->excel_generator->set_header(array('NIS', 'NISN', 'Nama Siswa', 'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin', 'Agama', 'Status Dalam Keluarga', 'Anak Ke', 'Alamat Siswa', 'No Telpon Siswa', 'Sekolah Asal', 'Kelas', 'Pada Tanggal', 'Nama Ayah', 'Nama Ibu', 'Alamat Orang Tua', 'No Telpon Orang Tua', 'Pekerjaan Ayah', 'Pekerjaan Ibu', 'Nama Wali', 'Alamat Wali', 'No Telpon Wali', 'Pekerjaan Wali'));   
    $this->excel_generator->set_column(array('nis', 'nisn', 'nama', 'tempat_lahir', 'tgl_lahir', 'jenis_kelamin', 'agama', 'status_dalam_keluarga', 'anak_ke', 'alamat_siswa', 'no_telp_siswa', 'sekolah_asal', 'id_kelassiswa', 'pada_tanggal', 'nama_ayah', 'nama_ibu', 'alamat_ortu', 'no_telp_ortu', 'pekerjaan_ayah', 'pekerjaan_ibu', 'nama_wali', 'alamat_wali', 'no_telp_wali', 'pekerjaan_wali'));
    $this->excel_generator->set_width(array(12, 23, 35, 13, 12, 13, 8, 12, 8, 40, 16, 30, 6, 12, 35, 35, 40, 16, 16, 16, 35, 40, 16, 16));
    $this->excel_generator->exportTo2007();
  }

}