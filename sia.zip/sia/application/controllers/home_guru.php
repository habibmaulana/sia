<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_guru extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'guru/tampilan_content';
		$isi['judul']		= 'home';
		$isi['sub_judul']	= '';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$this->load->view('guru/tampilan_home',$isi);
	}

	public function guru()
	{
		$this->load->model('model_kelassiswa');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'guru/formnilai_akhir';
		$isi['judul']		= 'Nilai Akhir';
		$isi['sub_judul']	= '';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"'; 
		$isi['data']		= $this->model_kelassiswa->data();
		//$isi['data']		= $this->db->get('nilai_akhir');
		$this->load->view('guru/tampilan_home',$isi);
	}

	public function profil()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'guru/tampilan_profil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Data Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$key = $this->session->userdata('nip');
		//$this->load->model('model_guru');
		//$query = $this->model_guru->getdata($key);
		$query = $this->db->query("SELECT
									guru.*,
									mapel.nama_mapel,
									jabatan.jabatan
								FROM
									guru,
									jabatan,
									mapel
								WHERE
									guru.id_jabatan = jabatan.id_jabatan
								AND guru.id_mapel = mapel.id_mapel
								and guru.nip=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->nama_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		} else
		{
			$isi['nip'] 		= '';
				$isi['nama'] 		= '';
				$isi['nuptk'] 		= '';
				$isi['nrg'] 		= '';
				$isi['tempat'] 		= '';
				$isi['tgl'] 		= '';
				$isi['pangkat'] 	= '';
				$isi['jabatan'] 	= '';
				$isi['jenis'] 		= '';
				$isi['status'] 		= '';
				$isi['tmt'] 		= '';
				$isi['tahun'] 		= '';
				$isi['bulan'] 		= '';
				$isi['jenjang'] 	= '';
				$isi['jurusan'] 	= '';
				$isi['mapel'] 		= '';
				$isi['jml'] 		= '';
				$isi['tahunser'] 	= '';
				$isi['noser'] 		= '';
				$isi['mapser'] 		= '';
				$isi['desa'] 		= '';
				$isi['kel'] 		= '';
				$isi['kec'] 		= '';
				$isi['no'] 			= '';
				$isi['pensiun'] 	= '';
				$isi['npwp'] 		= '';
				$isi['ket'] 		= '';
		}
		$this->load->view('guru/tampilan_home',$isi);
	}

	public function edit()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'guru/tampilan_editprofil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Edit Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$key = $this->session->userdata('nip');
		$this->db->where('nip',$key);
		$query = $this->db->get('guru');
		$query = $this->db->query("SELECT
									guru.*,
									jabatan.jabatan
									FROM
									guru ,
									jabatan
									WHERE
									guru.id_jabatan = jabatan.id_jabatan
									 and guru.nip=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['id_jabatan'] 	= $row->id_jabatan;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->id_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		} else
		{
			$isi['nip'] 		= '';
				$isi['nama'] 		= '';
				$isi['nuptk'] 		= '';
				$isi['nrg'] 		= '';
				$isi['tempat'] 		= '';
				$isi['tgl'] 		= '';
				$isi['pangkat'] 	= '';
				$isi['jabatan'] 	= '';
				$isi['jenis'] 		= '';
				$isi['status'] 		= '';
				$isi['tmt'] 		= '';
				$isi['tahun'] 		= '';
				$isi['bulan'] 		= '';
				$isi['jenjang'] 	= '';
				$isi['jurusan'] 	= '';
				$isi['mapel'] 		= '';
				$isi['jml'] 		= '';
				$isi['tahunser'] 	= '';
				$isi['noser'] 		= '';
				$isi['mapser'] 		= '';
				$isi['desa'] 		= '';
				$isi['kel'] 		= '';
				$isi['kec'] 		= '';
				$isi['no'] 			= '';
				$isi['pensiun'] 	= '';
				$isi['npwp'] 		= '';
				$isi['ket'] 		= '';
		}
		$this->load->view('guru/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('nip');
		$data['nip']				= $this->input->post('nip');
		$data['nama']				= $this->input->post('nama');
		$data['nuptk']				= $this->input->post('nuptk');
		$data['nrg']				= $this->input->post('nrg');
		$data['tempat_lahir']		= $this->input->post('tempat');
		$data['tgl_lahir']			= $this->input->post('tgl');
		$data['pangkat']			= $this->input->post('pangkat');
		$data['id_jabatan']			= $this->input->post('id_jabatan');
		$data['jenis_kelamin']		= $this->input->post('jenis');
		$data['status_guru']		= $this->input->post('status');
		$data['tmt']				= $this->input->post('tmt');
		$data['masa_tahun']			= $this->input->post('tahun');
		$data['masa_bulan']			= $this->input->post('bulan');
		$data['jenjang']			= $this->input->post('jenjang');
		$data['jurusan']			= $this->input->post('jurusan');
		$data['id_mapel']			= $this->input->post('mapel');
		$data['jml_jam_mengajar']	= $this->input->post('jml');
		$data['tahun_sertifikasi']	= $this->input->post('tahunser');
		$data['no_sertifikasi']		= $this->input->post('noser');
		$data['mapel_sertifikasi']	= $this->input->post('mapser');
		$data['desa']				= $this->input->post('desa');
		$data['kelurahan']			= $this->input->post('kel');
		$data['kecamatan']			= $this->input->post('kec');
		$data['no_telp_rmh']		= $this->input->post('no');
		$data['pensiun']			= $this->input->post('pensiun');
		$data['npwp']				= $this->input->post('npwp');
		$data['ket']				= $this->input->post('ket');
		

		$this->load->model('model_guru');
		
			$this->model_guru->getupdate($key,$data);
			$this->model_guru->update($key,$data);	
			$this->session->set_userdata('nama',$this->input->post('nama'));
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		
			redirect(base_url().'home_guru/edit');
	}

	public function password()
	{
		$this->model_squrity->getsqurity();
		$this->load->model('model_profil');
		$this->model_profil->set_password($this->input->post('pass_lama'));
			
		$query = $this->model_profil->view_by_password();
			
			if($query->num_rows())
			{
			$this->model_profil->set_username($this->input->post('user'));
			$this->model_profil->set_password_baru($this->input->post('pass_baru'));
			$this->model_profil->update_p();
			$this->session->set_userdata('username',$this->input->post('user'));
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
			} else{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Gagal di Perbaharui</div>');
			}
			redirect(base_url().'home_guru/edit');
	}

	public function foto()
	{
		$this->model_squrity->getsqurity();

		if(!empty($_FILES['foto']['name'])){
			$config['upload_path'] = realpath('assets/avatars/');
			$config['allowed_types'] = 'jpg|jpeg|png';
			$config['max_size']  = '2000000';
			$config['file_name'] = 'nip_'.$this->input->post('nip').'_'.date('Ymd').date('Hms');//$_FILES['foto']['name'];
			$config['overwrite'] = true;
     		
			$this->load->library('upload',$config);
			if (!$this->upload->do_upload('foto')){
				$this->session->set_flashdata('pesan','error:<b>'.$this->upload->display_errors().'</b>');
				redirect(base_url().'home_guru/edit');
			}
			else{
				$key = $this->session->userdata('id_pengguna');
				$f=$this->upload->data();
				$file=realpath('assets/avatars/').'/'.$this->session->userdata('foto');
				if(file_exists($file)){
					unlink(realpath('assets/avatars/').'/'.$this->session->userdata('foto'));
				}
				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan'),
				  			'foto'			=> $f['orig_name']
				  			);
			}
		} else{
				$key = $this->session->userdata('id_pengguna');

				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan')
				  			);
			}
		
		$key = $this->session->userdata('id_pengguna');
		$this->load->model('model_profil');
		/*$query = $this->model_profil->get($key);
		
		if($query->num_rows()>0)
		{	
		
		*/	$this->model_profil->getupdate($key,$data);

			$this->session->set_userdata('foto',$f['orig_name']);
			//echo "Data Berhasil di Perbaharui";
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
			redirect(base_url().'home_guru/edit');
		/*}
		else
		{
			
			//echo "Data Berhasil di Simpan";
			$this->session->set_flashdata('info','data sukses di simpan');
		}*/
	}

	function loaddata()
    {
    	$this->model_squrity->getsqurity();
      
       	$id_kelas = $_GET['id_kelas'];
       	$profileSQL=    "SELECT
							siswa.nama AS siswa,
							siswa.nis,
							kelas.kelas AS kelas,
							guru.nama AS guru,
							tahun_pelajaran.tahun_pelajaran,
							kelas.id_kelas,
							kelas_siswa.id_kelassiswa
						FROM
							kelas_siswa
						RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
						LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
						LEFT JOIN guru ON kelas.nip = guru.nip
						INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
						WHERE
							kelas.id_kelas=$id_kelas";
        $kelas_siswa   = $this->db->query($profileSQL)->row_array();
        $query = $this->db->query($profileSQL)->result();

       if($kelas_siswa){

     		echo '<form class="form-horizontal">
	<h4 class="header"><STRONG>Data Kelas</STRONG></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Kelas</label>
		<div class="col-sm-2">
			<label class="control-label">'.$kelas_siswa['kelas'].'</label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Wali Kelas</label>
		<div class="col-sm-6">
			<label class="control-label">'.$kelas_siswa['guru'].'</label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<label class="control-label">'.$kelas_siswa['tahun_pelajaran'].'</label>
		</div>	
	</div>
	<table id="simple-table" class="table table-striped table-bordered table-hover">
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">NIS</th>
			<th class="center">Nama Siswa</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody id="lihat">';
           $no=1;
	 		
	 		 foreach ($query as $key) {
       	    
		        echo '
						<tr>
	 		<td>'.$no++.'</td>
	 		<td>'.$key->nis.'</td>
			<td>'.$key->siswa.'</td>
			<td><input id="id_kelassiswa" hidden name="id_kelassiswa" value='.$key->id_kelassiswa.'></td>
	 	</tr>
				       	';
	       }
	       echo "</tbody>
</table></form>";
		}
		else{
			echo '';
		}
       
    }

    public function mapel()
	{
		$this->model_squrity->getsqurity();
		$id_tahunpelajaran 	= $_GET['id_tahunpelajaran'];
		$semester = $_GET['semester'];
		$nip = $this->session->userdata('nip');
        $khs        =   "SELECT
							nilai_kkm.*,
							guru.nip,
							guru.nama,
							mapel.nama_mapel
						FROM
							nilai_kkm,
							guru, 
							mapel
						WHERE
							nilai_kkm.id_mapel = guru.id_mapel 
						AND	nilai_kkm.id_mapel = mapel.id_mapel
						AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran
						AND nilai_kkm.semester = '$semester'
						AND guru.nip = $nip";
 	 	$c          =  $this->db->query($khs)->row_array();
		if($c){

			echo '<form><label class="control-label"><strong>Data Mata Pelajaran</strong></label>
				<input type="text" id="id_kkm" hidden name="id_kkm" value="'.$c['id_kkm'].'">';
			echo '	<table class="table table-bordered">
			    	<tr><td>Nama Mata Pelajaran : <label class="control-label">'. $c['nama_mapel'] .'</label></td></tr> 
					<tr><td>Nilai KKM : <label class="control-label">'. $c['nilai_kkm'] .'</label></td></tr></table></form>';
			echo '';
		}
		else {
			echo 'Maaf data nilai kkm belum di buat mohon hubungi admin';
		}	 
		
	}

function coba()
    {
    	$this->model_squrity->getsqurity();
      
       	$id_tahunpelajaran 	= $_GET['id_tahunpelajaran'];
		$semester = $_GET['semester'];
		$nip = $this->session->userdata('nip');
        $khs        =   "SELECT
							nilai_kkm.*,
							guru.nip,
							guru.nama,
							mapel.nama_mapel
						FROM
							nilai_kkm,
							guru, 
							mapel
						WHERE
							nilai_kkm.id_mapel = guru.id_mapel 
						AND	nilai_kkm.id_mapel = mapel.id_mapel
						AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran
						AND nilai_kkm.semester = '$semester'
						AND guru.nip = $nip";
 	 	$c          =  $this->db->query($khs)->row_array();
 	 	$id_kelas = $_GET['id_kelas'];
       	$profileSQL=    "SELECT
							siswa.nama AS siswa,
							siswa.nis,
							kelas.kelas AS kelas,
							guru.nama AS guru,
							tahun_pelajaran.tahun_pelajaran,
							kelas.id_kelas,
							kelas_siswa.id_kelassiswa
						FROM
							kelas_siswa
						RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
						LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
						LEFT JOIN guru ON kelas.nip = guru.nip
						INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
						WHERE
							kelas.id_kelas=$id_kelas";
		$a          =  $this->db->query($profileSQL)->row_array();
 	 	$query = $this->db->query($profileSQL)->result();
		if($c){
			  $no=1;
 			foreach ($query as $key) {
			echo "<tr>
	 		<td>".$no++."</td>
	 		<td>".$key->nis."</td>
			<td>".$key->siswa."</td>
			<td class='center'>
			<i class='fa fa-pencil' onclick='ambil($key->id_kelassiswa)' title='Ambil Siswa'> </i></td>
	 	";
		}
		echo"<tr>
        <td colspan=4>".anchor('cetak/nilai_kelas/'.$id_kelas.'/'.$id_tahunpelajaran.'/'.$semester,'<i class="ace-icon fa fa-print"></i> Cetak Nilai',array('class'=>'btn btn-danger btn-sm','</td></tr>'));
		}
		else {
			  $no=1;
 			foreach ($query as $key) {
			echo "<tr>
	 		<td>".$no++."</td>
	 		<td>".$key->nis."</td>
			<td>".$key->siswa."</td>
			<td></td>
	 	</tr>";
		}
		}	 
		       
	       
	     
    }

    public function cek()
	{
		$this->model_squrity->getsqurity();
		$id_kkm 	= $_GET['id_kkm'];
		$id_kelassiswa = $_GET['id_kelassiswa'];
		$id_tahunpelajaran 	= $_GET['id_tahunpelajaran'];
		$semester = $_GET['semester'];
		$nip = $this->session->userdata('nip');

		$profileSQL=    "SELECT
							siswa.nis,
							siswa.nama AS siswa,
							kelas.kelas,
							guru.nama AS guru,
							tahun_pelajaran.tahun_pelajaran,
							kelas_siswa.id_kelassiswa
						FROM
							kelas_siswa,
							kelas,
							siswa,
							guru,
							tahun_pelajaran
						WHERE
							kelas_siswa.id_kelas = kelas.id_kelas
						AND kelas_siswa.nis = siswa.nis
						AND kelas.nip = guru.nip
						AND kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
						AND kelas_siswa.id_kelassiswa = $id_kelassiswa";
        $d   = $this->db->query($profileSQL)->row_array();

        echo '	<input type="text" name="id_kelassiswa" hidden id="id_kelassiswa" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$d['id_kelassiswa'].'>
				        <table class="table table-bordered" id="daftarkrs">
				        <tr>
				            <td>NAMA</td><td>'.  strtoupper($d['siswa']).'</td>
				            <td>NIS</td><td>'.  strtoupper($d['nis']).'</td>
				        </tr>
				        <tr>
				            <td>Kelas, Tahun Pelajaran</td><td>'.  strtoupper($d['kelas'].' / '.$d['tahun_pelajaran']).'</td>
				            <td>Wali Kelas</td><td>'.$d['guru'].'</td>
				        </tr>
				        </table>

				       	';
		       
        $khs        =   "SELECT
							nilai_kkm.*,
							guru.nip,
							guru.nama,
							mapel.nama_mapel
						FROM
							nilai_kkm,
							guru, 
							mapel
						WHERE
							nilai_kkm.id_mapel = guru.id_mapel 
						AND	nilai_kkm.id_mapel = mapel.id_mapel
						AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran
						AND nilai_kkm.semester = '$semester'
						AND guru.nip = $nip";
 	 	$c          =  $this->db->query($khs)->row_array();
		$SQL=    "SELECT
					mapel.nama_mapel,
					nilai_kkm.nilai_kkm,
					nilai_kkm.semester,
					kelas_siswa.nis,
					nilai_akhirsiswa.*
				FROM
					nilai_akhirsiswa,
					nilai_kkm,
					mapel,
					kelas_siswa
				WHERE
					nilai_akhirsiswa.id_kelassiswa = kelas_siswa.id_kelassiswa
				AND nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
				AND nilai_kkm.id_mapel = mapel.id_mapel
				AND nilai_akhirsiswa.id_kelassiswa = '$d[id_kelassiswa]'
				AND nilai_akhirsiswa.id_kkm = '$c[id_kkm]'";
     
        $f   = $this->db->query($SQL)->result();


				echo '<form class="form-horizontal">
					<div class="form-group">
					<label class="col-sm-4 control-label">Nama Mata Pelajaran</label>
					<div class="col-sm-6">
						<label class="control-label">'. $c['nama_mapel'] .'</label>
					</div>	
					</div>
					<div class="form-group">
					<label class="col-sm-4 control-label">Nilai KKM</label>
					<div class="col-sm-2"><input id="id_kelassiswa" hidden value="'.$c['id_kkm'].'">
						<label class="control-label">'. $c['nilai_kkm'] .'</label>
					</div>	
					</div></form>';	
			
			echo '<form class="form-horizontal" method="post" >
			<input name="nis" id="nis" hidden  class="col-sm-5" value='.$d['nis'].'>';

		//action="<?php echo base_url();nilai_akhir/simpan" 
			if($f)
			{
				foreach ($f as $key) 
				{
					echo '
						<input id="id_kelassiswa" hidden value="'.$d['id_kelassiswa'].'">
						
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 1</label>
							<div class="col-sm-2"><input  name="id_nilaiakhir" hidden id="id_nilaiakhir" value="'.$key->id_nilaiakhir.'">
							
								<input type="text" name="nilai_harian1" id="nilai_harian1" placeholder="Masukkan Nilai Harian 1" class="col-sm-5" value='.$key->nilai_harian1.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 2</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian2" id="nilai_harian2" placeholder="Masukkan Nilai Harian 2" class="col-sm-5" value='.$key->nilai_harian2.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 3</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian3" id="nilai_harian3" placeholder="Masukkan Nilai Harian 3" class="col-sm-5" value='.$key->nilai_harian3.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 4</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian4" id="nilai_harian4" onchange="rata()" placeholder="Masukkan Nilai Harian 4" class="col-sm-5" value='.$key->nilai_harian4.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Rata-Rata Harian</label>
							<div class="col-sm-2">
								<label class="control-label" name="nilai_rataharian" id="nilai_rataharian">'.$key->nilai_rataharian.'</label>						
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Tengah Semester</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_uts" id="nilai_uts" placeholder="Masukkan Nilai UTS" class="col-sm-5" value='.$key->nilai_uts.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Akhir Semester</label>
							<div class="col-sm-2">
								<input type="text" onchange="jumlah()" name="nilai_uas" id="nilai_uas"  placeholder="Masukkan Nilai UAS" class="col-sm-5" value='.$key->nilai_uas.'>
							</div>	
						</div><div class="form-group">
							<label class="col-sm-4 control-label">Nilai Akhir</label>
							<div class="col-sm-2">
								<label class="control-label" id="nilai_akhir" name="nilai_akhir">'.$key->nilai_akhir.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Angka</label>
							<div class="col-sm-8">
								<label class="control-label" id="angka" name="angka">'.$key->angka.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Catatan Guru</label>
							<div class="col-sm-8">
								<textarea name="catatan_guru" id="catatan_guru" placeholder="Masukkan Catatan Guru" class="col-xs-10 col-sm-7" value='.$key->catatan_guru.'></textarea>
							</div>	
						</div>';
					
				}	
			}
		else 
		{
			echo '
				<input type="text" name="id_nilaiakhir" hidden id="id_nilaiakhir" class="col-sm-5">

				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 1</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian1" id="nilai_harian1" placeholder="Masukkan Nilai Harian 1" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 2</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian2" id="nilai_harian2" placeholder="Masukkan Nilai Harian 2" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 3</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian3" id="nilai_harian3" placeholder="Masukkan Nilai Harian 3" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 4</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian4" id="nilai_harian4" onchange="rata()" placeholder="Masukkan Nilai Harian 4" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Rata-Rata Harian</label>
					<div class="col-sm-2">
						<label  class="control-label" id="nilai_rataharian" name="nilai_rataharian"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Ulangan Tengah Semester</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_uts" id="nilai_uts" placeholder="Masukkan Nilai UTS" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Ulangan Akhir Semester</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_uas" id="nilai_uas" onchange="jumlah()" placeholder="Masukkan Nilai UAS" class="col-sm-5">
					</div>	
				</div><div class="form-group">
					<label class="col-sm-4 control-label">Nilai Akhir</label>
					<div class="col-sm-2">
						<label class="control-label" id="nilai_akhir" name="nilai_akhir"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Angka</label>
					<div class="col-sm-8">
						<label  class="control-label" id="angka" name="angka"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Catatan Guru</label>
					<div class="col-sm-8">
						<textarea name="catatan_guru" id="catatan_guru" placeholder="Masukkan Catatan Guru" class="col-xs-10 col-sm-7" ></textarea>
					</div>	
				</div>';
		}	 
			echo '<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9">
					<button type="button" onclick="simpan()" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp; 
					<button type="button" onclick="tampil()" class="btn"><i class="ace-icon fa fa-undo"></i>tutup</button> 
					</div>
				</div></form>';
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url().'login');
	}
}
