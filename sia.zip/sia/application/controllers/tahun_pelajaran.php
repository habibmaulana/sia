<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tahun_pelajaran extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tahunpelajaran/tampil_datatahunpelajaran';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tahun Pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->db->get('tahun_pelajaran');
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tahunpelajaran/form_tambahtahunpelajaran';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tambah Tahun Pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['id_tahun'] 	= '';
		$isi['tahun'] 		= '';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tahunpelajaran/form_tambahtahunpelajaran';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Edit Tahun Pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		$this->db->where('id_tahunpelajaran',$key);
		$query = $this->db->get('tahun_pelajaran');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_tahun'] 		= $row->id_tahunpelajaran;
				$isi['tahun'] 		= $row->tahun_pelajaran;
			}
		}
		else
		{
			$isi['id_tahun'] 	= '';
			$isi['tahun'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('id_tahun');
		$data['id_tahunpelajaran']	= $this->input->post('id_tahun');
		$data['tahun_pelajaran']	= $this->input->post('tahun');
		
		$this->load->model('model_tahunpelajaran');
		$query = $this->model_tahunpelajaran->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_tahunpelajaran->getupdate($key,$data);
			echo "Data Berhasil di Perbaharui";
		}
		else
		{
			$this->model_tahunpelajaran->getinsert($data);
			echo "Data Berhasil di Simpan";
		}
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_tahunpelajaran');
		$key = $this->uri->segment(3);
		$this->db->where('id_tahunpelajaran',$key);
		$query = $this->db->get('tahun_pelajaran');
		if($query->num_rows()>0)
		{
			$this->model_tahunpelajaran->getdelete($key);
		}
		redirect(base_url().'tahun_pelajaran');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 