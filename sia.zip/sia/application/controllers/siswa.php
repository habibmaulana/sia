<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Siswa extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/siswa/tampil_datasiswa';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->db->get('siswa');
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 		= 'admin/siswa/form_tambahsiswa';
		$isi['judul']			= 'Master';
		$isi['sub_judul']		= 'Tambah Siswa';
		$isi['icon']			= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['nis'] 			= '';
		$isi['nisn'] 			= '';
		$isi['nama'] 			= '';
		$isi['tempat'] 			= '';
		$isi['tgl'] 			= '';
		$isi['jenis'] 			= '';
		$isi['agama'] 			= '';
		$isi['status'] 			= '';
		$isi['anak'] 			= '';
		$isi['alamat'] 			= '';
		$isi['no'] 				= '';
		$isi['sekolah'] 		= '';
		$isi['kelas'] 			= '';
		$isi['pada'] 			= '';
		$isi['ayah'] 			= '';
		$isi['ibu'] 			= '';
		$isi['alamat_ortu'] 	= '';
		$isi['no_ortu'] 		= '';
		$isi['pekerjaan_ayah'] 	= '';
		$isi['pekerjaan_ibu'] 	= '';
		$isi['wali'] 			= '';
		$isi['alamat_wali'] 	= '';
		$isi['no_wali'] 		= '';
		$isi['pekerjaan_wali'] 	= '';
		$isi['id_tahunpelajaran'] 	= '';

		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/siswa/form_tampilsiswa';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tampil Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		
		$key = $this->uri->segment(3);
		$this->load->model('model_siswa');
		$query = $this->model_siswa->get($key);
		
			foreach ($query->result() as $row) 
			{
				$isi['nis'] 			= $row->nis;
				$isi['nisn'] 			= $row->nisn;
				$isi['nama'] 			= $row->nama;
				$isi['tempat'] 			= $row->tempat_lahir;
				$isi['tgl'] 			= $row->tgl_lahir;
				$isi['jenis'] 			= $row->jenis_kelamin;
				$isi['agama'] 			= $row->agama;
				$isi['status'] 			= $row->status_dalam_keluarga;
				$isi['anak'] 			= $row->anak_ke;
				$isi['alamat'] 			= $row->alamat_siswa;
				$isi['no'] 				= $row->no_telp_siswa;
				$isi['sekolah'] 		= $row->sekolah_asal;
				$isi['id_kelas'] 		= $row->kelas;
				$isi['pada'] 			= $row->pada_tanggal;
				$isi['ayah'] 			= $row->nama_ayah;
				$isi['ibu'] 			= $row->nama_ibu;
				$isi['alamat_ortu'] 	= $row->alamat_ortu;
				$isi['no_ortu'] 		= $row->no_telp_ortu;
				$isi['pekerjaan_ayah'] 	= $row->pekerjaan_ayah;
				$isi['pekerjaan_ibu'] 	= $row->pekerjaan_ibu;
				$isi['wali'] 			= $row->nama_wali;
				$isi['alamat_wali'] 	= $row->alamat_wali;
				$isi['no_wali'] 		= $row->no_telp_wali;
				$isi['pekerjaan_wali'] 	= $row->pekerjaan_wali;
				$isi['id_tahunpelajaran'] 	= $row->tahun_pelajaran;
			}
		
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/siswa/form_tambahsiswa';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Edit Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		
		$key = $this->uri->segment(3);
		$this->db->where('nis',$key);
		$query = $this->db->get('siswa');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nis'] 			= $row->nis;
				$isi['nisn'] 			= $row->nisn;
				$isi['nama'] 			= $row->nama;
				$isi['tempat'] 			= $row->tempat_lahir;
				$isi['tgl'] 			= $row->tgl_lahir;
				$isi['jenis'] 			= $row->jenis_kelamin;
				$isi['agama'] 			= $row->agama;
				$isi['status'] 			= $row->status_dalam_keluarga;
				$isi['anak'] 			= $row->anak_ke;
				$isi['alamat'] 			= $row->alamat_siswa;
				$isi['no'] 				= $row->no_telp_siswa;
				$isi['sekolah'] 		= $row->sekolah_asal;
				$isi['id_kelas'] 			= $row->id_kelas;
				$isi['pada'] 			= $row->pada_tanggal;
				$isi['ayah'] 			= $row->nama_ayah;
				$isi['ibu'] 			= $row->nama_ibu;
				$isi['alamat_ortu'] 	= $row->alamat_ortu;
				$isi['no_ortu'] 		= $row->no_telp_ortu;
				$isi['pekerjaan_ayah'] 	= $row->pekerjaan_ayah;
				$isi['pekerjaan_ibu'] 	= $row->pekerjaan_ibu;
				$isi['wali'] 			= $row->nama_wali;
				$isi['alamat_wali'] 	= $row->alamat_wali;
				$isi['no_wali'] 		= $row->no_telp_wali;
				$isi['pekerjaan_wali'] 	= $row->pekerjaan_wali;
				$isi['id_tahunpelajaran'] 	= $row->id_tahunpelajaran;
			}
		}
		else
		{
			$isi['nis'] 			= '';
			$isi['nisn'] 			= '';
			$isi['nama'] 			= '';
			$isi['tempat'] 			= '';
			$isi['tgl'] 			= '';
			$isi['jenis'] 			= '';
			$isi['agama'] 			= '';
			$isi['status'] 			= '';
			$isi['anak'] 			= '';
			$isi['alamat'] 			= '';
			$isi['no'] 				= '';
			$isi['sekolah'] 		= '';			
			$isi['id_kelas'] 			= '';
			$isi['pada'] 			= '';
			$isi['ayah'] 			= '';
			$isi['ibu'] 			= '';
			$isi['alamat_ortu'] 	= '';
			$isi['no_ortu'] 		= '';
			$isi['pekerjaan_ayah'] 	= '';
			$isi['pekerjaan_ibu'] 	= '';
			$isi['wali'] 			= '';
			$isi['alamat_wali'] 	= '';
			$isi['no_wali'] 		= '';
			$isi['pekerjaan_wali'] 	= '';
			$isi['id_tahunpelajaran'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('nis');
		$data['nis']					= $this->input->post('nis');
		$data['nisn']					= $this->input->post('nisn');
		$data['nama']					= $this->input->post('nama');
		$data['tempat_lahir'] 			= $this->input->post('tempat');
		$data['tgl_lahir'] 				= $this->input->post('tgl');
		$data['jenis_kelamin'] 			= $this->input->post('jenis');
		$data['agama'] 					= $this->input->post('agama');
		$data['status_dalam_keluarga'] 	= $this->input->post('status');
		$data['anak_ke'] 				= $this->input->post('anak');
		$data['alamat_siswa'] 			= $this->input->post('alamat');
		$data['no_telp_siswa'] 			= $this->input->post('no');
		$data['sekolah_asal'] 			= $this->input->post('sekolah');			
		$data['id_kelas'] 				= $this->input->post('id_kelas');
		$data['pada_tanggal'] 			= $this->input->post('pada');
		$data['nama_ayah'] 				= $this->input->post('ayah');
		$data['nama_ibu'] 				= $this->input->post('ibu');
		$data['alamat_ortu'] 			= $this->input->post('alamat_ortu');
		$data['no_telp_ortu'] 			= $this->input->post('no_ortu');
		$data['pekerjaan_ayah'] 		= $this->input->post('pekerjaan_ayah');
		$data['pekerjaan_ibu'] 			= $this->input->post('pekerjaan_ibu');
		$data['nama_wali'] 				= $this->input->post('wali');
		$data['alamat_wali'] 			= $this->input->post('alamat_wali');
		$data['no_telp_wali'] 			= $this->input->post('no_wali');
		$data['pekerjaan_wali']			= $this->input->post('pekerjaan_wali');
		$data['id_tahunpelajaran'] 		= $this->input->post('id_tahunpelajaran');
		$this->load->model('model_siswa');
		$query = $this->model_siswa->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_siswa->getupdate($key,$data);
			$this->model_siswa->update($key,$data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		}
		else
		{	
			$this->model_siswa->insert($data);
			$this->model_siswa->getinsert($data);
			$this->model_siswa->tambah($data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Simpan</div>');
		}
		
		redirect(base_url().'siswa/tambah');
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_siswa');
		$key = $this->uri->segment(3);
		$this->db->where('nis',$key);
		$query = $this->db->get('siswa');
		if($query->num_rows()>0)
		{
			$this->model_siswa->getdelete($key);
			$this->model_siswa->delete($key);
			$this->model_siswa->delet($key);
			$this->model_siswa->hapus($key);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Berhasil Di Hapus</div>');
		}
		redirect(base_url().'siswa');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 