<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Nilai_akhir extends CI_Controller {

	public function index()
	{
		$this->load->model('model_kelassiswa');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/nilai_akhir/form_tambahnilai';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'Nilai Akhir';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"'; 
		$isi['data']		= $this->model_kelassiswa->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function kelas()
	{
		$this->model_squrity->getsqurity();
		$id_tahunpelajaran 	= $this->input->post('id_tahunpelajaran');
		if($id_tahunpelajaran){
			$this->load->model('model_kelassiswa');
			$kelas = $this->model_kelassiswa->kelas($id_tahunpelajaran);
			echo '<option value="0">--Pilih Kelas--</option>';
			foreach ($kelas as $key) {
					echo '<option value='. $key->id_kelas .'>'. $key->kelas .'</option>';
				}	
		} else {
			echo '<option value="0">--Pilih Kelas--</option>';
		}
	}

	function loaddata()
    {
    	$this->model_squrity->getsqurity();
        $nis      =  $_GET['nis'];
       	$id_kelas = $_GET['id_kelas'];
       	$this->load->model('model_nilaiakhir');
		$kelas_siswa = $this->model_nilaiakhir->data($nis,$id_kelas);
     	if($kelas_siswa->num_rows() > 0){
             foreach ($kelas_siswa->result() as $d) 
       		{
       	    
		        echo '
						<input type="text" name="id_kelassiswa" hidden id="id_kelassiswa" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$d->id_kelassiswa.'>
				        <table class="table table-bordered" id="daftarkrs">
				        <tr>
				            <td>NAMA</td><td>'.  strtoupper($d->nama).'</td>
				            <td>NIS</td><td>'.  strtoupper($d->nis).'</td>
				        </tr>
				        <tr>
				            <td>Kelas, Tahun Pelajaran</td><td>'.  strtoupper($d->kelas.' / '.$d->tahun_pelajaran).'</td>
				            <td>Wali Kelas</td><td>'.$d->guru.'</td>
				        </tr>
				        </table>

				       	';
	       }
		}
		else{
			echo '';
		}
       
    }

    function loadnilai()
    {
    	$this->model_squrity->getsqurity();

        $nis             		=  $_GET['nis'];
        $id_tahunpelajaran  	=  $_GET['id_tahunpelajaran'];
        $id_kelas             	=  $_GET['id_kelas'];
        $semester             	=  $_GET['semester'];
        
       	$this->load->model('model_nilaiakhir');
		$nilai = $this->model_nilaiakhir->nilai($nis,$id_kelas,$id_tahunpelajaran,$semester);
       
       if ($nilai) {
       	# code...
       
        if($nilai->num_rows() > 0)
        {
        		echo '

       	<table class="table table-bordered" id="daftarkrs">
        <tr><th width="5">No</th>
        <th>Nama Mata Pelajaran</th>
        <th>Nilai Rata-Rata Harian</th>
        <th>Nilai UTS</th>
        <th>Nilai UAS</th>
        <th>Nilai Akhir</th>
        <th width="10">Hapus</th></tr>';
             $no=1;
            
            foreach ($nilai->result() as $r)
            {
                echo " <tr id='id_nilaiakhirhide$r->id_nilaiakhir'>
                            <td>$no</td>
                            <td>".  strtoupper($r->nama_mapel)."</td>
                            <td>".  $r->nilai_rataharian."</td>
                            <td>".  $r->nilai_uts."</td>
                            <td>".  $r->nilai_uas."</td>
                            <td>".  $r->nilai_akhir."</td>
                            <td align='center'><i class='fa fa-trash-o' onclick='hapus($r->id_nilaiakhir)' title='Hapus Nilai'> </td></tr>";
				
                $no++;
             
            }
            echo"<tr>
        <td colspan=7>".anchor('cetak/nilai/'.$nis.'/'.$id_tahunpelajaran.'/'.$id_kelas.'/'.$semester,'<i class="ace-icon fa fa-print"></i> Cetak Nilai',array('class'=>'btn btn-danger btn-sm','</td></tr></table>'));
        }
        else
        { 
            echo '<tr><td colspan=7>DATA TIDAK DITEMUKAN</td></tr></table>';

        }

         }
        else
        { 
            echo "";

        }

    }

	public function nama()
	{
		$this->model_squrity->getsqurity();
		$id_kelas 	= $this->input->post('id_kelas');
		if($id_kelas){
			$this->load->model('model_nilaiakhir');
			$kelas = $this->model_nilaiakhir->nip($id_kelas);
			
			foreach ($kelas as $key) {
					echo '<label class="control-label">'. $key->nama .'</label>';
					
				}	
		} else {
			echo '<label>-</label>';
		}
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/nilai_akhir/form_tambahnilai';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'tambah Nilai Akhir';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';
		$isi['id_mapel'] 	= '';
		$isi['nilai_kkm'] 	= '';
		$isi['semester'] 	= '';
		$isi['id_tahunpelajaran'] 	= '';

		$this->load->view('admin/tampilan_home',$isi);
	}


	public function siswa()
	{
		$this->model_squrity->getsqurity();
		$id_kelas 	= $this->input->post('id_kelas');
		if($id_kelas){
			$this->load->model('model_nilaiakhir');
			$nis = $this->model_nilaiakhir->nis($id_kelas);
			echo '<option value="0">--Pilih Siswa--</option>';
			foreach ($nis as $key) {
				echo '<option value='. $key->nis .'>'. $key->nama .'</option>';
				}	
		} else {
			echo '<option value="0">--Pilih Siswa--</option>';
		}
	}

	public function semester()
	{
		$this->model_squrity->getsqurity();
		$id_tahunpelajaran 	= $_GET['id_tahunpelajaran'];
		if($id_tahunpelajaran){
			$this->load->model('model_nilaiakhir');
			$nis = $this->model_nilaiakhir->nilai_kkm($id_tahunpelajaran);
			echo '<option value="0">--Pilih Semester--</option>';
			foreach ($nis as $key) {
			echo '<option value='. $key->semester .'>'. $key->semester .'</option>';
				}
			echo '</select>';	
		} else {
			echo '<option value="0">--Pilih Semester--</option>';
		}
	}

	function angka()
	{
		$nilai_harian1 = $_GET['nilai_harian1'];
		$nilai_harian2 = $_GET['nilai_harian2'];
		$nilai_harian3 = $_GET['nilai_harian3'];
		$nilai_harian4 = $_GET['nilai_harian4'];

		$jumlah = $nilai_harian1 + $nilai_harian2 + $nilai_harian3 + $nilai_harian4;
		$hasil = $jumlah / 4;
		$nilai_uts = $_GET['nilai_uts'];
		$nilai_uas = $_GET['nilai_uas'];
		$angka	= ((0.6*$hasil)+(0.2*$nilai_uts)+(0.2*$nilai_uas));
		
		echo number_to_words($angka);
	}

	function rata()
	{
		$nilai_harian1 = $_GET['nilai_harian1'];
		$nilai_harian2 = $_GET['nilai_harian2'];
		$nilai_harian3 = $_GET['nilai_harian3'];
		$nilai_harian4 = $_GET['nilai_harian4'];

		$jumlah = $nilai_harian1 + $nilai_harian2 + $nilai_harian3 + $nilai_harian4;
		$nilai_rataharian = $jumlah / 4;
		echo round($nilai_rataharian);
	}

	function jumlah()
	{
		$nilai_harian1 = $_GET['nilai_harian1'];
		$nilai_harian2 = $_GET['nilai_harian2'];
		$nilai_harian3 = $_GET['nilai_harian3'];
		$nilai_harian4 = $_GET['nilai_harian4'];

		$jumlah = $nilai_harian1 + $nilai_harian2 + $nilai_harian3 + $nilai_harian4;
		$hasil = $jumlah / 4;

		$nilai_uts = $_GET['nilai_uts'];
		$nilai_uas = $_GET['nilai_uas'];
		$nilai_akhir	= ((0.6*$hasil)+(0.2*$nilai_uts)+(0.2*$nilai_uas));
		
		echo round($nilai_akhir);	
	}

	public function mapel()
	{
		$this->model_squrity->getsqurity();
		$id_tahunpelajaran 	= $_GET['id_tahunpelajaran'];
		$semester = $_GET['semester'];

		$this->load->model('model_nilaiakhir');
		$mapel = $this->model_nilaiakhir->mapel($id_tahunpelajaran,$semester);
		if($mapel->num_rows() > 0){
			echo "<label><strong>Data Mata Pelajaran</strong></label>
							<table class='table table-bordered'>
			    			<tr><td>Mata Pelajaran Pelajaran <select onchange='input()' class='form-control' type='text' id='id_kkm' name='id_kkm'>
			         		<option value='0'>--Pilih Mata Pelajaran--</option>";

			foreach ($mapel->result() as $key) {
				echo '<option value="'. $key->id_kkm .'">'. $key->nama_mapel .'</option>';	
				}	
		echo '</select></td></tr></table>';
		}
		else {
			echo '';
		}	 
		
	}

	public function cek()
	{
		$this->model_squrity->getsqurity();
		$id_kkm 	= $_GET['id_kkm'];
		$nis      	= $_GET['nis'];
       	$id_kelas 	= $_GET['id_kelas'];
		$nilai_akhir = $_GET['nilai_akhir'];
		$nilai_rataharian = $_GET['nilai_rataharian'];
		$angka = $_GET['angka'];


		$this->load->model('model_nilaiakhir');
		$cek = $this->model_nilaiakhir->nil($id_kkm,$nis,$id_kelas);
		$kk = $this->model_nilaiakhir->kkm($id_kkm);
		if($kk){
			foreach ($kk as $key) 
			{
				echo '<form class="form-horizontal">
					<div class="form-group">
					<label class="col-sm-4 control-label">Nama Mata Pelajaran</label>
					<div class="col-sm-6">
						<label class="control-label">'. $key->nama_mapel .'</label>
					</div>	
					</div>
					<div class="form-group">
					<label class="col-sm-4 control-label">Nilai KKM</label>
					<div class="col-sm-2">
						<label class="control-label">'. $key->nilai_kkm .'</label>
					</div>	
					</div></form>';	
			}
			echo '<form class="form-horizontal" method="post" >';
			if($cek)
			{
				foreach ($cek->result() as $key) 
				{
					echo '
						<input type="text" name="id_nilaiakhir" hidden id="id_nilaiakhir" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->id_nilaiakhir.'>

						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 1</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian1" id="nilai_harian1" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->nilai_harian1.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 2</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian2" id="nilai_harian2" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->nilai_harian2.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 3</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian3" id="nilai_harian3" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->nilai_harian3.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 4</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_harian4" id="nilai_harian4" onchange="rata()" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->nilai_harian4.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Rata-Rata Harian</label>
							<div class="col-sm-2">
								<label class="control-label" name="nilai_rataharian" id="nilai_rataharian">'.$key->nilai_rataharian.'</label>						
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Tengah Semester</label>
							<div class="col-sm-2">
								<input type="text" name="nilai_uts" id="nilai_uts" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->nilai_uts.'>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Akhir Semester</label>
							<div class="col-sm-2">
								<input type="text" onchange="jumlah()" name="nilai_uas" id="nilai_uas"  placeholder="Masukkan Nilai KKM" class="col-sm-5"  value='.$key->nilai_uas.'>
							</div>	
						</div><div class="form-group">
							<label class="col-sm-4 control-label">Nilai Akhir</label>
							<div class="col-sm-2">
								<label class="control-label" id="nilai_akhir" name="nilai_akhir">'.$key->nilai_akhir.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Angka</label>
							<div class="col-sm-8">
								<label class="control-label" id="angka" name="$angka">'.$key->angka.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Catatan Guru</label>
							<div class="col-sm-8">
								<textarea name="catatan_guru" id="catatan_guru" placeholder="Masukkan Keterangan" class="col-xs-10 col-sm-7" value='.$key->catatan_guru.'></textarea>
							</div>	
						</div>';
					
				}	
			}
		else 
		{
			echo '
				<input type="text" name="id_nilaiakhir" hidden id="id_nilaiakhir" placeholder="Masukkan Nilai KKM" class="col-sm-5">

				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 1</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian1" id="nilai_harian1" placeholder="Masukkan Nilai KKM" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 2</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian2" id="nilai_harian2" placeholder="Masukkan Nilai KKM" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 3</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian3" id="nilai_harian3" placeholder="Masukkan Nilai KKM" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Harian Ke 4</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_harian4" id="nilai_harian4" onchange="rata()" placeholder="Masukkan Nilai KKM" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Rata-Rata Harian</label>
					<div class="col-sm-2">
						<label  class="control-label" id="nilai_rataharian" name="nilai_rataharian"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Ulangan Tengah Semester</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_uts" id="nilai_uts" placeholder="Masukkan Nilai KKM" class="col-sm-5" >
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Nilai Ulangan Akhir Semester</label>
					<div class="col-sm-2">
						<input type="text" name="nilai_uas" id="nilai_uas" onchange="jumlah()" placeholder="Masukkan Nilai KKM" class="col-sm-5">
					</div>	
				</div><div class="form-group">
					<label class="col-sm-4 control-label">Nilai Akhir</label>
					<div class="col-sm-2">
						<label class="control-label" id="nilai_akhir" name="nilai_akhir"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Angka</label>
					<div class="col-sm-8">
						<label  class="control-label" id="angka" name="angka"></label>
					</div>	
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">Catatan Guru</label>
					<div class="col-sm-8">
						<textarea name="catatan_guru" id="catatan_guru" placeholder="Masukkan Keterangan" class="col-xs-10 col-sm-7" ></textarea>
					</div>	
				</div>';
		}	 
			echo '<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9">
					<button type="button" onclick="simpan()" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp; 
					<button type="button" onclick="loadjurusan()" class="btn"><i class="ace-icon fa fa-undo"></i>tutup</button> 
					</div>
				</div></form>'; //onclick="loadtablemapel($id)"
		}
		else{
				echo "";
			}
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $_GET['id_nilaiakhir'];
		$data['id_nilaiakhir'] = $_GET['id_nilaiakhir'];
		$data['id_kelassiswa']	= $_GET['id_kelassiswa'];
		$data['nis']			= $_GET['nis'];
		$data['id_kkm']			= $_GET['id_kkm'];
		$data['nilai_harian1']	= $_GET['nilai_harian1'];
		$data['nilai_harian2'] 	= $_GET['nilai_harian2'];
		$data['nilai_harian3']	= $_GET['nilai_harian3'];
		$data['nilai_harian4'] 	= $_GET['nilai_harian4'];
		$data['nilai_rataharian'] 	= $_GET['nilai_rataharian'];
		$data['nilai_uts'] 			= $_GET['nilai_uts'];
		$data['nilai_uas']			= $_GET['nilai_uas'];
		$data['nilai_akhir'] 		= $_GET['nilai_akhir'];
		$data['angka'] 				= $_GET['angka'];
		$data['catatan_guru'] 		= $_GET['catatan_guru'];

		$this->load->model('model_nilaiakhir');
		$query = $this->model_nilaiakhir->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_nilaiakhir->getupdate($key,$data);
			echo "Data Berhasil di Perbaharui";
		}
		else
		{
			$this->model_nilaiakhir->getinsert($data);
			echo "Data Berhasil di Simpan";
		}
	}

	public function haps()
	{ 
		$this->model_squrity->getsqurity();
		$key = $_GET['id_nilaiakhir'];
		$this->load->model('model_nilaiakhir');
		
		$this->model_nilaiakhir->getdelete($key);
		
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 