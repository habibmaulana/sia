<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kelas extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$this->load->model('model_kelas');
		$isi['content'] 	= 'admin/kelas/tampil_datakelas';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Kelas';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->model_kelas->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 			= 'admin/kelas/form_tambahkelas';
		$isi['judul']				= 'Master';
		$isi['sub_judul']			= 'Tambah Kelas';
		$isi['icon']				= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['id_kelas'] 			= '';
		$isi['nama'] 				= '';
		$isi['nip'] 				= '';
		$isi['id_tahunpelajaran'] 	= '';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$this->load->model('model_kelas');
		$isi['content'] 	= 'admin/kelas/form_tampilkelas';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tampil Kelas';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		
		$query = $this->model_kelas->data();
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				
				$isi['kelas']				= $row->kelas;
				$isi['nama'] 				= $row->nama;
				$isi['tahun_pelajaran'] 	= $row->tahun_pelajaran;
			}
		}
		else
		{
			$isi['kelas']			= '';
			$isi['nama'] 			= '';
			$isi['tahun_pelajaran']	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/kelas/form_tambahkelas';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Edit Kelas';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		$this->db->where('id_kelas',$key);
		$query = $this->db->get('kelas');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_kelas']			= $row->id_kelas;
				$isi['nama'] 				= $row->kelas;
				$isi['nip'] 				= $row->nip;
				$isi['id_tahunpelajaran'] 	= $row->id_tahunpelajaran;
			}
		}
		else
		{
			$isi['id_kelas'] 			= '';
			$isi['nama'] 				= '';
			$isi['nip'] 				= '';
			$isi['id_tahunpelajaran'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key 						= $this->input->post('id_kelas');
		$data['id_kelas']			= $this->input->post('id_kelas');
		$data['kelas']				= $this->input->post('nama');
		$data['nip'] 				= $this->input->post('nip');
		$data['id_tahunpelajaran'] 	= $this->input->post('id_tahunpelajaran');
		
		$this->load->model('model_kelas');
		$query = $this->model_kelas->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_kelas->getupdate($key,$data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		}
		else
		{
			$this->model_kelas->getinsert($data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Simpan</div>');
		}
		redirect(base_url().'kelas/tambah');
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_kelas');
		$key = $this->uri->segment(3);
		$this->db->where('id_kelas',$key);
		$query = $this->db->get('kelas');
		if($query->num_rows()>0)
		{
			$this->model_kelas->getdelete($key);
			$this->model_kelas->delete($key);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Berhasil Di Hapus</div>');
		}
		redirect(base_url().'kelas');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 