<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mapel extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/mapel/tampil_datamapel';
		$isi['judul']		= 'master';
		$isi['sub_judul']	= 'mata pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->db->get('mapel');
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/mapel/form_tambahmapel';
		$isi['judul']		= 'master';
		$isi['sub_judul']	= 'tambah mata pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['nama'] 		= '';
		$isi['id']		= '';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/mapel/form_tampilmapel';
		$isi['judul']		= 'master';
		$isi['sub_judul']	= 'tampil mata pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		$this->db->where('id_mapel',$key);
		$query = $this->db->get('mapel');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				
				$isi['nama'] 	= $row->nama_mapel;
			}
		}
		else
		{
			
			$isi['nama'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/mapel/form_tambahmapel';
		$isi['judul']		= 'master';
		$isi['sub_judul']	= 'edit mata pelajaran';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		$this->db->where('id_mapel',$key);
		$query = $this->db->get('mapel');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id']		= $row->id_mapel;
				$isi['nama'] 	= $row->nama_mapel;
			}
		}
		else
		{
			$isi['id']		= '';
			$isi['nama'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('id');
		$data['id_mapel']	= $this->input->post('id');
		$data['nama_mapel']	= $this->input->post('nama');
		
		$this->load->model('model_mapel');
		$query = $this->model_mapel->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_mapel->getupdate($key,$data);
			echo "Data Berhasil di Perbaharui";
		}
		else
		{
			$this->model_mapel->getinsert($data);
			echo "Data Berhasil di Simpan";
		}
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_mapel');
		$key = $this->uri->segment(3);
		$this->db->where('id_mapel',$key);
		$query = $this->db->get('mapel');
		if($query->num_rows()>0)
		{
			$this->model_mapel->getdelete($key);
		}
		redirect(base_url().'mapel');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 