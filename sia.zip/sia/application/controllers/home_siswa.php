<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_siswa extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'siswa/tampilan_content';
		$isi['judul']		= 'home';
		$isi['sub_judul']	= '';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$this->load->view('siswa/tampilan_home',$isi);
	}

	public function siswa()
	{
		$this->load->model('model_kelassiswa');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'siswa/form_nilaiakhir';
		$isi['judul']		= 'Nilai Akhir';
		$isi['sub_judul']	= '';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"'; 
		$isi['data']		= $this->model_kelassiswa->data();
		//$isi['data']		= $this->db->get('nilai_akhir');
		$this->load->view('siswa/tampilan_home',$isi);
	}

	public function profil()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'siswa/tampilan_profil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Data Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$key = $this->session->userdata('nis');
		$this->load->model('model_siswa');
		$query = $this->model_siswa->get($key);
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nis'] 			= $row->nis;
				$isi['nisn'] 			= $row->nisn;
				$isi['nama'] 			= $row->nama;
				$isi['tempat'] 			= $row->tempat_lahir;
				$isi['tgl'] 			= $row->tgl_lahir;
				$isi['jenis'] 			= $row->jenis_kelamin;
				$isi['agama'] 			= $row->agama;
				$isi['status'] 			= $row->status_dalam_keluarga;
				$isi['anak'] 			= $row->anak_ke;
				$isi['alamat'] 			= $row->alamat_siswa;
				$isi['no'] 				= $row->no_telp_siswa;
				$isi['sekolah'] 		= $row->sekolah_asal;
				$isi['kelas'] 			= $row->kelas;
				$isi['pada'] 			= $row->pada_tanggal;
				$isi['ayah'] 			= $row->nama_ayah;
				$isi['ibu'] 			= $row->nama_ibu;
				$isi['alamat_ortu'] 	= $row->alamat_ortu;
				$isi['no_ortu'] 		= $row->no_telp_ortu;
				$isi['pekerjaan_ayah'] 	= $row->pekerjaan_ayah;
				$isi['pekerjaan_ibu'] 	= $row->pekerjaan_ibu;
				$isi['wali'] 			= $row->nama_wali;
				$isi['alamat_wali'] 	= $row->alamat_wali;
				$isi['no_wali'] 		= $row->no_telp_wali;
				$isi['pekerjaan_wali'] 	= $row->pekerjaan_wali;
				$isi['id_tahunpelajaran'] 	= $row->tahun_pelajaran;
			}
		}
		$this->load->view('siswa/tampilan_home',$isi);
	}

	public function edit()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'siswa/tampilan_editprofil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Edit Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$key = $this->session->userdata('nis');
		$this->db->where('nis',$key);
		$query = $this->db->get('siswa');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nis'] 			= $row->nis;
				$isi['nisn'] 			= $row->nisn;
				$isi['nama'] 			= $row->nama;
				$isi['tempat'] 			= $row->tempat_lahir;
				$isi['tgl'] 			= $row->tgl_lahir;
				$isi['jenis'] 			= $row->jenis_kelamin;
				$isi['agama'] 			= $row->agama;
				$isi['status'] 			= $row->status_dalam_keluarga;
				$isi['anak'] 			= $row->anak_ke;
				$isi['alamat'] 			= $row->alamat_siswa;
				$isi['no'] 				= $row->no_telp_siswa;
				$isi['sekolah'] 		= $row->sekolah_asal;
				$isi['kelas'] 			= $row->id_kelas;
				$isi['pada'] 			= $row->pada_tanggal;
				$isi['ayah'] 			= $row->nama_ayah;
				$isi['ibu'] 			= $row->nama_ibu;
				$isi['alamat_ortu'] 	= $row->alamat_ortu;
				$isi['no_ortu'] 		= $row->no_telp_ortu;
				$isi['pekerjaan_ayah'] 	= $row->pekerjaan_ayah;
				$isi['pekerjaan_ibu'] 	= $row->pekerjaan_ibu;
				$isi['wali'] 			= $row->nama_wali;
				$isi['alamat_wali'] 	= $row->alamat_wali;
				$isi['no_wali'] 		= $row->no_telp_wali;
				$isi['pekerjaan_wali'] 	= $row->pekerjaan_wali;
				$isi['id_tahunpelajaran'] 	= $row->id_tahunpelajaran;
			}
		}
		$this->load->view('siswa/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('nis');
		$data['nis']					= $this->input->post('nis');
		$data['nisn']					= $this->input->post('nisn');
		$data['nama']					= $this->input->post('nama');
		$data['tempat_lahir'] 			= $this->input->post('tempat');
		$data['tgl_lahir'] 				= $this->input->post('tgl');
		$data['jenis_kelamin'] 			= $this->input->post('jenis');
		$data['agama'] 					= $this->input->post('agama');
		$data['status_dalam_keluarga'] 	= $this->input->post('status');
		$data['anak_ke'] 				= $this->input->post('anak');
		$data['alamat_siswa'] 			= $this->input->post('alamat');
		$data['no_telp_siswa'] 			= $this->input->post('no');
		$data['sekolah_asal'] 			= $this->input->post('sekolah');			
		$data['id_kelas'] 				= $this->input->post('kelas');
		$data['pada_tanggal'] 			= $this->input->post('pada');
		$data['nama_ayah'] 				= $this->input->post('ayah');
		$data['nama_ibu'] 				= $this->input->post('ibu');
		$data['alamat_ortu'] 			= $this->input->post('alamat_ortu');
		$data['no_telp_ortu'] 			= $this->input->post('no_ortu');
		$data['pekerjaan_ayah'] 		= $this->input->post('pekerjaan_ayah');
		$data['pekerjaan_ibu'] 			= $this->input->post('pekerjaan_ibu');
		$data['nama_wali'] 				= $this->input->post('wali');
		$data['alamat_wali'] 			= $this->input->post('alamat_wali');
		$data['no_telp_wali'] 			= $this->input->post('no_wali');
		$data['pekerjaan_wali'] 		= $this->input->post('pekerjaan_wali');
		$data['id_tahunpelajaran'] 		= $this->input->post('id_tahunpelajaran');
		

		$this->load->model('model_siswa');
		
			$this->model_siswa->getupdate($key,$data);
			$this->model_siswa->update($key,$data);	
			//echo "Data Berhasil di Perbaharui";
			$this->session->set_userdata('nama',$this->input->post('nama'));

			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
			redirect(base_url().'home_siswa/edit');
	}

	public function password()
	{
		$this->model_squrity->getsqurity();
		$this->load->model('model_profil');
		$this->model_profil->set_password($this->input->post('pass_lama'));
			
		$query = $this->model_profil->view_by_password();
			
			if($query->num_rows())
			{
			$this->model_profil->set_username($this->input->post('user'));
			$this->model_profil->set_password_baru($this->input->post('pass_baru'));
			$this->model_profil->update_p();
			$this->session->set_userdata('username',$this->input->post('user'));
			//echo "Data Berhasil di Perbaharui";
			//redirect(base_url().'profil_dosen/index/success');
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		
			
			} else{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Gagal di Perbaharui</div>');
				
					//echo "Data Gaga-l di Perbaharui";
				//redirect(site_url().'profil_dosen/index/error_save');
			}
			redirect(base_url().'home_siswa/edit');
	}

	public function foto()
	{
		$this->model_squrity->getsqurity();

		if(!empty($_FILES['foto']['name'])){
			$config['upload_path'] = realpath('assets/avatars/');
			$config['allowed_types'] = 'jpg|jpeg|png';
			$config['max_size']  = '2000000';
			$config['file_name'] = 'nis_'.$this->input->post('nis').'_'.date('Ymd').date('Hms');//$_FILES['foto']['name'];
			$config['overwrite'] = true;
     		
			$this->load->library('upload',$config);
			if (!$this->upload->do_upload('foto')){
				$this->session->set_flashdata('pesan','error:<b>'.$this->upload->display_errors().'<b>.');
				redirect(base_url().'home_siswa');
			}
			else{
				$key = $this->session->userdata('id_pengguna');
				$f=$this->upload->data();
				$file=realpath('assets/avatars/').'/'.$this->session->userdata('foto');
				if(file_exists($file)){
					unlink(realpath('assets/avatars/').'/'.$this->session->userdata('foto'));
				}
				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan'),
				  			'foto'			=> $f['orig_name']
				  			);
			}
		} else{
				$key = $this->session->userdata('id_pengguna');

				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan')
				  			);
			}
		
		$key = $this->session->userdata('id_pengguna');
		$this->load->model('model_profil');
		$this->model_profil->getupdate($key,$data);
		$this->session->set_userdata('foto',$f['orig_name']);
		$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		redirect(base_url().'home_siswa/edit');
	}

	function loaddata()
    {
    	$this->model_squrity->getsqurity();
        $nis      =  $this->session->userdata('nis');
       	$id_kelas = $_GET['id_kelas'];
       	$this->load->model('model_nilaiakhir');
		$kelas_siswa = $this->model_nilaiakhir->data($nis,$id_kelas);
     	if($kelas_siswa->num_rows() > 0){
             foreach ($kelas_siswa->result() as $d) 
       		{
       	    
		        echo '
						<input type="text" name="id_kelassiswa" hidden id="id_kelassiswa" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$d->id_kelassiswa.'>
						<input type="text" name="id_tahunpelajaran" hidden id="id_tahunpelajaran" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$d->id_tahunpelajaran.'>
				        <table class="table table-bordered" id="daftarkrs">
				        <tr>
				            <td>NAMA</td><td>'.  strtoupper($d->nama).'</td>
				            <td>NIS</td><td>'.  strtoupper($d->nis).'</td>
				        </tr>
				        <tr>
				            <td>Kelas, Tahun Pelajaran</td><td>'.  strtoupper($d->kelas.' / '.$d->tahun_pelajaran).'</td>
				            <td>Wali Kelas</td><td>'.$d->guru.'</td>
				        </tr>
				        </table>

				       	';
	       }
		}
		else{
			echo '';
		}
       
    }

	function loadnilai()
    {
    	$this->model_squrity->getsqurity();

        $nis             		=  $this->session->userdata('nis');
        $id_tahunpelajaran  	=  $_GET['id_tahunpelajaran'];
        $id_kelas             	=  $_GET['id_kelas'];
        $semester             	=  $_GET['semester'];
        
       	$this->load->model('model_nilaiakhir');
		$nilai = $this->model_nilaiakhir->nilai($nis,$id_kelas,$id_tahunpelajaran,$semester);
       
       if ($nilai) {
         
        if($nilai->num_rows() > 0)
        {
        		echo '

       	<table class="table table-bordered" id="daftarkrs">
        <tr><th width="5">No</th>
        <th>Nama Mata Pelajaran</th>
        <th>Nilai Rata-Rata Harian</th>
        <th>Nilai UTS</th>
        <th>Nilai UAS</th>
        <th>Nilai Akhir</th>
        <th width="10">Lihat Lengkap</th></tr>';
             $no=1;
            
            foreach ($nilai->result() as $r)
            {
            	
        
                echo " <tr id='id_nilaiakhirhide$r->id_nilaiakhir'>
                            <td>$no</td>
                            <td>".  strtoupper($r->nama_mapel)."</td>
                            <td>".  $r->nilai_rataharian."</td>
                            <td>".  $r->nilai_uts."</td>
                            <td>".  $r->nilai_uas."</td>
                            <td>".  $r->nilai_akhir."</td>
                            <td align='center'><i class='fa fa-eye' onclick='input($r->id_nilaiakhir)' title='Lihat Nilai'></i></td></tr>";
				
                $no++;
             
            }
            echo"<tr>
        <td colspan=7>".anchor('cetak/nilai/'.$nis.'/'.$id_tahunpelajaran.'/'.$id_kelas.'/'.$semester,'<i class="ace-icon fa fa-print"></i> Cetak Nilai',array('class'=>'btn btn-danger btn-sm'));
      
        echo"</td>
        </tr></table>";
        }
        else { echo '<table><tr><td colspan=7>DATA TIDAK DITEMUKAN</td></tr></table>'; }
         }
        else { echo ""; }
    }

    public function cek()
	{
		$this->model_squrity->getsqurity();
		$id_nilaiakhir 	= $_GET['id_nilaiakhir'];
		$this->load->model('model_nilaiakhir');
		$pernil = $this->model_nilaiakhir->pernil($id_nilaiakhir);
			if($pernil)
			{
				foreach ($pernil as $key) 
				{
					echo '
					<form class="form-horizontal">
					<div class="form-group">
					<label class="col-sm-4 control-label">Nama Mata Pelajaran</label>
					<div class="col-sm-6">
						<label class="control-label">: '. $key->nama_mapel .'</label>
					</div>	
					</div>
					<div class="form-group">
					<label class="col-sm-4 control-label">Nilai KKM</label>
					<div class="col-sm-2">
						<label class="control-label">: '. $key->nilai_kkm .'</label>
					</div>	
					</div>
						<input type="text" name="id_nilaiakhir" hidden id="id_nilaiakhir" placeholder="Masukkan Nilai KKM" class="col-sm-5" value='.$key->id_nilaiakhir.'>

						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 1</label>
							<div class="col-sm-2">
							<label class="control-label">: '.$key->nilai_harian1.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 2</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_harian2.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 3</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_harian3.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Harian Ke 4</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_harian4.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Rata-Rata Harian</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_rataharian.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Tengah Semester</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_uts.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Nilai Ulangan Akhir Semester</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_uas.'</label>
							</div>	
						</div><div class="form-group">
							<label class="col-sm-4 control-label">Nilai Akhir</label>
							<div class="col-sm-2">
								<label class="control-label">: '.$key->nilai_akhir.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Angka</label>
							<div class="col-sm-8">
								<label class="control-label">: '.$key->angka.'</label>
							</div>	
						</div>
						<div class="form-group">
							<label class="col-sm-4 control-label">Catatan Guru</label>
							<div class="col-sm-8">
								<label class="control-label">: '.$key->catatan_guru.'</label>
							</div>	
						</div>';
					
				}	
				echo '<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9"><button type="button" onclick="loadjurusan()" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</button></div></div></form>'; 
			}
		else { echo ''; }	 	
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url().'login');
	}
}
