<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kelas_siswa extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$this->load->model('model_kelassiswa');
		$isi['content'] 			= 'admin/kelas_siswa/tampil_datakelassiswa';
		$isi['judul']				= 'Transaksi';
		$isi['sub_judul']			= 'Kelas Siswa';
		$isi['icon']				= 'class="ace-icon fa fa-shopping-cart home-icon"';
		$isi['id_kelassiswa'] 		= '';
		$isi['id_kelas'] 			= '';
		$isi['id_tahunpelajaran'] 	= '';
		$isi['nip'] 				= '';
		$isi['nis'] 				= ''; 
		$isi['data']				= $this->model_kelassiswa->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function kelas()
	{
		$id_tahunpelajaran 	= $this->input->post('id_tahunpelajaran');
		if($id_tahunpelajaran){
			$this->load->model('model_kelassiswa');
			$kelas = $this->model_kelassiswa->kelas($id_tahunpelajaran);
			echo '<option value="0">--Pilih Kelas--</option>';
			foreach ($kelas as $key) {
					echo '<option value="'. $key->id_kelas .'">'. $key->kelas .'</option>';
				}	
		} else {
			echo '<option value="0">--Pilih Kelas--</option>';
		}
	}

	public function nama()
	{
		$id_kelas 	= $this->input->post('id_kelas');
		if($id_kelas){
			$this->load->model('model_kelassiswa');
			$kelas = $this->model_kelassiswa->nip($id_kelas);
		
			foreach ($kelas as $key) {
					echo '<label>'. $key->nama .'</label>';
				}	
		} else {
			echo '<label>-</label>';
		}
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/kelas_siswa/form_tambahkelassiswa';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'Tampil Data Kelas Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';

		$key = $this->uri->segment(3);
		$query = $this->db->query("SELECT
						siswa.nama AS siswa,
						siswa.nis,
						kelas.kelas AS kelas,
						guru.nama AS guru,
						tahun_pelajaran.tahun_pelajaran,
						kelas_siswa.id_kelas,
						kelas_siswa.id_kelassiswa
					FROM
						kelas_siswa
					RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
					LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
					LEFT JOIN guru ON kelas.nip = guru.nip
					INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
					WHERE
						kelas.id_kelas=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				
				$isi['kelas'] 	= $row->kelas;
				$isi['guru'] 	= $row->guru;
				$isi['tahun_pelajaran'] 	= $row->tahun_pelajaran;
				$isi['query'] = $query;
			}
		}
		else
		{
				$isi['kelas'] 	= '';
				$isi['guru'] 	= '';
				$isi['tahun_pelajaran'] 	= '';
				$isi['query'] = $query;
			
		}

		
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/kelas_siswa/form_editkelassiswa';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'Edit Kelas Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';

		$key = $this->uri->segment(3);
		$query = $this->db->query("SELECT
						siswa.nama AS siswa,
						siswa.nis,
						kelas.kelas AS kelas,
						guru.nama AS guru,
						tahun_pelajaran.tahun_pelajaran,
						kelas.id_kelas,
						kelas.id_tahunpelajaran
					FROM
						kelas_siswa
					RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
					LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
					LEFT JOIN guru ON kelas.nip = guru.nip
					INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
					WHERE
						kelas.id_kelas=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_tahunpelajaran'] 	= $row->id_tahunpelajaran;
				$isi['id_kelas'] = $row->id_kelas;
				$isi['tahun_pelajaran'] 	= $row->tahun_pelajaran;
				$isi['kelas'] 	= $row->kelas;
				$isi['guru'] 	= $row->guru;
				$isi['nis'] 	= $row->nis;
			}
		}
		else
		{

			$isi['id_tahunpelajaran'] 	= '';
			$isi['tahun_pelajaran'] 	= '';
			$isi['id_kelas'] 	= '';
			$isi['kelas'] = '';
			$isi['guru'] 	= '';
			$isi['nis'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();
		
		$id_kelassiswa = $this->input->post('id_kelassiswa');
		$id_kelas = $this->input->post('id_kelas');

		foreach($this->input->post('nis') as $nis) {
	
     		$data = array('id_kelassiswa' => $id_kelassiswa,
     						'id_kelas' => $id_kelas,
     						'nis' => $nis);
			
     		$this->load->model('model_kelassiswa');
     		$query = $this->model_kelassiswa->getdata($id_kelas,$nis);
     		if($query->num_rows()>0)
			{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Maaf data sudah ada</div>
					');
			}
			else
			{
				$this->model_kelassiswa->getinsert($data);
				$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Simpan</div>');
			}
		}
		
		redirect(base_url().'kelas_siswa');
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/kelas_siswa/form_tampilkelasiswa';
		$isi['judul']		= 'Transaksi';
		$isi['sub_judul']	= 'Tampil Data Kelas Siswa';
		$isi['icon']		= 'class="ace-icon fa fa-shopping-cart home-icon"';

		$key = $this->uri->segment(3);
		$query = $this->db->query("SELECT
						siswa.nama AS siswa,
						siswa.nis,
						kelas.kelas AS kelas,
						guru.nama AS guru,
						tahun_pelajaran.tahun_pelajaran,
						kelas_siswa.id_kelas
					FROM
						kelas_siswa
					RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
					LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
					LEFT JOIN guru ON kelas.nip = guru.nip
					INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
					WHERE
						kelas.id_kelas=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				
				$isi['kelas'] 	= $row->kelas;
				$isi['guru'] 	= $row->guru;
				$isi['tahun_pelajaran'] 	= $row->tahun_pelajaran;
				$isi['query'] = $query;
			}
		}
		else
		{
				$isi['kelas'] 	= '';
				$isi['guru'] 	= '';
				$isi['tahun_pelajaran'] 	= '';
				$isi['query'] = $query;
			
		}

		
		$this->load->view('admin/tampilan_home',$isi);
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_kelassiswa');
		$key = $this->uri->segment(3);
		$this->db->where('id_kelas',$key);
		$query = $this->db->get('kelas_siswa');
		if($query->num_rows()>0)
		{
			$this->model_kelassiswa->getdelete($key);
		}
		redirect(base_url().'kelas_siswa');
	}

	public function del()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_kelassiswa');
		$key = $this->uri->segment(3);
		$this->db->where('id_kelassiswa',$key);
		$query = $this->db->get('kelas_siswa');
		if($query->num_rows()>0)
		{
			$this->model_kelassiswa->del($key);
		}
		redirect(base_url().'kelas_siswa');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 