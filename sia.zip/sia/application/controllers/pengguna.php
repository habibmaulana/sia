<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pengguna extends CI_Controller {

	public function index()
	{
		$this->load->model('model_pengguna');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/pengguna/tampil_datapengguna';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->model_pengguna->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/pengguna/form_tambahpengguna';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tambah Data Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['id_pengguna'] = '';
		$isi['username'] 	= '';
		$isi['password'] 	= '';
		$isi['nama'] 		= '';
		$isi['nis'] 		= '';
		$isi['nip'] 		= '';
		$isi['id_jabatan'] 	= '';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/pengguna/form_tampilpengguna';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tampil Data Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		
		$key = $this->uri->segment(3);
		$query = $this->db->query("SELECT
					pengguna.*,
					jabatan.id_jabatan,
					jabatan.jabatan
				FROM
					pengguna,
					jabatan
				WHERE 
					pengguna.id_jabatan = jabatan.id_jabatan and pengguna.id_pengguna=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_pengguna'] = $row->id_pengguna;
				$isi['username'] 	= $row->username;
				$isi['password'] 	= md5($row->password);
				$isi['nama'] 	= $row->nama;
				$isi['nis'] 	= $row->nis;
				$isi['nip'] 	= $row->nip;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['foto'] 	= $row->foto;
			}
		}
		else
		{
			$isi['id_pengguna'] = '';
			$isi['username'] 	= '';
			$isi['password'] 	= '';
			$isi['nama'] 	= '';
			$isi['nis'] 	= '';
			$isi['nip'] 	= '';
			$isi['jabatan'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/pengguna/form_editpengguna';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Edit Data Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		
		$key = $this->uri->segment(3);
		
		$query = $this->db->query("SELECT
					pengguna.*,
					jabatan.id_jabatan,
					jabatan.jabatan
				FROM
					pengguna,
					jabatan
				WHERE 
					pengguna.id_jabatan = jabatan.id_jabatan and pengguna.id_pengguna=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['id_pengguna'] = $row->id_pengguna;
				$isi['username'] 	= $row->username;
				$isi['password'] 	= md5($row->password);
				$isi['nama'] 	= $row->nama;
				$isi['nis'] 	= $row->nis;
				$isi['nip'] 	= $row->nip;
				$isi['id_jabatan'] 	= $row->id_jabatan;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['foto'] 	= $row->foto;
			}
		}
		else
		{
			$isi['id_pengguna'] = '';
			$isi['username'] 	= '';
			$isi['password'] 	= '';
			$isi['nama'] 	= '';
			$isi['nis'] 	= '';
			$isi['nip'] 	= '';
			$isi['id_jabatan'] 	= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();


		if(!empty($_FILES['foto']['name'])){
			$config['upload_path'] = realpath('assets/avatars/');
			$config['allowed_types'] = 'jpg|jpeg|png';
			$config['max_size']  = '2000000';
			$config['file_name'] ='pengguna_'.$this->input->post('nama').'_'.date('Ymd').date('Hms');
			$config['overwrite'] = true;
     		
			$this->load->library('upload',$config);
			if (!$this->upload->do_upload('foto')){
				$this->session->set_flashdata('pesan','<div class="alert alert-danger">
											<button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button> error:'.$this->upload->display_errors('foto').'</div>');
				redirect(base_url().'pengguna/tambah');
			}
			else{
				$key = $this->input->post('id_pengguna');
				$f=$this->upload->data();
				
				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			'password' 		=> md5($this->input->post('password')),
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan'),
				  			'foto'			=> $f['orig_name']
				  			);
			}
		} else{
				$key = $this->input->post('id_pengguna');

				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			'password' 		=> md5($this->input->post('password')),
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan')
				  			);
			}
		

		$this->load->model('model_pengguna');
		$query = $this->model_pengguna->getdata($key);
		
		if($query->num_rows()>0)
		{	
			
			$this->model_pengguna->update($nip,$data);
			$this->model_pengguna->updat($nis,$data);
			$this->model_pengguna->getupdate($key,$data);
			$this->session->set_userdata('nama',$this->input->post('nama'));
			//echo "Data Berhasil di Perbaharui";
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data '.$this->input->post('nama').' Sudah Diperbaharui </div>');
		}
		else
		{ $this->model_pengguna->getinsert($data);
			/*$result = mysql_query($query);
			while ($row = mysql_fetch_object($result)) {
				
			}
			foreach ($query->result() as $row) 
		{
			$nip = $row->nip;
			$nis = $row->nis;
			}*/
			if($data['nis']==0){
				/*if($data['nip']==$nip){
					
					$this->model_pengguna->update($nip,$data);
					
					}
				else{ */
				$this->model_pengguna->insert($data);
			//}
			}
			elseif ($data['nip']==0)
			{
				/*if($data['nis']==$nis){
					
					$this->model_pengguna->updat($nis,$data);
					
					}
				else{
			*/
				$this->model_pengguna->insertsiswa($data);
				
			//}
			}
			//echo "Data Berhasil di Simpan";
		//}	
		$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data '.$this->input->post('nama').' Sudah Tersimpan </div>');
	}
		redirect(base_url().'pengguna/tambah');
	}
		
	public function tugas_mengajar()
	{
		$this->model_squrity->getsqurity();
		$id_jabatan 	= $_GET['id_jabatan'];
		
		$key="SELECT * FROM mapel";
		$b = $this->db->query($key)->result();

		if($id_jabatan > 0 && $id_jabatan <= 10){
			echo "<label class='col-sm-2 control-label'>Tugas Mengajar</label>
					<div class='col-sm-2'>
						 <select class='form-control' type='text' id='id_mapel' name='id_mapel' required>
			         		<option value='0'>--Pilih Mata Pelajaran--</option>";

			foreach ($b as $key) {
				echo '<option value="'. $key->id_mapel .'">'. $key->nama_mapel .'</option>';
						
				}	
		echo '</select></div>';
		}
		else {
			echo '';
		}	 
		
	}

	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_pengguna');
		$key = $this->uri->segment(3);
		$this->db->where('id_pengguna',$key);
		$query = $this->db->get('pengguna');
		
		
		foreach ($query->result() as $q) {
			unlink(realpath('assets/avatars/') . $q->foto);

			$nip = $q->nip;
			$nis = $q->nis;
			
		
			$this->model_pengguna->getdelete($key);
			$this->model_pengguna->delete($nip);
			$this->model_pengguna->elete($nip);
			$this->model_pengguna->delet($nis);
			$this->model_pengguna->dele($nis);
			$this->model_pengguna->hapus($nis);
			
		$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sudah Dihapus </div>');
		redirect(base_url().'pengguna');
		}
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 