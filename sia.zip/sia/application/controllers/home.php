<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tampilan_content';
		$isi['judul']		= 'home';
		$isi['sub_judul']	= '';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function profil()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tampilan_profil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Data Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-home home-icon"';
		$key = $this->session->userdata('nip');
		$query = $this->db->query("SELECT
									guru.*,
									mapel.nama_mapel,
									jabatan.jabatan
								FROM
									guru,
									jabatan,
									mapel
								WHERE
									guru.id_jabatan = jabatan.id_jabatan
								AND guru.id_mapel = mapel.id_mapel
								and guru.nip=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->nama_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		} else
		{
			$isi['nip'] 		= '';
				$isi['nama'] 		= '';
				$isi['nuptk'] 		= '';
				$isi['nrg'] 		= '';
				$isi['tempat'] 		= '';
				$isi['tgl'] 		= '';
				$isi['pangkat'] 	= '';
				$isi['jabatan'] 	= '';
				$isi['jenis'] 		= '';
				$isi['status'] 		= '';
				$isi['tmt'] 		= '';
				$isi['tahun'] 		= '';
				$isi['bulan'] 		= '';
				$isi['jenjang'] 	= '';
				$isi['jurusan'] 	= '';
				$isi['mapel'] 		= '';
				$isi['jml'] 		= '';
				$isi['tahunser'] 	= '';
				$isi['noser'] 		= '';
				$isi['mapser'] 		= '';
				$isi['desa'] 		= '';
				$isi['kel'] 		= '';
				$isi['kec'] 		= '';
				$isi['no'] 			= '';
				$isi['pensiun'] 	= '';
				$isi['npwp'] 		= '';
				$isi['ket'] 		= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/tampilan_editprofil';
		$isi['judul']		= 'Profil';
		$isi['sub_judul']	= 'Edit Profil Pengguna';
		$isi['icon']		= 'class="ace-icon fa fa-pencil-square-o home-icon"';
		$key = $this->session->userdata('nip');
		$this->db->where('nip',$key);
		$query = $this->db->get('guru');
		$query = $this->db->query("SELECT
									guru.*,
									jabatan.jabatan
									FROM
									guru ,
									jabatan
									WHERE
									guru.id_jabatan = jabatan.id_jabatan
									 and guru.nip=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['id_jabatan'] 	= $row->id_jabatan;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->id_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		} else
		{
			$isi['nip'] 		= '';
				$isi['nama'] 		= '';
				$isi['nuptk'] 		= '';
				$isi['nrg'] 		= '';
				$isi['tempat'] 		= '';
				$isi['tgl'] 		= '';
				$isi['pangkat'] 	= '';
				$isi['jabatan'] 	= '';
				$isi['jenis'] 		= '';
				$isi['status'] 		= '';
				$isi['tmt'] 		= '';
				$isi['tahun'] 		= '';
				$isi['bulan'] 		= '';
				$isi['jenjang'] 	= '';
				$isi['jurusan'] 	= '';
				$isi['mapel'] 		= '';
				$isi['jml'] 		= '';
				$isi['tahunser'] 	= '';
				$isi['noser'] 		= '';
				$isi['mapser'] 		= '';
				$isi['desa'] 		= '';
				$isi['kel'] 		= '';
				$isi['kec'] 		= '';
				$isi['no'] 			= '';
				$isi['pensiun'] 	= '';
				$isi['npwp'] 		= '';
				$isi['ket'] 		= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('nip');
		$data['nip']				= $this->input->post('nip');
		$data['nama']				= $this->input->post('nama');
		$data['nuptk']				= $this->input->post('nuptk');
		$data['nrg']				= $this->input->post('nrg');
		$data['tempat_lahir']		= $this->input->post('tempat');
		$data['tgl_lahir']			= $this->input->post('tgl');
		$data['pangkat']			= $this->input->post('pangkat');
		$data['id_jabatan']			= $this->input->post('id_jabatan');
		$data['jenis_kelamin']		= $this->input->post('jenis');
		$data['status_guru']		= $this->input->post('status');
		$data['tmt']				= $this->input->post('tmt');
		$data['masa_tahun']			= $this->input->post('tahun');
		$data['masa_bulan']			= $this->input->post('bulan');
		$data['jenjang']			= $this->input->post('jenjang');
		$data['jurusan']			= $this->input->post('jurusan');
		$data['id_mapel']			= $this->input->post('mapel');
		$data['jml_jam_mengajar']	= $this->input->post('jml');
		$data['tahun_sertifikasi']	= $this->input->post('tahunser');
		$data['no_sertifikasi']		= $this->input->post('noser');
		$data['mapel_sertifikasi']	= $this->input->post('mapser');
		$data['desa']				= $this->input->post('desa');
		$data['kelurahan']			= $this->input->post('kel');
		$data['kecamatan']			= $this->input->post('kec');
		$data['no_telp_rmh']		= $this->input->post('no');
		$data['pensiun']			= $this->input->post('pensiun');
		$data['npwp']				= $this->input->post('npwp');
		$data['ket']				= $this->input->post('ket');
		

		$this->load->model('model_guru');
		
			$this->model_guru->getupdate($key,$data);
			$this->model_guru->update($key,$data);	
			$this->session->set_userdata('nama',$this->input->post('nama'));
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		
			redirect(base_url().'home/edit');
	}

	public function password()
	{
		$this->model_squrity->getsqurity();
		$this->load->model('model_profil');
		$this->model_profil->set_password($this->input->post('pass_lama'));
			
		$query = $this->model_profil->view_by_password();
			
			if($query->num_rows())
			{
			$this->model_profil->set_username($this->input->post('user'));
			$this->model_profil->set_password_baru($this->input->post('pass_baru'));
			$this->model_profil->update_p();
			$this->session->set_userdata('username',$this->input->post('user'));
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		
			
			} else{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Gagal di Perbaharui</div>');
			}
			redirect(base_url().'home/edit');
	}

	public function foto()
	{
		$this->model_squrity->getsqurity();

		if(!empty($_FILES['foto']['name'])){
			$config['upload_path'] = realpath('assets/avatars/');
			$config['allowed_types'] = 'jpg|jpeg|png';
			$config['max_size']  = '2000000';
			$config['file_name'] = 'nip_'.$this->input->post('nip').'_'.date('Ymd').date('Hms');//$_FILES['foto']['name'];
			$config['overwrite'] = true;
     		
			$this->load->library('upload',$config);
			if (!$this->upload->do_upload('foto')){
				$this->session->set_flashdata('pesan','error:<b>'.$this->upload->display_error().'</b>');
				redirect(base_url().'home/edit');
			}
			else{
				$key = $this->session->userdata('id_pengguna');
				$f=$this->upload->data();
				$file=realpath('assets/avatars/').'/'.$this->session->userdata('foto');
				if(file_exists($file)){
					unlink(realpath('assets/avatars/').'/'.$this->session->userdata('foto'));
				}
				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan'),
				  			'foto'			=> $f['orig_name']
				  			);
			}
		} else{
				$key = $this->session->userdata('id_pengguna');

				$data=array('id_pengguna' 	=> $this->input->post('id_pengguna'),
				  			'username'		=> $this->input->post('username'),
				  			
				  			'nama' 			=> $this->input->post('nama'),
				  			'nis'			=> $this->input->post('nis'),
				  			'nip'			=> $this->input->post('nip'),
				  			'id_jabatan'	=> $this->input->post('id_jabatan')
				  			);
			}
		
		$key = $this->session->userdata('id_pengguna');
		$this->load->model('model_profil');
		$this->model_profil->getupdate($key,$data);
		$this->session->set_userdata('foto',$f['orig_name']);
		$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		redirect(base_url().'home/edit');
		
	}
		
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url().'login');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 