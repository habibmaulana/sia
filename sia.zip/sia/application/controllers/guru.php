<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Guru extends CI_Controller {

	public function index()
	{
		$this->load->model('model_guru');
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/guru/tampil_dataguru';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Guru';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['data']		= $this->model_guru->data();
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tambah()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/guru/form_tambahguru';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tambah Guru';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';
		$isi['nip'] 		= '';
		$isi['nama'] 		= '';
		$isi['nuptk'] 		= '';
		$isi['nrg'] 		= '';
		$isi['tempat'] 		= '';
		$isi['tgl'] 		= '';
		$isi['pangkat'] 	= '';
		$isi['jabatan'] 	= '';
		$isi['jenis'] 		= '';
		$isi['status'] 		= '';
		$isi['tmt'] 		= '';
		$isi['tahun'] 		= '';
		$isi['bulan'] 		= '';
		$isi['jenjang'] 	= '';
		$isi['alamat'] 		= '';
		$isi['jurusan'] 	= '';
		$isi['mapel'] 		= '';
		$isi['jml'] 		= '';
		$isi['tahunser'] 	= '';
		$isi['noser'] 		= '';
		$isi['mapser'] 		= '';
		$isi['desa'] 		= '';
		$isi['kel'] 		= '';
		$isi['kec'] 		= '';
		$isi['no'] 			= '';
		$isi['pensiun'] 	= '';
		$isi['npwp'] 		= '';
		$isi['ket'] 		= '';
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function tampil()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/guru/form_tampilguru';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Tampil Data guru';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
		$query = $this->db->query("SELECT
									guru.*,
									mapel.nama_mapel,
									jabatan.jabatan
								FROM
									guru,
									jabatan,
									mapel
								WHERE
									guru.id_jabatan = jabatan.id_jabatan
								AND guru.id_mapel = mapel.id_mapel
								and guru.nip=$key");
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['jabatan'] 	= $row->jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->nama_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function edit()
	{ 
		$this->model_squrity->getsqurity();
		$isi['content'] 	= 'admin/guru/form_tambahguru';
		$isi['judul']		= 'Master';
		$isi['sub_judul']	= 'Edit Data Guru';
		$isi['icon']		= 'class="ace-icon fa fa-desktop home-icon"';

		$key = $this->uri->segment(3);
	
		$query = $this->db->where('nip',$key)->get('guru');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$isi['nip'] 		= $row->nip;
				$isi['nama'] 		= $row->nama;
				$isi['nuptk'] 		= $row->nuptk;
				$isi['nrg'] 		= $row->nrg;
				$isi['tempat'] 		= $row->tempat_lahir;
				$isi['tgl'] 		= $row->tgl_lahir;
				$isi['pangkat'] 	= $row->pangkat;
				$isi['jabatan'] 	= $row->id_jabatan;
				$isi['jenis'] 		= $row->jenis_kelamin;
				$isi['status'] 		= $row->status_guru;
				$isi['tmt'] 		= $row->tmt;
				$isi['tahun'] 		= $row->masa_tahun;
				$isi['bulan'] 		= $row->masa_bulan;
				$isi['jenjang'] 	= $row->jenjang;
				$isi['jurusan'] 	= $row->jurusan;
				$isi['mapel'] 		= $row->id_mapel;
				$isi['jml'] 		= $row->jml_jam_mengajar;
				$isi['tahunser'] 	= $row->tahun_sertifikasi;
				$isi['noser'] 		= $row->no_sertifikasi;
				$isi['mapser'] 		= $row->mapel_sertifikasi;
				$isi['desa'] 		= $row->desa;
				$isi['kel'] 		= $row->kelurahan;
				$isi['kec'] 		= $row->kecamatan;
				$isi['no'] 			= $row->no_telp_rmh;
				$isi['pensiun'] 	= $row->pensiun;
				$isi['npwp'] 		= $row->npwp;
				$isi['ket'] 		= $row->ket;
			}
		}
		else
		{
				$isi['nip'] 		= '';
				$isi['nama'] 		= '';
				$isi['nuptk'] 		= '';
				$isi['nrg'] 		= '';
				$isi['tempat'] 		= '';
				$isi['tgl'] 		= '';
				$isi['pangkat'] 	= '';
				$isi['jabatan'] 	= '';
				$isi['jenis'] 		= '';
				$isi['status'] 		= '';
				$isi['tmt'] 		= '';
				$isi['tahun'] 		= '';
				$isi['bulan'] 		= '';
				$isi['jenjang'] 	= '';
				$isi['alamat'] 		= '';
				$isi['jurusan'] 	= '';
				$isi['mapel'] 		= '';
				$isi['jml'] 		= '';
				$isi['tahunser'] 	= '';
				$isi['noser'] 		= '';
				$isi['mapser'] 		= '';
				$isi['desa'] 		= '';
				$isi['kel'] 		= '';
				$isi['kec'] 		= '';
				$isi['no'] 			= '';
				$isi['pensiun'] 	= '';
				$isi['npwp'] 		= '';
				$isi['ket'] 		= '';
		}
		$this->load->view('admin/tampilan_home',$isi);
	}

	public function simpan()
	{
		$this->model_squrity->getsqurity();

		$key = $this->input->post('nip');
		$data['nip']				= $this->input->post('nip');
		$data['nama']				= $this->input->post('nama');
		$data['nuptk']				= $this->input->post('nuptk');
		$data['nrg']				= $this->input->post('nrg');
		$data['tempat_lahir']		= $this->input->post('tempat');
		$data['tgl_lahir']			= $this->input->post('tgl');
		$data['pangkat']			= $this->input->post('pangkat');
		$data['id_jabatan']			= $this->input->post('jabatan');
		$data['jenis_kelamin']		= $this->input->post('jenis');
		$data['status_guru']		= $this->input->post('status');
		$data['tmt']				= $this->input->post('tmt');
		$data['masa_tahun']			= $this->input->post('tahun');
		$data['masa_bulan']			= $this->input->post('bulan');
		$data['jenjang']			= $this->input->post('jenjang');
		$data['jurusan']			= $this->input->post('jurusan');
		$data['id_mapel']			= $this->input->post('mapel');
		$data['jml_jam_mengajar']	= $this->input->post('jml');
		$data['tahun_sertifikasi']	= $this->input->post('tahunser');
		$data['no_sertifikasi']		= $this->input->post('noser');
		$data['mapel_sertifikasi']	= $this->input->post('mapser');
		$data['desa']				= $this->input->post('desa');
		$data['kelurahan']			= $this->input->post('kel');
		$data['kecamatan']			= $this->input->post('kec');
		$data['no_telp_rmh']		= $this->input->post('no');
		$data['pensiun']			= $this->input->post('pensiun');
		$data['npwp']				= $this->input->post('npwp');
		$data['ket']				= $this->input->post('ket');
		

		$this->load->model('model_guru');
		$query = $this->model_guru->getdata($key);
		if($query->num_rows()>0)
		{
			$this->model_guru->getupdate($key,$data);
			$this->model_guru->update($key,$data);	
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Perbaharui</div>');
		}
		else
		{
			$this->model_guru->getinsert($data);
			$this->model_guru->insert($data);
			$this->session->set_flashdata('pesan','<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Sukses Di Simpan</div>');
		}
		redirect(base_url().'guru/tambah');
	}
	
	public function delete()
	{ 
		$this->model_squrity->getsqurity();	
		$this->load->model('model_guru');
		$key = $this->uri->segment(3);
		$this->db->where('nip',$key);
		$query = $this->db->get('guru');
		if($query->num_rows()>0)
		{
			$this->model_guru->getdelete($key);
			$this->model_guru->delete($key);
			$this->model_guru->hapus($key);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>Data Berhasil Di Hapus</div>');
		}

		redirect(base_url().'guru');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */ 