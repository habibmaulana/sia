<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_kkm extends CI_model {

	public function getdata($key)
	{
		$this->db->where('id_kkm',$key);
		$hasil = $this->db->get('nilai_kkm');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_kkm',$key);
		$this->db->update('nilai_kkm',$data);
	}

	public function getinsert($data)
	{
		$this->db->insert('nilai_kkm',$data);
	}

	public function getdelete($key)
	{
		$this->db->where('id_kkm',$key);
		$this->db->delete('nilai_kkm');
	}

	public function delete($key)
	{
		$this->db->where('id_kkm',$key);
		$this->db->delete('nilai_akhirsiswa');
	}

	public function data()
	{
		$data = "SELECT
					nilai_kkm.id_kkm,
					mapel.nama_mapel,
					nilai_kkm.nilai_kkm,
					nilai_kkm.semester,
					tahun_pelajaran.tahun_pelajaran
				FROM
					nilai_kkm,
					mapel,
					tahun_pelajaran
				WHERE
					nilai_kkm.id_mapel = mapel.id_mapel
				AND nilai_kkm.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
				ORDER BY nilai_kkm.semester ASC, tahun_pelajaran.tahun_pelajaran ASC ";
		return $this->db->query($data);
	}	
	
	public function get($key)
	{
		$data = "SELECT
					mapel.nama_mapel,
					nilai_kkm.*,
					tahun_pelajaran.tahun_pelajaran
				FROM
					nilai_kkm
				INNER JOIN mapel ON nilai_kkm.id_mapel = mapel.id_mapel
				INNER JOIN tahun_pelajaran ON nilai_kkm.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
				WHERE
					nilai_kkm.id_kkm = $key";
		return $this->db->query($data);
	}

}

