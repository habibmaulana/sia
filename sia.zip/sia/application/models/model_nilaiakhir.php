<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_nilaiakhir extends CI_model{
	
public function getdata($key)
	{
		$this->db->where('id_nilaiakhir',$key);
	
		$hasil = $this->db->get('nilai_akhirsiswa');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_nilaiakhir',$key);
		$this->db->update('nilai_akhirsiswa',$data);
	}

	public function getinsert($data)
	{
		$this->db->insert('nilai_akhirsiswa',$data);
		
	}

	public function getdelete($key)
	{
		$this->db->where('id_nilaiakhir',$key);
		$this->db->delete('nilai_akhirsiswa');
	}

	public function nilai_kkm($id_tahunpelajaran)
	{
		$nis = $this->db->query("SELECT DISTINCT semester
								FROM
								nilai_kkm");
		if($nis->num_rows() > 0){
			return $nis->result();
		}
		//$this->db->where('id_tahunpelajaran',$id_tahunpelajaran);
		//$hasil = $this->db->get('nilai_kkm');
		//return $hasil;
	}

	public function mapel($id_tahunpelajaran,$semester)
	{	
		
		$mapel = $this->db->query("SELECT
									nilai_kkm.*,
									mapel.nama_mapel
								FROM
									nilai_kkm,
									mapel
								WHERE
									nilai_kkm.id_mapel = mapel.id_mapel
								AND nilai_kkm.semester = '$semester'
								AND nilai_kkm.id_tahunpelajaran =$id_tahunpelajaran 
								ORDER BY
									mapel.nama_mapel ASC
								");
		
			return $mapel;
		
	}

	public function nilai($nis,$id_kelas,$id_tahunpelajaran,$semester)
	{	
		
		$nilai = $this->db->query("SELECT
									nilai_akhirsiswa.*,
									tahun_pelajaran.tahun_pelajaran,
									siswa.nama,
									kelas.kelas,
									nilai_kkm.nilai_kkm,
									nilai_kkm.semester,
									mapel.nama_mapel,
									kelas_siswa.id_kelas
								FROM
									nilai_akhirsiswa
								INNER JOIN siswa ON nilai_akhirsiswa.nis = siswa.nis
								INNER JOIN kelas_siswa ON nilai_akhirsiswa.id_kelassiswa = kelas_siswa.id_kelassiswa
								AND kelas_siswa.nis = siswa.nis
								INNER JOIN kelas ON kelas_siswa.id_kelas = kelas.id_kelas
								INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
								INNER JOIN nilai_kkm ON nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
								AND nilai_kkm.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
								LEFT JOIN mapel ON nilai_kkm.id_mapel = mapel.id_mapel
								WHERE
									siswa.nis = $nis
								AND nilai_kkm.semester = '$semester'
								AND kelas_siswa.id_kelas = $id_kelas
								AND nilai_kkm.id_tahunpelajaran = $id_tahunpelajaran
								ORDER BY mapel.id_mapel ASC
								");
		
			return $nilai;
		
	}

	public function nip($id_kelas)
	{	
		
		$kelas = $this->db->query("SELECT
									guru.nama,
									kelas.nip,
									guru.nip
								FROM
									kelas ,
									guru
								WHERE
									kelas.nip = guru.nip 
								AND kelas.id_kelas=$id_kelas");
		if($kelas->num_rows() > 0){
			return $kelas->result();
		}
	}

	public function kelas_s($id_kelas)
	{	
		
		$kelas_siswa = $this->db->query("SELECT
											siswa.nama AS siswa,
											siswa.nis,
											kelas.kelas AS kelas,
											guru.nama AS guru,
											tahun_pelajaran.tahun_pelajaran,
											kelas.id_kelas
										FROM
											kelas_siswa
										RIGHT OUTER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
										LEFT JOIN siswa ON kelas_siswa.nis = siswa.nis
										LEFT JOIN guru ON kelas.nip = guru.nip
										INNER JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
										WHERE
											kelas.id_kelas=$id_kelas");
			if($kelas_siswa->num_rows() > 0){
			return $kelas_siswa->result();
		}
		
	}

	public function data($nis,$id_kelas)
	{	
		
		$kelas_siswa = $this->db->query("SELECT
								kelas_siswa.*,
								siswa.nama,
								kelas.kelas,
								tahun_pelajaran.id_tahunpelajaran,
								tahun_pelajaran.tahun_pelajaran,
								guru.nama AS guru
							FROM
								kelas_siswa,
								kelas,
								guru,
								tahun_pelajaran,
								siswa
							WHERE
								kelas_siswa.id_kelas = kelas.id_kelas
							AND kelas_siswa.nis = siswa.nis
							AND kelas.nip = guru.nip
							AND kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
							AND kelas_siswa.nis=$nis
							AND kelas_siswa.id_kelas=$id_kelas");
		
			
			return $kelas_siswa;
		
	}

public function nil($id_kkm,$nis,$id_kelas)
	{	
		
		$cek = $this->db->query("SELECT
										nilai_akhirsiswa.*,
										mapel.nama_mapel,
										nilai_kkm.nilai_kkm
									FROM
										nilai_akhirsiswa
									INNER JOIN nilai_kkm ON nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
									INNER JOIN kelas_siswa ON nilai_akhirsiswa.id_kelassiswa = kelas_siswa.id_kelassiswa
									INNER JOIN siswa ON nilai_akhirsiswa.nis = siswa.nis
									INNER JOIN mapel ON nilai_kkm.id_mapel = mapel.id_mapel
									WHERE
										nilai_akhirsiswa.id_kkm = $id_kkm
									AND nilai_akhirsiswa.nis = $nis
									AND kelas_siswa.id_kelas = $id_kelas");
		if($cek->num_rows() > 0){
			return $cek;
		}
	}

	
	public function kkm($id_kkm)
	{	
		
		$kk = $this->db->query("SELECT
									*, mapel.nama_mapel
								FROM
									nilai_kkm, mapel
								WHERE
									nilai_kkm.id_mapel=mapel.id_mapel and
									id_kkm=$id_kkm");
		if($kk->num_rows() > 0){
			return $kk->result();
		}
	}

	public function pernil($id_nilaiakhir)
	{	
		
		$pernil = $this->db->query("SELECT
										nilai_akhirsiswa.*,
										mapel.nama_mapel,
										nilai_kkm.nilai_kkm
									FROM
										nilai_akhirsiswa
									INNER JOIN nilai_kkm ON nilai_akhirsiswa.id_kkm = nilai_kkm.id_kkm
									INNER JOIN mapel ON nilai_kkm.id_mapel = mapel.id_mapel
									WHERE
										nilai_akhirsiswa.id_nilaiakhir = $id_nilaiakhir");
		if($pernil->num_rows() > 0){
			return $pernil->result();
		}
	}

	public function nis($id_kelas)
	{	
		
		$nis = $this->db->query("SELECT
									kelas.kelas,
									guru.nama As guru,
									siswa.nama,
									kelas_siswa.id_kelassiswa,
									kelas_siswa.id_kelas,
									kelas_siswa.nis,
									siswa.nis
								FROM
									kelas_siswa,
									kelas,
									siswa,
									guru
								WHERE
									kelas_siswa.id_kelas = kelas.id_kelas
								AND kelas_siswa.nis = siswa.nis
								AND Kelas.nip = guru.nip
								AND kelas_siswa.id_kelas=$id_kelas
								ORDER BY siswa.nama");
		if($nis->num_rows() > 0){
			return $nis->result();
		}
	}
}