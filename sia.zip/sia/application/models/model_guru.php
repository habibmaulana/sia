<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_guru extends CI_model {

	public function data()
	{
		$data = "SELECT
					guru.*,
					mapel.nama_mapel
				FROM
					guru,
					mapel
				WHERE guru.id_mapel=mapel.id_mapel
					";
		return $this->db->query($data);
	}

	public function getdata($key)
	{
		$this->db->where('nip',$key);
		$hasil = $this->db->get('guru');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('nip',$key);
		$this->db->update('guru',$data);
	}

	public function update($key,$data)
	{
		$sql = "UPDATE pengguna SET nama='".$this->input->post('nama')."' WHERE nip='$key'";	
		return $this->db->query($sql);	
	}

	public function getinsert($data)
	{
		$this->db->insert('guru',$data);
	}

	public function insert($data)
	{
		$sql = "INSERT INTO pengguna(username,password,nama,nip,id_jabatan) values('".$this->input->post('nip')."',  md5('".$this->input->post('nip')."'), '".$this->input->post('nama')."', '".$this->input->post('nip')."', '".$this->input->post('jabatan')."')";	
		$this->db->query($sql);
	}

	public function getdelete($key)
	{
		$this->db->where('nip',$key);
		$this->db->delete('guru');
	}

	public function delete($key)
	{
		$this->db->where('nip',$key);
		$this->db->delete('pengguna');
	}

 	function hapus($key)
	{
		$this->db->where('nip',$key);
		$this->db->delete('kelas');
	}


}

