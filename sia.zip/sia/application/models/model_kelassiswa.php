<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_kelassiswa extends CI_model{
	
public function getdata($id_kelas,$nis)
	{
		$this->db->where('id_kelas',$id_kelas);
		$this->db->where('nis',$nis);
		$hasil = $this->db->get('kelas_siswa');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_kelassiswa',$key);
		$this->db->update('kelas_siswa',$data);
	}

	public function getinsert($data)
	{
		$this->db->insert('kelas_siswa',$data);
		
	}

	public function getdelete($key)
	{
		$this->db->where('id_kelas',$key);
		$this->db->delete('kelas_siswa');
	}

	public function del($key)
	{
		$this->db->where('id_kelassiswa',$key);
		$this->db->delete('kelas_siswa');
	}

	public function gettahun()
	{
		
		$tahun_pelajaran = $this->db->get('tahun_pelajaran');
		if($tahun_pelajaran->num_rows() > 0){
			return $tahun_pelajaran->result();
		}
	}

	public function kelas($id_tahunpelajaran)
	{	
		$this->db->where('id_tahunpelajaran',$id_tahunpelajaran);
		$this->db->order_by('kelas');
		$kelas = $this->db->get('kelas');
		if($kelas->num_rows() > 0){
			return $kelas->result();
		}
	}

	public function nip($id_kelas)
	{	
		
		$kelas = $this->db->query("SELECT
									guru.nama,
									kelas.nip,
									guru.nip
								FROM
									kelas ,
									guru
								WHERE
									kelas.nip = guru.nip 
								AND kelas.id_kelas=$id_kelas");
		if($kelas->num_rows() > 0){
			return $kelas->result();
		}
	}
 
 	public function data()
 	{
 		$data = "SELECT kelas.*, guru.nama,tahun_pelajaran.tahun_pelajaran FROM kelas
				LEFT JOIN guru ON kelas.nip = guru.nip
				LEFT JOIN tahun_pelajaran ON kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
				ORDER BY kelas.id_kelas,
							tahun_pelajaran.tahun_pelajaran";
		return $this->db->query($data);
 	}
}
