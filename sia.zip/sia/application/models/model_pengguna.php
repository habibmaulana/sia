<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_pengguna extends CI_model {

	

	public function getdata($key)
	{
		$this->db->where('id_pengguna',$key);
		$hasil = $this->db->get('pengguna');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$sql = "UPDATE pengguna SET nama='".$this->input->post('nama')."', username='".$this->input->post('username')."', password='".md5($this->input->post('password'))."' WHERE id_pengguna='$key'";	
		return $this->db->query($sql);
		
	}

	public function update($nip,$data)
	{
		$sql = "UPDATE guru SET nama='".$this->input->post('nama')."', id_jabatan='".$this->input->post('id_jabatan')."' WHERE nip='$nip'";	
		return $this->db->query($sql);	
	}

	public function updat($nis,$data)
	{
		$sql = "UPDATE siswa SET nama='".$this->input->post('nama')."' WHERE nis='$nis'";	
		return $this->db->query($sql);	
	}

	public function getinsert($data)
	{
		$this->db->insert('pengguna',$data);
	}

	public function insert($data)
	{
		$sql = "INSERT INTO guru(nip,nama,id_jabatan,id_mapel) values('".$_POST['nip']."', '".$this->input->post('nama')."', '".$this->input->post('id_jabatan')."', '".$_POST['id_mapel']."')";	
		return	 $this->db->query($sql);		
	}

	public function insertsiswa($data)
	{
		$sql = "INSERT INTO siswa(nis,nama) values('".$this->input->post('nis')."', '".$this->input->post('nama')."')";	
		return $this->db->query($sql);
	}

	public function getdelete($key)
	{
		$this->db->where('id_pengguna',$key);
		$this->db->delete('pengguna');
	}
	
	public function delete($nip)
	{
		$this->db->where('nip',$nip);
		$this->db->delete('guru');
	}

	public function elete($nip)
	{
		$this->db->where('nip',$nip);
		$this->db->delete('kelas');
	}
	
	public function delet($nis)
	{
		$this->db->where('nis',$nis);
		$this->db->delete('siswa');
	}
	
	public function data()
	{
		$data = "SELECT
					pengguna.*,
					jabatan.jabatan
				FROM
					pengguna,
					jabatan
				WHERE
					pengguna.id_jabatan = jabatan.id_jabatan";
		return $this->db->query($data);
	}

	public function dele($nis)
	{
		$this->db->where('nis',$nis);
		$this->db->delete('kelas_siswa');
	}

	public function hapus($nis)
	{
		$this->db->where('nis',$nis);
		$this->db->delete('nilai_akhirsiswa');
	}
}