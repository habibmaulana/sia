<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_tahunpelajaran extends CI_model {

	public function getdata($key)
	{
		$this->db->where('id_tahunpelajaran',$key);
		$hasil = $this->db->get('tahun_pelajaran');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_tahunpelajaran',$key);
		$this->db->update('tahun_pelajaran',$data);
	}

	public function getinsert($data)
	{
		$this->db->insert('tahun_pelajaran',$data);
	}

	public function getdelete($key)
	{
		$this->db->where('id_tahunpelajaran',$key);
		$this->db->delete('tahun_pelajaran');
	}
}

