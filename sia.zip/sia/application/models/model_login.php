<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_login extends CI_model {

	public function getlogin($u,$p)
	{
		$pwd = md5($p);
		$this->db->where('username',$u);
		$this->db->where('password',$pwd);
		$query = $this->db->get('pengguna');
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row) 
			{
				$sess = array('id_pengguna' => $row->id_pengguna,
							'username' 	=> $row->username,
							'nama' 			=> $row->nama,
							'id_jabatan' 	=> $row->id_jabatan,
							'nis' 			=> $row->nis,
							'nip' 			=> $row->nip,
							'foto' 			=> $row->foto );
				$this->session->set_userdata($sess);
			}
			if ($this->session->userdata('id_jabatan') <= '2' or $this->session->userdata('id_jabatan') == '10') {
				
				echo "<script type=\"text/javascript\"> alert('Selamat datang $row->nama'); window.location = \"". base_url()."home\"</script>";
				
			}
			elseif ($this->session->userdata('id_jabatan')=='11') {
				
				echo "<script type=\"text/javascript\"> alert('Selamat datang $row->nama'); window.location = \"". base_url()."home_siswa\"</script>";
				
			}	
			elseif ($this->session->userdata('id_jabatan') >= '3' && $this->session->userdata('id_jabatan') <= '9') {
				
				echo "<script type=\"text/javascript\"> alert('Selamat datang $row->nama'); window.location = \"". base_url()."home_guru\"</script>";
			}		
			
		}
		else
		{
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">
												<i class="ace-icon fa fa-times"></i>
											</button>username atau password salah</div>');
			redirect(base_url().'login/index');
		}
	}
	
}

