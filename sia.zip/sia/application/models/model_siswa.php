<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_siswa extends CI_model {


	 function get($key)
	{
		$query = $this->db->query("SELECT
									siswa.*,
									tahun_pelajaran.tahun_pelajaran,
									kelas.kelas
								FROM
									siswa
								LEFT JOIN tahun_pelajaran ON siswa.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
								LEFT JOIN kelas ON siswa.id_kelas = kelas.id_kelas
								WHERE
									siswa.nis=$key
								");
		return $query;
	}

	 function getdata($key)
	{
		$this->db->where('nis',$key);
		$hasil = $this->db->get('siswa');
		return $hasil;
	}
	
	 function update($key,$data)
	{
		$sql = "UPDATE pengguna SET nama='".$this->input->post('nama')."' WHERE nis='$key'";	
		return $this->db->query($sql);	
	}

	 function getupdate($key,$data)
	{
		$this->db->where('nis',$key);
		$this->db->update('siswa',$data);
	}

	 function getinsert($data)
	{
		$this->db->insert('siswa',$data);
	}
	public function tambah($data)
	{
		$sql = "INSERT INTO pengguna(username,password,nama,nis,id_jabatan) values('".$this->input->post('nis')."', md5('".$this->input->post('nis')."'), '".$this->input->post('nama')."', '".$this->input->post('nis')."', 11)";	
		$this->db->query($sql);
	}

	public function insert($data)
	{
		$sql = "INSERT INTO kelas_siswa(nis,id_kelas) values('".$this->input->post('nis')."', '".$this->input->post('id_kelas')."')";	
		$this->db->query($sql);
	}

	public function getdelete($key)
	{
		$this->db->where('nis',$key);
		$this->db->delete('siswa');
	}
	
	public function delete($key)
	{
		$this->db->where('nis',$key);
		$this->db->delete('pengguna');
	}

	public function delet($key)
	{
		$this->db->where('nis',$key);
		$this->db->delete('kelas_siswa');
	}

	public function hapus($key)
	{
		$this->db->where('nis',$key);
		$this->db->delete('nilai_akhirsiswa');
	}
}

