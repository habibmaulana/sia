<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_kelas extends CI_model {

	public function getdata($key)
	{
		$this->db->where('id_kelas',$key);
		$hasil = $this->db->get('kelas');
		return $hasil;
	}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_kelas',$key);
		$this->db->update('kelas',$data);
	}

	public function getinsert($data)
	{
		$this->db->insert('kelas',$data);
	}

	public function getdelete($key)
	{
		$this->db->where('id_kelas',$key);
		$this->db->delete('kelas');
	}

	public function delete($key)
	{
		$this->db->where('id_kelas',$key);
		$this->db->delete('kelas_siswa');
	}

	public function data()
	{
		
		$data = "SELECT
					kelas.id_kelas,
					guru.nama,
					kelas.kelas,
					tahun_pelajaran.tahun_pelajaran
				FROM
					kelas,
					guru,
					tahun_pelajaran
				WHERE
					kelas.nip = guru.nip
				AND kelas.id_tahunpelajaran = tahun_pelajaran.id_tahunpelajaran
				ORDER BY kelas.id_kelas";
		return $this->db->query($data);
	}

}

