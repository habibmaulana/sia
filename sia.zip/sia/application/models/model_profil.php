<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_profil extends CI_model {

	public function set_username($value)
		{
			$this->username = $value;	
		}
	
	public function set_password($value)
		{
			$this->password = $value;	
		}
	
	public function set_password_baru($value)
		{
			$this->password_baru = $value;	
		}

	public function get_username()
		{
			return $this->username;
		}		
		
	public function get_password()
		{
			return $this->password;
		}
		
	public function get_password_baru()
		{
			return $this->password_baru;
		}

	public function getdata($key)
	{
		$this->db->where('nip',$key);
		$hasil = $this->db->get('guru');
		return $hasil;
	}

	public function view_by_password()
		{
			$sql = "SELECT * FROM pengguna WHERE password=md5('".$this->get_password()."') and username='".$this->session->userdata('username')."'";	
			return $this->db->query($sql);
		}
		
	public function update_p()
		{
			$sql = "UPDATE pengguna SET username='".$this->get_username()."', password=md5('".$this->get_password_baru()."') WHERE username='".$this->session->userdata('username')."'";	
			$this->db->query($sql);	
		}
	
	public function getupdate($key,$data)
	{
		$this->db->where('id_pengguna',$key);
		$this->db->update('pengguna',$data);
	}

	public function get($key)
	{
		$this->db->where('id_pengguna',$key);
		$hasil = $this->db->get('pengguna');
		return $hasil;
	}
}

