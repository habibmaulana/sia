<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				 $('#dynamic-table').dataTable( {
				 	
					"aoColumns": [ 
					  null, null, null, null, null, 
					  { "bSortable": false }
					]
			    } );

			})
		</script>

		<div class="table-header">
			Data Pengguna
			<div class="pull-right">
			<a href="<?php echo base_url();?>pengguna/tambah" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
		</div>
			
		</div>
		<?php echo $this->session->flashdata('pesan'); ?>
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Username</th>
			<th class="center">Nis</th>
			<th class="center">Nip</th>
			<th class="center">Jabatan</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		$no=1;
		 
	 		foreach ($data->result() as $row) :
	 	?>
	 	<tr>
	 	
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->username ;?></td>
	 		<td><?php echo $row->nis ;?></td>
	 		<td><?php echo $row->nip ;?></td>
	 		<td><?php echo $row->jabatan ;?></td>
	 		<td class="center">
	 			<a class="blue" href="<?php echo base_url();?>pengguna/tampil/<?php echo $row->id_pengguna; ?>" title="Lihat Data"><i class="ace-icon fa fa-eye bigger-130"></i></a>
	 			<a class="green" href="<?php echo base_url();?>pengguna/edit/<?php echo $row->id_pengguna; ?>" title="Edit Data"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
	 			<a class="red" href="<?php echo base_url();?>pengguna/delete/<?php echo $row->id_pengguna; ?>" title="Hapus Data" onclick="return confirm('anda yakin akan menghapus data ini??');"><i class="ace-icon fa fa-trash bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?PHP 
				endforeach;
				?>
	</tbody>
</table>
