<script type="text/javascript">
	$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>pengguna/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>pengguna";
				}
			});
		});
	});


	function cekform()
	{
		if(!$("#username").val())
		{
			alert('Username tidak boleh kosong');
			$('#username').focus()
			return false;
		}
		if(!$("#password").val())
		{
			alert('Password tidak boleh kosong');
			$('#password').focus()
			return false;
		}
	
	}
	
</script>

<?php
echo $this->session->flashdata('pesan');

?>

<form class="form-horizontal" name="my-form" id="my-form" enctype="multipart/form-data" onsubmit="return cekform();">
	<input type="text" name="id_pengguna" id="id_pengguna" hidden class="col-xs-10 col-sm-5" value="<?php echo $id_pengguna; ?>">


	<div class="form-group">
		<label class="col-sm-2 control-label">Username</label>
		<div class="col-sm-4">
			<input type="text" name="username" id="username" placeholder="Masukkan Username" class="col-xs-10 col-sm-5" value="<?php echo $username; ?>">
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Password</label>
		<div class="col-sm-6">
			<input type="password" name="password" id="password" placeholder="Masukkan Password" class="col-xs-10 col-sm-5" value="<?php echo $password; ?>">
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama</label>
		<div class="col-sm-6">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama" class="col-xs-10 col-sm-5" value="<?php echo $nama; ?>">
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIS</label>
		<div class="col-sm-6">
		<label class="control-label"><?php echo $nis; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIP</label>
		<div class="col-sm-6">
		<label class="control-label"><?php echo $nip; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Jabatan</label>
		<div class="col-sm-2">
		<input type="text" name="id_jabatan" id="id_jabatan" hidden value="<?php echo $id_jabatan; ?>">
		<label class="control-label"><?php echo $jabatan; ?></label>   
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Foto</label>
		<div class="col-sm-6">
		<?php echo base_url();?>assets/avatars/<?=$foto?> 
		</div>	
	</div>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9"> 
	<button type="button" name="simpan" id="simpan" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp; 
	<a href="<?php echo base_url();?>pengguna" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
</div>
</div>
</form>