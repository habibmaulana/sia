<form class="form-horizontal" method="post" action="<?php echo base_url();?>pengguna/simpan" enctype="multipart/form-data" onsubmit="return cekform();">
	<div class="form-group">
		<label class="col-sm-2 control-label">Username</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $username; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Password</label>
		<div class="col-sm-4">
			<input class="control-label" disabled="disabled" type="password" value="<?php echo $password; ?>">
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $nama; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIS</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $nis; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIP</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $nip; ?></label>
		</div>	
	</div>
<div class="space-4"></div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Jabatan</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $jabatan; ?></label>
                    
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Foto</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $foto; ?></label>
			
		</div>	
	</div>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9"> 
	<a href="<?php echo base_url();?>pengguna" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
</div>
</div>
</form>