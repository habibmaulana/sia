<form class="form-horizontal" name="my-form" id="my-form" onsubmit="return cekform();">
	<h4 class="header"><strong>Data Kelas</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Kelas</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $kelas; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Wali Kelas</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $nama; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $tahun_pelajaran; ?></label>
		</div>	
	</div>
	
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<a href="<?php echo base_url();?>kelas" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>