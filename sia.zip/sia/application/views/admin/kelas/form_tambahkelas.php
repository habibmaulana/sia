<script type="text/javascript">
$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>kelas/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>kelas";
				}
			});
		});
});
	function cekform()
	{
		if(!$("#nama").val())
		{
			alert('Nama tidak boleh kosong');
			$('#nama').focus()
			return false;
		}
		if(!$("#nip").val())
		{
			alert('Nama Wali Kelas tidak boleh kosong');
			$('#nip').focus()
			return false;
		}
		if(!$("#id_tahunpelajaran").val())
		{
			alert('Tahun Pelajaran tidak boleh kosong');
			$('#id_tahunpelajaran').focus()
			return false;
		}
	}
</script>

<?php
echo $this->session->flashdata('pesan');
?>

<form class="form-horizontal" method="post" action="<?php echo site_url();?>kelas/simpan">
	<input type="text" name="id_kelas" id="id_kelas" hidden class="col-xs-10 col-sm-5" value="<?php echo $id_kelas; ?>">

	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Kelas</label>
		<div class="col-sm-2">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama Mata Pelajaran" class="col-xs-10 col-sm-5" value="<?php echo $nama; ?>" required>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Wali Kelas</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="nip" id="nip" required>
         <option value="">--Pilih Guru--</option>                            
			<?php
				$guru = $this->db->get('guru');
				foreach ($guru->result() as $row) {
					
            ?>
                                      
        <option value="<?PHP echo $row->nip; ?>"><?PHP echo $row->nama; ?></option>
        <?php } ?>
                                        
        </select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="id_tahunpelajaran" id="id_tahunpelajaran" required>
         <option value="">Pilih Tahun Pelajaran</option>                            
			<?php
				$tahun = $this->db->get('tahun_pelajaran');
				foreach ($tahun->result() as $row) {
					
            ?>
                                      
        <option value="<?PHP echo $row->id_tahunpelajaran; ?>"><?PHP echo $row->tahun_pelajaran; ?></option>
        <?php } ?>
                                        
        </select>
		</div>	
	</div>
	
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="submit" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>kelas" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>