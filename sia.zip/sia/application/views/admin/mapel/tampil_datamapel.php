<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = $('#dynamic-table').dataTable( {

					"aoColumns": [ 
					  null, null,  
					  { "bSortable": false }
					]
			    } );
						
			})
		</script>
	
		<div class="table-header">
			Data Mata Pelajaran
			<div class="pull-right">
			<a href="<?php echo base_url();?>mapel/tambah" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
		</div>
			
		</div>
	
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nama Mata Pelajaran</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		foreach ($data->result() as $row) {
	 			
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nama_mapel ;?></td>
	 		<td class="center">
	 			<a class="blue" href="<?php echo base_url();?>mapel/tampil/<?php echo $row->id_mapel; ?>" title="Lihat Data"><i class="ace-icon fa fa-eye bigger-130"></i></a>
	 			<a class="green" href="<?php echo base_url();?>mapel/edit/<?php echo $row->id_mapel; ?>" title="Edit Data"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
	 			<a class="red" href="<?php echo base_url();?>mapel/delete/<?php echo $row->id_mapel; ?>" title="Hapus Data" onclick="return confirm('anda yakin akan menghapus data ini??');"><i class="ace-icon fa fa-trash bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?php }?>
	</tbody>
</table>