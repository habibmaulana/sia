<form class="form-horizontal" name="my-form" id="my-form" onsubmit="return cekform();">
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Mata Pelajaran</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $nama; ?></label>
		</div>	
	</div>
<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<a href="<?php echo base_url();?>mapel" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>