<script type="text/javascript">
	function cekform()
	{
		
		if(!$("#nama").val())
		{
			alert('Nama Mata Pelajaran tidak boleh kosong');
			$('#nama').focus()
			return false;
		}
	}

$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>mapel/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>mapel";
				}
			});
		});
	});
</script>


<form class="form-horizontal" name="my-form" id="my-form" onsubmit="return cekform();">
	
	<input type="text" name="id" id="id" hidden class="col-xs-10 col-sm-5" value="<?php echo $id; ?>">
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Mata Pelajaran</label>
		<div class="col-sm-6">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama Mata Pelajaran" class="col-xs-10 col-sm-5" value="<?php echo $nama; ?>">
		</div>	
	</div>
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="button" name="simpan" id="simpan" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>mapel" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>