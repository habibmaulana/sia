<script type="text/javascript">
$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>siswa/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>siswa";
				}
			});
		});
});
$(document).ready(function() {
		$("#id_tahunpelajaran").change(function() {
			$("#id_tahunpelajaran option:selected").each(function() {
			id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.post("<?php echo base_url(); ?>kelas_siswa/kelas", {
				id_tahunpelajaran : id_tahunpelajaran
			}, function(data){
			$("#id_kelas").html(data);
			
			});
		});
	});
});
	
</script>


<?php echo $this->session->flashdata('pesan');?>
<form class="form-horizontal" method="post" action="<?php echo site_url();?>siswa/simpan">
	<h4 class="header blue"><strong>Data Siswa</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa</label>
		<div class="col-sm-2">
			<input type="text" name="nis" id="nis" placeholder="Masukkan NIS" class="col-sm-7" value="<?php echo $nis; ?>" required>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa Nasional</label>
		<div class="col-sm-2">
			<input type="text" name="nisn" id="nisn" placeholder="Masukkan NISN" value="<?php echo $nisn; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama</label>
		<div class="col-sm-2">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama" value="<?php echo $nama; ?>" required>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tempat Lahir</label>
		<div class="col-sm-2">
			<input type="text" name="tempat" id="tempat" placeholder="Masukkan tempat" value="<?php echo $tempat; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tanggal Lahir</label>
		<div class="col-sm-2">
			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-calendar bigger-110"></i>
				</span>
				<input class="form-control" type="date" name="tgl" id="tgl" placeholder="Masukkan Tanggal Lahir" value="<?php echo $tgl; ?>">
			</div>	
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="jenis" id="jenis" value="<?php echo $jenis; ?>">
			<option value="">Jenis Kelamin</option>
			<option value="1">Laki-Laki</option>
			<option value="2">Perempuan</option>
			</select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Agama</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="agama" id="agama" value="<?php echo $agama; ?>">
			<option value="">Agama</option>
			<option value="Buhda">Buhda</option>
			<option value="Hindu">Hindu</option>
			<option value="Islam">Islam</option>
			<option value="Kristen">Kristen</option>
			<option value="Katolik">Katolik</option>
			</select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Status Dalam Keluarga</label>
		<div class="col-sm-2">
			<input type="text" name="status" id="status" placeholder="Masukkan Status Dalam Keluarga" value="<?php echo $status; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Anak Ke-</label>
		<div class="col-sm-2">
			<input type="text" name="anak" id="anak" placeholder="Masukkan Anak Ke" value="<?php echo $anak; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-6">
			<textarea name="alamat" id="alamat" placeholder="Masukkan Alamat" class="col-xs-10 col-sm-5" value="<?php echo $alamat; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no" id="no" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Sekolah Asal</label>
		<div class="col-sm-2">
			<input type="text" name="sekolah" id="sekolah" placeholder="Masukkan Sekolah Asal" value="<?php echo $sekolah; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="id_tahunpelajaran" id="id_tahunpelajaran" required>
         <option value="">Masukkan Tahun Pelajaran</option>                            
			<?php
				$tahun = $this->db->get('tahun_pelajaran');
				foreach ($tahun->result() as $row) {
					
            ?>
                                      
        <option value="<?PHP echo $row->id_tahunpelajaran; ?>"><?PHP echo $row->tahun_pelajaran; ?></option>
        <?php } ?>
                                        
        </select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Diterima di kelas</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="id_kelas" id="id_kelas" required>
         <option value="0">--Pilih Kelas--</option>    
			                      
        </select>
        </div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pada Tanggal</label>
		<div class="col-sm-2">
			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-calendar bigger-110"></i>
				</span>
				<input class="form-control" type="date" name="pada" id="pada" placeholder="Masukkan Pada Tanggal" value="<?php echo $pada; ?>">
			</div>	
		</div>	
	</div>
	<hr>
	<h4 class="header blue"><strong>Data Orang Tua</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ayah</label>
		<div class="col-sm-2">
			<input type="text" name="ayah" id="ayah" placeholder="Masukkan Nama Ayah" value="<?php echo $ayah; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ibu</label>
		<div class="col-sm-2">
			<input type="text" name="ibu" id="ibu" placeholder="Masukkan Nama Ibu" value="<?php echo $ibu; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Orang Tua</label>
		<div class="col-sm-6">
			<textarea name="alamat_ortu" id="alamat_ortu" placeholder="Masukkan Alamat Orang Tua" class="col-xs-10 col-sm-5" value="<?php echo $alamat_ortu; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no_ortu" id="no_ortu" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no_ortu; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ayah</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_ayah" id="pekerjaan_ayah" placeholder="Masukkan Pekerjaan Ayah" value="<?php echo $pekerjaan_ayah; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ibu</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_ibu" id="pekerjaan_ibu" placeholder="Masukkan Pekerjaan Ibu" value="<?php echo $pekerjaan_ibu; ?>">
		</div>	
	</div>
	<hr>
	<h4 class="header blue"><strong>Data Wali</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Wali</label>
		<div class="col-sm-2">
			<input type="text" name="wali" id="wali" placeholder="Masukkan Nama Wali" value="<?php echo $wali; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Wali</label>
		<div class="col-sm-6">
			<textarea name="alamat_wali" id="alamat_wali" placeholder="Masukkan Alamat Wali" class="col-xs-10 col-sm-5" value="<?php echo $alamat_wali; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no_wali" id="no_wali" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no_wali; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Wali</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_wali" id="pekerjaan_wali" placeholder="Masukkan Pekerjaan Wali" value="<?php echo $pekerjaan_wali; ?>">
		</div>	
	</div>
	
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
	<button type="submit" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp; 
	<a href="<?php echo base_url();?>siswa" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
</div>
</div>
</form>