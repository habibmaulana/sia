<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				 $('#dynamic-table').dataTable( {
				 	
					"aoColumns": [ 
					  null, null, null, null, null, 
					  { "bSortable": false }
					]
			    } );

			})
		</script>

		<div class="table-header">
			Data Siswa
			<div class="pull-right">
			<a href="<?php echo base_url();?>siswa/tambah" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
		</div>
			
		</div>
<?php echo $this->session->flashdata('pesan');?>
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nis</th>
			<th class="center">Nisn</th>
			<th class="center">Nama</th>
			<th class="center">Asal Sekolah </th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		$no=1;
		 
	 		foreach ($data->result() as $row) :
	 			?>
	 	<tr>
	 	
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nis ;?></td>
	 		<td><?php echo $row->nisn ;?></td>
	 		<td><?php echo $row->nama ;?></td>
	 		<td><?php echo $row->sekolah_asal ;?></td>
	 		<td class="center">
	 			<a class="red" href="<?php echo base_url();?>cetak/datasiswa/<?php echo $row->nis; ?>" title="Cetak"><i class="ace-icon fa fa-print bigger-130"></i></a>
	 			<a class="blue" href="<?php echo base_url();?>siswa/tampil/<?php echo $row->nis; ?>" title="Lihat Data"><i class="ace-icon fa fa-eye bigger-130"></i></a>
	 			<a class="green" href="<?php echo base_url();?>siswa/edit/<?php echo $row->nis; ?>" title="Edit Data"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
	 			<a class="red" href="<?php echo base_url();?>siswa/delete/<?php echo $row->nis; ?>" onclick="return confirm('anda yakin akan menghapus data ini??');" title="Hapus Data"><i class="ace-icon fa fa-trash bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?PHP 
				endforeach;
				?>
	</tbody>
</table>
