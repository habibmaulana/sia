



<form class="form-horizontal" name="my-form" id="my-form">
	<h4 class="header blue"><strong>Data Siswa</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $nis; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa Nasional</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $nisn; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $nama; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tempat Lahir</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tempat; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tanggal Lahir</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo tgl_indo($tgl); ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $jenis; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Agama</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $agama; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Status Dalam Keluarga</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $status; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Anak Ke-</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $anak; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-7">
			<label class="control-label"><?php echo $alamat; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $no; ?></label>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Sekolah Asal</label>
		<div class="col-sm-7">
			<label class="control-label"><?php echo $sekolah; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $id_tahunpelajaran; ?></label>
		
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Diterima di kelas</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $id_kelas; ?></label>
        </div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pada Tanggal</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo tgl_indo($pada); ?></label>
		</div>	
	</div>
	<hr>
	<h4 class="header blue"><strong>Data Orang Tua</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ayah</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $ayah; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ibu</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $ibu; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Orang Tua</label>
		<div class="col-sm-7">
			<label class="control-label"><?php echo $alamat_ortu; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $no_ortu; ?></label>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ayah</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $pekerjaan_ayah; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ibu</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $pekerjaan_ibu; ?></label>
		</div>	
	</div>
	<hr>
	<h4 class="header blue"><strong>Data Wali</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Wali</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $wali; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Wali</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $alamat_wali; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $no_wali; ?></label>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Wali</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $pekerjaan_wali; ?></label>
		</div>	
	</div>
	
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
	<a href="<?php echo base_url();?>siswa" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
</div>
</div>
</form>