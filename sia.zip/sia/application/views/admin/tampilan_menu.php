<ul class="nav nav-list">
					<li class="">
						<a href="<?php echo base_url();?>home">
							<i class="menu-icon fa fa-home"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								Master
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url();?>pengguna">
									<i class="menu-icon fa fa-caret-right"></i>
									Pengguna
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>siswa">
									<i class="menu-icon fa fa-caret-right"></i>
									Siswa
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>guru">
									<i class="menu-icon fa fa-caret-right"></i>
									Guru
								</a>
								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>kelas">
									<i class="menu-icon fa fa-caret-right"></i>
									Kelas
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>mapel">
									<i class="menu-icon fa fa-caret-right"></i>
									Mata Pelajaran
								</a>

								<b class="arrow"></b>
							</li>
										
							<li class="">
								<a href="<?php echo base_url();?>tahun_pelajaran">
									<i class="menu-icon fa fa-caret-right"></i>
									Tahun Pelajaran
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-shopping-cart"></i>
							<span class="menu-text">
								Transaksi
							</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url();?>nilai_kkm">
									<i class="menu-icon fa fa-caret-right"></i>
									Nilai KKM
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>kelas_siswa">
									<i class="menu-icon fa fa-caret-right"></i>
									Kelas Siswa
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="<?php echo base_url();?>nilai_akhir">
									<i class="menu-icon fa fa-caret-right"></i>
									Nilai Akhir
								</a>
								<b class="arrow"></b>
							</li>
						</ul>

						<b class="arrow"></b>
					</li>
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-print"></i>
							<span class="menu-text">
								Cetak Laporan
							</span>
							<b class="arrow fa fa-angle-down"></b>
						</a>
						<b class="arrow"></b>
						<ul class="submenu">
							<li class="">
								<a href="<?php echo base_url();?>cetak">
									<i class="menu-icon fa fa-caret-right"></i>
									Data Guru
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="<?php echo base_url();?>cetak/siswa">
									<i class="menu-icon fa fa-caret-right"></i>
									Data Siswa
								</a>

								<b class="arrow"></b>
							</li>

						</ul>

						<b class="arrow"></b>
					</li>
					<li class="">
						<a href="<?php echo base_url();?>home/logout"  onclick="return confirm('Apakah anda akan keluar?');">
							<i class="menu-icon fa fa-power-off"></i>
							<span class="menu-text"> Keluar </span>
						</a>

						<b class="arrow"></b>

					</li>

				</ul><!-- /.nav-list -->