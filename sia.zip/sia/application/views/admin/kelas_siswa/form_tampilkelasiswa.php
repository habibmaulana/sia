<form class="form-horizontal">
	<h4 class="header"><STRONG>Data Kelas</STRONG></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Kelas</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $kelas; ?></label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Wali Kelas</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $guru; ?></label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tahun_pelajaran; ?></label>
		</div>	
	</div>

<table id="simple-table" class="table table-striped table-bordered table-hover">
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">NIS</th>
			<th class="center">Nama Siswa</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		
	 		 foreach ($query->result() as $key) {
	 		
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $key->nis ;?></td>
			<td><?php echo $key->siswa ;?></td>
	 	</tr>
	 	<?php } ?>
	</tbody>
</table>
<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<a href="<?php echo base_url();?>kelas_siswa" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
</div>
</form>