<script type="text/javascript">
	jQuery(function($) {
				//initiate dataTables plugin
				 $('#dynamic-table').dataTable( {
				 	
					"aoColumns": [ 
					 null, { "bSortable": false }, null, null, null
					]
			    } );
				
			});
	$(document).ready(function() {
			$("input[name='checkAll']").click(function() {
				var checked = $(this).attr("checked");
				$("#dynamic-table tr td input:checkbox").attr("checked", checked);
			});
		});
	function cekform()
	{
		
		
	}
	
</script>

<?php
echo $this->session->flashdata('pesan');
?>

<form class="form-horizontal" method="post" action="<?php echo base_url();?>kelas_siswa/simpan" onsubmit="return cekform();">
	<h4 class="header"><STRONG>Data Kelas</STRONG></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Kelas</label>
		<div class="col-sm-2">
			<label class="control-label" ><?php echo $kelas; ?></label>
			<input type="text" hidden id="id_kelas" name="id_kelas" value="<?php echo $id_kelas;?>">
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Wali Kelas</label>
		<div class="col-sm-6">
			<label class="control-label" ><?php echo $guru; ?></label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<label class="control-label" id="tahun_pelajaran"><?php echo $tahun_pelajaran; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Pilih Siswa</label>
		<div class="col-sm-8">
	<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">no</th>
			<th class="center">
				pilih
				
			</th>
			<th class="center">nis</th>
			<th class="center">nama</th>
			<th class="center">nisn</th>
		
		</tr>
	</thead>
	<tbody>
		<?php 
		
		$no=1;
		 $data = "SELECT * FROM Siswa";
		 $result = mysql_query($data);
         while($row = mysql_fetch_object($result))
               {
	 		
	 			$nis=$row->nis;
	 				$infoSql	= "SELECT
						kelas_siswa.*,
						kelas.*
						FROM
						kelas_siswa
						INNER JOIN kelas ON kelas.id_kelas = kelas_siswa.id_kelas
						INNER JOIN siswa ON siswa.nis = kelas_siswa.nis
						WHERE
							 kelas.id_tahunpelajaran=$id_tahunpelajaran
						AND  kelas_siswa.nis=$nis";
		 $infoQry = mysql_query($infoSql);            
         $infoData = mysql_fetch_object($infoQry);
	
		// Status mematikan Checkbox jika sudah memiliki kelas
		$mati	= "";
		if(mysql_num_rows($infoQry) >=1) {
			$mati	= " disabled";
		}
	 			?>

	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td class="center">
				
				<input type="checkbox" class="ace" name="nis[]" value="<?php echo $row->nis; ?>"<?php echo $mati; ?>>
				<span class="lbl"></span>
			</td>
	 		<td><?php echo $row->nis ;?></td>
	 		<td><?php echo $row->nama ;?></td>
	 		<td><?php echo $row->nisn ;?></td>
	 		

	 	</tr>
	 	<?PHP 
				}
				?>
	</tbody>
</table>
</div>
</div>
<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="submit" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>kelas_siswa" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
</div>	
</form>
