<link href="<?php echo base_url();?>assets/avatars/logo1.jpg" rel="shortcut icon" rev="shortcut icon">
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									Selamat Datang di  
									<strong class="green">
										Sistem Informasi Akademik
										<strong class="blue"> SMP Negeri 40 Semarang </strong>
										
									</strong>
								</div>

								