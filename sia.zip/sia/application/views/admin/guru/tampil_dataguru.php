<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = $('#table').dataTable( {
					
					"aoColumns": [
					  null, null, null, null, null, 
					  { "bSortable": false }
					]
			    } );
			    	})
		</script>
		<div class="table-header">
			Data Guru
			<div class="pull-right">
			<a href="<?php echo base_url();?>guru/tambah" class="btn btn-sm btn-primary"  title="Tambah Data">Tambah Data</a>
		</div>
			
		</div>
<?php echo $this->session->flashdata('pesan');?>
<table id="table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nip</th>
			<th class="center">Nama</th>
			<th class="center">Jenis Kelamin</th>
			<th class="center">Mata Pelajaran</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		foreach ($data->result() as $row) {
	 			
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nip ;?></td>
	 		<td><?php echo $row->nama ;?></td>
	 		<td><?php echo $row->jenis_kelamin ;?></td>
	 		<td><?php echo $row->nama_mapel ;?></td>
	 		<td class="center">
	 			<a class="blue" href="<?php echo base_url();?>guru/tampil/<?php echo $row->nip; ?>" title="Lihat Data"><i class="ace-icon fa fa-eye bigger-130"></i></a>
	 			<a class="green" href="<?php echo base_url();?>guru/edit/<?php echo $row->nip; ?>" title="Edit Data"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
	 			<a class="red" href="<?php echo base_url();?>guru/delete/<?php echo $row->nip; ?>" title="Hapus Data" onclick="return confirm('anda yakin akan menghapus data ini??');"><i class="ace-icon fa fa-trash bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?php }?>
	</tbody>
</table>