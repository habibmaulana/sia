<script type="text/javascript">
$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>guru/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>/guru";
				}
			});
		});
});
		

	
</script>

<?php
echo $this->session->flashdata('pesan');
?>

<form class="form-horizontal" method="POST" action="<?php echo site_url();?>guru/simpan">
	<h4 class="header blue"><strong>Data Guru</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIP</label>
		<div class="col-sm-5">
			<input type="text" name="nip" id="nip" placeholder="Masukkan NIP" class="col-xs-10 col-sm-5" value="<?php echo $nip; ?>" required>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Guru</label>
		<div class="col-sm-6">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama Guru" class="col-sm-5" value="<?php echo $nama; ?>" required>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">NUPTK</label>
		<div class="col-sm-5">
			<input type="text" name="nuptk" id="nuptk" placeholder="Masukkan NUPTK" class="col-xs-10 col-sm-5" value="<?php echo $nuptk; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NRG</label>
		<div class="col-sm-4">
			<input type="text" name="nrg" id="nrg" placeholder="Masukkan NRG" class="col-xs-10 col-sm-5" value="<?php echo $nrg; ?>">
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Tempat Lahir</label>
		<div class="col-sm-4">
			<input type="text" name="tempat" id="tempat" placeholder="Masukkan Tempat Lahir" class="col-xs-10 col-sm-5" value="<?php echo $tempat; ?>">
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Tanggal Lahir</label>
		<div class="col-sm-2">
			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-calendar bigger-110"></i>
				</span>
				<input class="form-control" type="date" name="tgl" id="tgl" placeholder="Masukkan Tanggal Lahir" value="<?php echo $tgl; ?>">
			</div>	
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Pangkat/Golongan</label>
		<div class="col-sm-4">
			<input type="text" name="pangkat" id="pangkat" placeholder="Masukkan Pangkat" class="col-xs-10 col-sm-5" value="<?php echo $pangkat; ?>">
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jabatan</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="jabatan" id="jabatan" required>
         <option value="">Masukkan Jabatan</option>                            
			<?php
				$jabatan = $this->db->get('jabatan');
				foreach ($jabatan->result() as $row) {
					
            ?>
                                      
        <option value="<?PHP echo $row->id_jabatan; ?>"><?PHP echo $row->jabatan; ?></option>
        <?php } ?>
                                        
        </select>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jenis Kelamin</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="jenis" id="jenis" value="<?php echo $jenis; ?>">
			<option value="">Jenis Kelamin</option>
			<option value="1">Laki-Laki</option>
			<option value="2">Perempuan</option>
			</select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Setatus Guru</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="status" id="status" value="<?php echo $status; ?>">
			<option value="">Setatus Guru</option>
			<option value="1">PNS</option>
			<option value="2">GTT</option>
			<option value="3">GTY</option>
			</select>	
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">TMT</label>
		<div class="col-sm-2">
			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-calendar bigger-110"></i>
				</span>
				<input type="date" name="tmt" id="tmt" placeholder="Masukkan TMT" class="form-control" value="<?php echo $tmt; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Mata Pelajaran</label>
		<div class="col-sm-2">
		<select class="form-control" type="text" name="mapel" id="mapel" required>
         <option value="">Masukkan Mata pelajaran</option>                            
		<?php
			$mapel = $this->db->get('mapel');
			foreach ($mapel->result() as $row) {
			
		?>	                               
        <option value="<?php echo $row->id_mapel; ?>"><?php echo $row->nama_mapel; ?></option>
        <?php }?>                                      
        </select>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jumlah Jam Mengajar</label>
		<div class="col-sm-2">
			<input type="text" name="jml" id="jml" placeholder="Masukkan Jumlah Jam Mengajar" class="col-xs-10 col-sm-5" value="<?php echo $jml; ?>">
		</div>	
	</div>
	<hr>
<h4 class="header"><strong>Masa</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun</label>
		<div class="col-sm-2">
			<input type="text" name="tahun" id="tahun" placeholder="Masukkan Masa Tahun" class="col-xs-10 col-sm-5" value="<?php echo $tahun; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Bulan</label>
		<div class="col-sm-2">
			<input type="text" name="bulan" id="bulan" placeholder="Masukkan Masa Bulan" class="col-xs-10 col-sm-5" value="<?php echo $bulan; ?>">
		</div>	
	</div>
	<hr>
<h4 class="header"><strong>Pendidikan</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Jenjang</label>
		<div class="col-sm-6">
			<input type="text" name="jenjang" id="jenjang" placeholder="Masukkan Jenjang" class="col-xs-10 col-sm-5" value="<?php echo $jenjang; ?>">
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jurusan</label>
		<div class="col-sm-6">
			<input type="text" name="jurusan" id="jurusan" placeholder="Masukkan Jurusan" class="col-xs-10 col-sm-5" value="<?php echo $jurusan; ?>">
		</div>	
	</div>
	<hr>
	
<h4 class="header blue"><strong>Sertifikasi</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun</label>
		<div class="col-sm-2">
			<input type="text" name="tahunser" id="tahunser" placeholder="Masukkan Tahun Setifikasi" class="col-xs-10 col-sm-5" value="<?php echo $tahunser; ?>">
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">No</label>
		<div class="col-sm-6">
			<input type="text" name="noser" id="noser" placeholder="Masukkan No Sertifikasi" class="col-xs-10 col-sm-5" value="<?php echo $noser; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Mata Pelajaran</label>
		<div class="col-sm-4">
			<input type="text" name="mapser" id="mapser" placeholder="Masukkan Mata Pelajaran Sertifikasi" class="col-xs-10 col-sm-5" value="<?php echo $mapser; ?>">
		</div>	
	</div>
<hr>

<h4 class="header"><strong>Alamat Rumah</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Desa</label>
		<div class="col-sm-5">
			<input type="text" name="desa" id="desa" placeholder="Masukkan Desa" class="col-xs-10 col-sm-5" value="<?php echo $desa; ?>">
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Kelurahan</label>
		<div class="col-sm-5">
			<input type="text" name="kel" id="kel" placeholder="Masukkan Kelurahan" class="col-xs-10 col-sm-5" value="<?php echo $kel; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Kecamatan</label>
		<div class="col-sm-5">
			<input type="text" name="kec" id="kec" placeholder="Masukkan Kecamatan" class="col-xs-10 col-sm-5" value="<?php echo $kec; ?>">
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">No Telepon/HP</label>
		<div class="col-sm-5">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no" id="no" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no; ?>">
			</div>	
		</div>
	</div>
	<hr><hr>

	<div class="form-group">
		<label class="col-sm-2 control-label">Pensiun</label>
		<div class="col-sm-2">
			<input type="text" name="pensiun" id="pensiun" placeholder="Masukkan pensiun" class="col-xs-10 col-sm-5" value="<?php echo $pensiun; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NPWP</label>
		<div class="col-sm-6">
			<input type="text" name="npwp" id="npwp" placeholder="Masukkan NPWP" class="col-xs-10 col-sm-5" value="<?php echo $npwp; ?>">
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Keterangan</label>
		<div class="col-sm-6">
			<textarea name="ket" id="ket" placeholder="Masukkan Keterangan" class="col-xs-10 col-sm-5" value="<?php echo $ket; ?>"></textarea>
		</div>	
	</div>

	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="sumbit" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>guru" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>