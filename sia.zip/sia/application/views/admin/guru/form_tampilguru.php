<form class="form-horizontal" name="my-form" id="my-form" onsubmit="return cekform();">
	<h4 class="header blue"><strong>Data Guru</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">NIP</label>
		<div class="col-sm-5">
		<label class="control-label"><?php echo $nip; ?></label>
			
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Guru</label>
		<div class="col-sm-6">
		<label class="control-label"><?php echo $nama; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">NUPTK</label>
		<div class="col-sm-5">
		<label class="control-label"><?php echo $nuptk; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NRG</label>
		<div class="col-sm-4">
		<label class="control-label"><?php echo $nrg; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Tempat Lahir</label>
		<div class="col-sm-4">
		<label class="control-label"><?php echo $tempat; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Tanggal Lahir</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tgl; ?></label>	
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Pangkat/Golongan</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $pangkat; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jabatan</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $jabatan; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jenis Kelamin</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $jenis; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Status Guru</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $status; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">TMT</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tmt; ?>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Mata Pelajaran</label>
		<div class="col-sm-4">
		<label class="control-label"><?php echo $mapel; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jumlah jam Mengajar</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $jml; ?></label>
		</div>	
	</div>
	<hr>
<h4 class="header"><strong>Masa</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tahun; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Bulan</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $bulan; ?></label>
		</div>	
	</div>
	<hr>
<h4 class="header"><strong>Pendidikan</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Jenjang</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $jenjang; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Jurusan</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $jurusan; ?></label>
		</div>	
	</div>
	<hr>
	
<h4 class="header blue"><strong>Sertifikasi</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tahunser; ?></label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">No</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $noser; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Mata pelajaran</label>
		<div class="col-sm-4">
			<label class="control-label"><?php echo $mapser; ?></label>
		</div>	
	</div>
<hr>

<h4 class="header"><strong>Alamat Rumah</strong></h4>
	<div class="form-group">
		<label class="col-sm-2 control-label">Desa</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $desa; ?></label>
		</div>	
	</div>
	
	<div class="form-group">
		<label class="col-sm-2 control-label">Kelurahan</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $kel; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Kecamatan</label>
		<div class="col-sm-5">
			<label class="control-label"><?php echo $kec; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">No Telepon/HP</label>
		<div class="col-sm-5">
			<div class="input-group">
			<label class="control-label"><?php echo $no; ?></label>
			</div>	
		</div>
	</div>
	<hr><hr>

	<div class="form-group">
		<label class="col-sm-2 control-label">Pensiun</label>
		<div class="col-sm-2">
		<label class="control-label"><?php echo $pensiun; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">NPWP</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $npwp; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Keterangan</label>
		<div class="col-sm-6">
			<label class="control-label"><?php echo $ket; ?></label>
		</div>	
	</div>
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<a href="<?php echo base_url();?>guru" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>