<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				 $('#dynamic-table').dataTable( {
				 	
					"aoColumns": [ 
					  null, null, null, null, null, 
					  { "bSortable": false }
					]
			    } );

			})
		</script>

		<div class="table-header">
			Data Siswa
		</div>
		
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nis</th>
			<th class="center">Nisn</th>
			<th class="center">Nama</th>
			<th class="center">Alamat</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		$no=1;
		 
	 		foreach ($data->result() as $row) :
	 			?>
	 	<tr>
	 	
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nis ;?></td>
	 		<td><?php echo $row->nisn ;?></td>
	 		<td><?php echo $row->nama ;?></td>
	 		<td><?php echo $row->alamat_siswa ;?></td>
	 		<td class="center">
	 			<a class="red" href="<?php echo base_url();?>index.php/cetak/datasiswa/<?php echo $row->nis; ?>" title="Cetak Data"><i class="ace-icon fa fa-print bigger-130"></i></a>
		</td>

	 	</tr>
	 	<?PHP 
				endforeach;
				?>
	</tbody>
</table>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
<a href="<?php echo base_url();?>cetak/excelsiswa" title="Cetak Semua Data" class="btn btn-success"><i class="ace-icon fa fa-print bigger-110 "></i> Cetak Semua Data Ke Excel</a> &nbsp; &nbsp;
</div>
</div>
