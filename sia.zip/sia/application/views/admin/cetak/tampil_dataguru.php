<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = $('#table').dataTable( {
					
					"aoColumns": [
					  null, null, null, null, null 
					 
					]
			    } );
			    	})
		</script>
		<div class="table-header">
			Data Guru			
		</div>
		
<table id="table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nip</th>
			<th class="center">Nama</th>
			<th class="center">Jenis Kelamin</th>
			<th class="center">Mata Pelajaran</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		foreach ($data->result() as $row) {
	 			
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nip ;?></td>
	 		<td><?php echo $row->nama ;?></td>
	 		<td><?php echo $row->jenis_kelamin ;?></td>
	 		<td><?php echo $row->nama_mapel ;?></td>
	 	</tr>
	 	<?php }?>
	</tbody>
</table>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
<a href="<?php echo base_url();?>cetak/excelguru" title="Cetak Data Ke EXCEL" class="btn btn-success"><i class="ace-icon fa fa-print bigger-110 "></i> Cetak Excel</a> &nbsp; &nbsp;
<a href="<?php echo base_url();?>cetak/pdf" title="Cetak Data Ke PDF" class="btn btn-info"><i class="ace-icon fa fa-print bigger-110"></i>Cetak Pdf</a>
</div>
</div>
<div class="center"></div>
