<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = $('#dynamic-table').dataTable( {

					"aoColumns": [ 
					  null, null, null, null, null,
					  { "bSortable": false }
					]
			    } );
						
			})
		</script>
	
		<div class="table-header">
			Cetak Data Kelas Siswa
			
			
		</div>
	
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nama Kelas</th>
			<th class="center">Wali Kelas</th>
			<th class="center">Siswa</th>
			<th class="center">Tahun Pelajaran</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		foreach ($data->result() as $row) {
	 			
	 			$id_kelas=$row->id_kelas;
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->kelas ;?></td>
			<td><?php echo $row->nama ;?></td>
			<td><?php $query= "SELECT COUNT(*) AS total_siswa FROM kelas_siswa WHERE id_kelas='$id_kelas'";
						$result = mysql_query($query);        
                    	while($row_dd = mysql_fetch_object($result))
                        { echo $row_dd->total_siswa.' siswa'; }
					?></td>
			<td><?php echo $row->tahun_pelajaran ;?></td>
	 		<td class="center">
	 			<a class="red" href="<?php echo base_url();?>cetak/datakelas/<?php echo $row->id_kelas; ?>"><i class="ace-icon fa fa-print bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?php }?>
	</tbody>
</table>