<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = $('#dynamic-table').dataTable( {

					"aoColumns": [ 
					  null, null, null, null, null,
					  { "bSortable": false }
					]
			    } );
						
			})
		</script>
	
		<div class="table-header">
			Data Nilai KKM
			<div class="pull-right">
			<a href="<?php echo base_url();?>nilai_kkm/tambah" class="btn btn-sm btn-primary" title="Tambah Data">Tambah Data</a>
		</div>
			
		</div>
<?php echo $this->session->flashdata('pesan');?>
<table id="dynamic-table" class="table table-striped table-bordered table-hover" >
	<thead>
		<tr>
			<th class="center">No</th>
			<th class="center">Nama Mata Pelajaran</th>
			<th class="center">Nilai KKM</th>
			<th class="center">Semester</th>
			<th class="center">Tahun Pelajaran</th>
			<th class="center">Aksi</th>
		</tr>
	</thead>
	<tbody>
	 	
	 		<?php
	 		$no=1;
	 		foreach ($data->result() as $row) {
	 			
	 		?>
	 	<tr>
	 		<td><?php echo $no++; ?></td>
	 		<td><?php echo $row->nama_mapel ;?></td>
			<td><?php echo $row->nilai_kkm ;?></td>
			<td><?php echo $row->semester ;?></td>
			<td><?php echo $row->tahun_pelajaran ;?></td>
	 		<td class="center">
	 			<a class="green" href="<?php echo base_url();?>nilai_kkm/edit/<?php echo $row->id_kkm; ?>" title="Edit Data"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
	 			<a class="red" href="<?php echo base_url();?>nilai_kkm/delete/<?php echo $row->id_kkm; ?>" title="Hapus Data" onclick="return confirm('anda yakin akan menghapus data ini??');"><i class="ace-icon fa fa-trash bigger-130"></i></a>
	 		</td>

	 	</tr>
	 	<?php }?>
	</tbody>
</table>