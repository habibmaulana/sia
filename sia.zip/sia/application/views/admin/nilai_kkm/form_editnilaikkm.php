<script type="text/javascript">

function cekform()
	{
		
		if(!$("#id_mapel").val())
		{
			alert('Nama Mata Pelajaran tidak boleh kosong');
			$('#id_mapel').focus()
			return false;
		}
		if(!$("#nilai_kkm").val())
		{
			alert('Nilai KKM tidak boleh kosong');
			$('#nilai_kkm').focus()
			return false;
		}
		if(!$("#semester").val())
		{
			alert('Semester tidak boleh kosong');
			$('#semester').focus()
			return false;
		}
		if(!$("#id_tahunpelajaran").val())
		{
			alert('Tahun Mata Pelajaran tidak boleh kosong');
			$('#id_tahunpelajaran').focus()
			return false;
		}
	};	
$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>nilai_kkm/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>nilai_kkm";
				}
			});
		});

		
	});
</script>

<?php
echo $this->session->flashdata('pesan');
?>

<form class="form-horizontal" method="POST" action="<?php echo site_url();?>nilai_kkm/simpan" >
	<input type="text" name="id_kkm" id="id_kkm" hidden value="<?php echo $id_kkm?>">
	<input type="text" name="id_tahunpelajaran" id="id_tahunpelajaran" hidden value="<?php echo $id_tahunpelajaran?>">
	<input type="text" name="id_mapel" id="id_mapel" hidden value="<?php echo $id_mapel?>">
	<input type="text" name="semester" id="semester" hidden value="<?php echo $semester?>">
	<div class="form-group">
		<label class="col-sm-2 control-label">Nama Mata Pelajaran</label>
		<div class="col-sm-4">
			<label class="control-label"><?PHP echo $nama_mapel; ?></label>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Nilai KKM</label>
		<div class="col-sm-2">
			<input type="text" name="nilai_kkm" id="nilai_kkm" placeholder="Masukkan Nilai KKM" class="col-sm-5" value="<?php echo $nilai_kkm?>" required>
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label">Semester</label>
		<div class="col-sm-1">
			<label class="control-label"><?php echo $semester; ?></label>
			
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<label class="control-label"><?php echo $tahun_pelajaran; ?></label>
		</div>	
	</div>
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="submit" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>nilai_kkm" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>