	<div class="footer">
				<div class="footer-inner">
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder">USM</span>
							Habib Maulana &copy; 2015
						</span>

						&nbsp; &nbsp;
						
					</div>
				</div>
			</div>