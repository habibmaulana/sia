<script type="text/javascript">
	$(document).ready(function(){

		$("#simpan").click(function(){
			var string = $("#my-form").serialize();
			$.ajax({
				type 	: 'POST',
				url 	: '<?php echo site_url();?>tahun_pelajaran/simpan',
				data 	: string,
				success : function(data){
					alert(data);
					window.location = "<?php echo site_url();?>tahun_pelajaran";
				}
			});
		});
});
	function cekform()
	{
		
		
		if(!$("#tahun").val())
		{
			alert('Tahun Pelajaran tidak boleh kosong');
			$('#tahun').focus()
			return false;
		}
	}
</script>

<?php
$info = $this->session->flashdata('info');
if(!empty($info))
{
	echo $info;
}
?>

<form class="form-horizontal" name="my-form" id="my-form" onsubmit="return cekform();">
	
	<input type="text" name="id_tahun" id="id_tahun" hidden value="<?php echo $id_tahun; ?>">

	<div class="form-group">
		<label class="col-sm-2 control-label">Tahun Pelajaran</label>
		<div class="col-sm-2">
			<input type="text" name="tahun" id="tahun" placeholder="Masukkan Tahun Pelajaran" value="<?php echo $tahun; ?>">
		</div>	
	</div>
	<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
	<button type="button" name="simpan" id="simpan" class="btn btn-info"><i class="ace-icon fa fa-check"></i>Simpan</button> &nbsp; &nbsp;
	<a href="<?php echo base_url();?>tahun_pelajaran" class="btn"><i class="ace-icon fa fa-undo bigger-110"></i>Tutup</a>
	</div>
	</div>
</form>