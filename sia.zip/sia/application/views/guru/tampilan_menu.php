<ul class="nav nav-list">
					<li class="">
						<a href="<?php echo base_url();?>home_guru">
							<i class="menu-icon fa fa-home"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					
					<li class="">
						<a href="<?php echo base_url();?>home_guru/guru" >
							<i class="menu-icon fa fa-pencil-square-o"></i>
							<span class="menu-text">
								Nilai Akhir
							</span>
							
						</a>
						<b class="arrow"></b>
					</li>
				
					<li class="">
						<a href="<?php echo base_url();?>home_guru/logout"  onclick="return confirm('Apakah anda akan keluar?');">
							<i class="menu-icon fa fa-power-off"></i>
							<span class="menu-text"> Keluar </span>
						</a>

						<b class="arrow"></b>

					</li>

				</ul><!-- /.nav-list -->