<script type="text/javascript">
	
	$(document).ready(function() {
		$("#id_tahunpelajaran").change(function() {
			$("#id_tahunpelajaran option:selected").each(function() {
			id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.post("<?php echo base_url(); ?>kelas_siswa/kelas", {
				id_tahunpelajaran : id_tahunpelajaran
			}, function(data){
			$("#id_kelas").html(data);
			
			});
		});
	});
});

	$(document).ready(function() {
		$("#id_tahunpelajaran").change(function() {
			var id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.ajax({
				url 	: '<?php echo base_url(); ?>nilai_akhir/semester',
				data 	: "id_tahunpelajaran=" + id_tahunpelajaran,
				success : function(html)
				       {
				          $("#semester").html(html);
				       }
			});

		});
	});



$(document).ready(function(){
		$("#semester").change(function(){
			var semester = $("#semester").val();
			var id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.ajax({
				url 	: '<?php echo site_url();?>/home_guru/mapel',
				data 	: "semester=" + semester + "&id_tahunpelajaran=" + id_tahunpelajaran,
				success : function(html)
				       {
				          $("#mapel").html(html);
				       }
			});
		});
});
	


		
</script>

<script type="text/javascript">
$(document).ready(function() {
		$("#id_kelas").change(function() {
		kelas();
		});
});
</script>

<script type="text/javascript">
function kelas()
{
		var id_kelas = $('#id_kelas').val();
			$.ajax({
				url 	: '<?php echo base_url(); ?>home_guru/loaddata',
				data 	: "id_kelas=" + id_kelas,
				success : function(html)
				       {
				       		$("#cek").hide();
				       		$("#daftarkrs").show();
				          	$("#daftarkrs").html(html);
				       }
			});
		
}

</script>

<script type="text/javascript">
$(document).ready(function(){
		$("#semester").change(function(){
		tampil();
		});
});
</script>

<script type="text/javascript">
function tampil()
{
		var semester = $("#semester").val();
		var id_tahunpelajaran = $('#id_tahunpelajaran').val();
		var id_kelas = $('#id_kelas').val();
			$.ajax({
				url 	: '<?php echo base_url(); ?>home_guru/coba',
				data 	: "id_kelas=" + id_kelas + "&semester=" + semester + "&id_tahunpelajaran=" + id_tahunpelajaran,
				success : function(html)
				       {	$("#cek").hide();
				       		$("#daftarkrs").show();
				          $("#lihat").html(html);
				       }
			});
		
}

</script>

<script type="text/javascript">
function ubah()
	{
			var nilai_harian1 	= $("#nilai_harian1").val();
		var nilai_harian2 	= $("#nilai_harian2").val();
		var nilai_harian3 	= $("#nilai_harian3").val();
		var nilai_harian4 	= $("#nilai_harian4").val();	
			var nilai_uts 	= $("#nilai_uts").val();
			var nilai_uas 	= $("#nilai_uas").val();
			$.ajax({
				url 	: '<?php echo base_url();?>nilai_akhir/angka',
				data 	: "nilai_harian1=" + nilai_harian1 + "&nilai_harian2=" + nilai_harian2 + "&nilai_harian3=" + nilai_harian3 + "&nilai_harian4=" + nilai_harian4 + "&nilai_uts=" + nilai_uts + "&nilai_uas=" + nilai_uas,
				success : function(html)
				       {	   
				          $("#angka").html(html);
				          
				       }
			});
	}
</script>

<script type="text/javascript">
function rata()
	{
		
			var nilai_harian1 	= $("#nilai_harian1").val();
			var nilai_harian2 	= $("#nilai_harian2").val();
			var nilai_harian3 	= $("#nilai_harian3").val();
			var nilai_harian4 	= $("#nilai_harian4").val();
			$.ajax({
				url 	: '<?php echo base_url();?>nilai_akhir/rata',
				data 	: "nilai_harian1=" + nilai_harian1 + "&nilai_harian2=" + nilai_harian2 + "&nilai_harian3=" + nilai_harian3 + "&nilai_harian4=" + nilai_harian4 ,
				success : function(html)
				       {	   
				          $("#nilai_rataharian").html(html);
				          
				       }
			});
	}
</script>

<script type="text/javascript">
function jumlah()
	{
		
		var nilai_harian1 	= $("#nilai_harian1").val();
		var nilai_harian2 	= $("#nilai_harian2").val();
		var nilai_harian3 	= $("#nilai_harian3").val();
		var nilai_harian4 	= $("#nilai_harian4").val();	
			var nilai_uts 	= $("#nilai_uts").val();
			var nilai_uas 	= $("#nilai_uas").val();
			
			$.ajax({
				url 	: '<?php echo base_url();?>nilai_akhir/jumlah',
				data 	: "nilai_harian1=" + nilai_harian1 + "&nilai_harian2=" + nilai_harian2 + "&nilai_harian3=" + nilai_harian3 + "&nilai_harian4=" + nilai_harian4 + "&nilai_uts=" + nilai_uts + "&nilai_uas=" + nilai_uas,
				success : function(html)
				       {	   
				          $("#nilai_akhir").html(html);
				          ubah();
				          
				       }
			});
	}
</script>

<script type="text/javascript">
	function simpan()
	{
			var id_nilaiakhir 	= $("#id_nilaiakhir").val();
	 		var id_kelassiswa 	= $("#id_kelassiswa").val();
			var nis 			= $("#nis").val();
			var id_kkm 			= $("#id_kkm").val();
			var nilai_harian1 	= $("#nilai_harian1").val();
			var nilai_harian2 	= $("#nilai_harian2").val();
			var nilai_harian3 	= $("#nilai_harian3").val();
			var nilai_harian4 	= $("#nilai_harian4").val();
			var nilai_rataharian = $("#nilai_rataharian").html();
			var nilai_uts 		= $("#nilai_uts").val();
			var nilai_uas 		= $("#nilai_uas").val();
			var nilai_akhir 	= $("#nilai_akhir").html();
			var angka 			= $("#angka").html();
			var catatan_guru 	= $("#catatan_guru").val();
			$.ajax({
				url 	: '<?php echo base_url();?>nilai_akhir/simpan',
				data 	: "id_nilaiakhir=" + id_nilaiakhir + "&id_kelassiswa=" + id_kelassiswa + "&nis=" + nis + "&nis=" + nis + "&id_kkm=" + id_kkm +  "&nilai_harian1=" + nilai_harian1 + "&nilai_harian2=" + nilai_harian2 + "&nilai_harian3=" + nilai_harian3 + "&nilai_harian4=" + nilai_harian4 + "&nilai_rataharian=" + nilai_rataharian
							+ "&nilai_uts=" + nilai_uts + "&nilai_uas=" + nilai_uas + "&nilai_akhir=" + nilai_akhir + "&angka=" + angka + "&catatan_guru=" + catatan_guru ,
				success : function(html)
				       {	
				            alert(html);
				            tampil();
				            $("#cek").hide();
				            //window.location = "<?php echo site_url();?>/nilai_akhir";
				       }
			});
	}
</script>



<script type="text/javascript">
function ambil(id_kelassiswa)
{
		var id_kkm = $("#id_kkm").val();
		var semester = $("#semester").val();
		var id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.ajax({
				url 	: '<?php echo site_url();?>/home_guru/cek',
				data 	: "id_kkm=" + id_kkm + "&id_kelassiswa=" + id_kelassiswa + "&semester=" + semester + "&id_tahunpelajaran=" + id_tahunpelajaran,
				success : function(html)
				       {	$("#daftarkrs").hide();
				       		$("#cek").show();
				            $("#cek").html(html);
				            
				       }
			});
}
</script>



<div class="col-sm-3">
	<label><strong>Data Kelas Siswa</strong></label>
    <table class="table table-bordered">
    <tr><td>Tahun Pelajaran <select class="form-control" type="text" name="id_tahunpelajaran" id="id_tahunpelajaran">
         <option value="0">--Pilih Tahun Pelajaran--</option>    
			<?php
				$tahun = $this->db->get('tahun_pelajaran');
				foreach ($tahun->result() as $i) {
           			 echo '<option value="'.$i->id_tahunpelajaran.'">'.$i->tahun_pelajaran.'</option>';
         } ?>
                                     
        </select></td></tr>
    <tr><td>Kelas <select class="form-control" type="text" name="id_kelas" id="id_kelas">
         <option value="0">--Pilih Kelas--</option>    
			                      
        </select></td></tr>
        <tr><td>Semester  <select  id="semester" name="semester" class="form-control">
    	<option value="0">--Pilih Semester--</option>   
                    </select> 

        	
        	</td></tr>

</table>
<div id="mapel" name="mapel"></div>

</div>


<div class="col-sm-9">
    <div id="daftarkrs" name="daftarkrs"></div>
    <div id="nilai" name="nilai"></div>
 <div id="cek" name="cek"><?php
echo $this->session->flashdata('pesan');?></div>

	
	

</div>
