<ul class="nav nav-list">
					<li class="">
						<a href="<?php echo base_url();?>home_siswa">
							<i class="menu-icon fa fa-home"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					
					<li class="">
						<a href="<?php echo base_url();?>home_siswa/siswa">
							<i class="menu-icon fa fa-eye"></i>
							<span class="menu-text">
								Nilai
							</span>
							
						</a>
						<b class="arrow"></b>
						
					</li>
					<li class="">
						<a href="<?php echo base_url();?>home_siswa/logout"  onclick="return confirm('Apakah anda akan keluar?');">
							<i class="menu-icon fa fa-power-off"></i>
							<span class="menu-text"> Keluar </span>
						</a>

						<b class="arrow"></b>

					</li>

				</ul><!-- /.nav-list -->