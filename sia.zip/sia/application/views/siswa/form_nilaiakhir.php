<script type="text/javascript">
	
	$(document).ready(function() {
		$("#id_kelas").change(function() {
			
			var id_kelas = $('#id_kelas').val();
			$.ajax({
				url 	: '<?php echo base_url(); ?>home_siswa/loaddata',
				data 	: "id_kelas=" + id_kelas,
				success : function(html)
				       {
				          $("#daftarkrs").html(html);
				       }
			});
		});
	});

	$(document).ready(function() {
		$("#id_kelas").change(function() {
			var id_tahunpelajaran = $('#id_tahunpelajaran').val();
			$.ajax({
				url 	: '<?php echo base_url(); ?>nilai_akhir/semester',
				data 	: "id_tahunpelajaran=" + id_tahunpelajaran,
				success : function(html)
				       {
				          $("#semester").html(html);
				       }
			});

		});
	});
	
</script>

<script>
$(document).ready(function(){
		$("#semester").change(function(){
      loadjurusan()
  });
});
</script>
<script type="text/javascript">

function loadjurusan()
{
   	var semester = $("#semester").val();
	var id_tahunpelajaran = $('#id_tahunpelajaran').val();
	var nis = $("#nis").val();
	var id_kelas = $("#id_kelas").val();
		$.ajax({
				url 	: '<?php echo site_url();?>/home_siswa/loadnilai',
				data 	: "semester=" + semester + "&id_tahunpelajaran=" + id_tahunpelajaran + "&nis=" + nis + "&id_kelas=" + id_kelas,
				success : function(html)
				       {
				       		$("#cek").hide();
				          $("#nilai").html(html);
				          $("#nilai").show();

				       }
			});
}
</script>

<script type="text/javascript">
function input(id_nilaiakhir)
{
			$.ajax({
				url 	: '<?php echo site_url();?>/home_siswa/cek',
				data 	: "id_nilaiakhir=" + id_nilaiakhir ,
				success : function(html)
				       {	$("#nilai").hide();
				            $("#cek").html(html);
				            $("#cek").show();
				       }
			});
		
}
</script>



<div class="col-sm-3">
	<label><strong>Data Kelas</strong></label>
    <table class="table table-bordered">
    <tr><td>Kelas <select class="form-control" type="text" name="id_kelas" id="id_kelas">
         <option value="0">--Pilih Kelas--</option>    
			 <?php
			 	$nis = $this->session->userdata('nis');

				$tahun = $this->db->query("SELECT
											kelas_siswa.*,
											kelas.kelas
										FROM
											kelas_siswa,
											kelas
										WHERE
										kelas_siswa.id_kelas = kelas.id_kelas AND
										kelas_siswa.nis = $nis
										");
				foreach ($tahun->result() as $i) {
           			 echo '<option value="'.$i->id_kelas.'">'.$i->kelas.'</option>';
         } ?>
                                     
        </select></td></tr>
        
        <tr><td>Semester  <select  id="semester" name="semester" class="form-control">
    	<option value="0">--Pilih Semester--</option>   
                    </select> 

        	
        	</td></tr>

</table>
<div id="mapel" name="mapel"></div>

</div>


<div class="col-sm-9">
    <div id="daftarkrs" name="daftarkrs"></div>
    <div id="nilai" name="nilai"></div>
 <div id="cek" name="cek"><?php
echo $this->session->flashdata('pesan');?></div>

	
	

</div>
