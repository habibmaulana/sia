<?php echo $this->session->flashdata('pesan'); ?>
<form class="form-horizontal"  >
	<div class="tabbable">
		<ul class="nav nav-tabs padding-16">
			<li class="active">
				<a data-toggle="tab" href="#edit-basic">
				<i class="green ace-icon fa fa-pencil-square-o bigger-125"></i>
				Data Pengguna
 				</a>
			</li>
			<li>
				<a data-toggle="tab" href="#edit-password">
				<i class="blue ace-icon fa fa-key bigger-125"></i>
				Username dan Password
				</a>
			</li>
			<li>
				<a data-toggle="tab" href="#edit-foto">
				<i class="black ace-icon fa fa-user bigger-125"></i>
				Ganti Foto
				</a>
			</li>    
		</ul>
</form>
	<form class="form-horizontal" method="POST" action="<?php echo site_url();?>/home_siswa/simpan" >
		<div class="tab-content profile-edit-tab-content">								
		<div id="edit-basic" name="edit-basic" class="tab-pane in active">		
			<h4 class="header blue"><strong>Data Siswa</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa</label>
		<div class="col-sm-2">
			<input type="text" hidden id="nis" name="nis" value="<?php echo $nis;?>">
			<label class="control-label"><?php echo $nis; ?></label>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nomor Induk Siswa Nasional</label>
		<div class="col-sm-2">
			<input type="text" name="nisn" id="nisn" placeholder="Masukkan NISN" value="<?php echo $nisn; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama</label>
		<div class="col-sm-2">
			<input type="text" name="nama" id="nama" placeholder="Masukkan Nama" value="<?php echo $nama; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tempat Lahir</label>
		<div class="col-sm-2">
			<input type="text" name="tempat" id="tempat" placeholder="Masukkan tempat" value="<?php echo $tempat; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Tanggal Lahir</label>
		<div class="col-sm-2">
			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-calendar bigger-110"></i>
				</span>
				<input class="form-control" type="date" name="tgl" id="tgl" placeholder="Masukkan Tanggal Lahir" value="<?php echo $tgl; ?>">
			</div>	
		</div>	
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="jenis" id="jenis" value="<?php echo $jenis; ?>">
			<option value="">Jenis Kelamin</option>
			<option value="1">Laki-Laki</option>
			<option value="2">Perempuan</option>
			</select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Agama</label>
		<div class="col-sm-2">
			<select class="form-control" type="text" name="agama" id="agama" value="<?php echo $agama; ?>">
			<option value="">Agama</option>
			<option value="Buhda">Buhda</option>
			<option value="Hindu">Hindu</option>
			<option value="Islam">Islam</option>
			<option value="Kristen">Kristen</option>
			<option value="Katolik">Katolik</option>
			</select>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Status Dalam Keluarga</label>
		<div class="col-sm-2">
			<input type="text" name="status" id="status" placeholder="Masukkan Status Dalam Keluarga" value="<?php echo $status; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Anak Ke-</label>
		<div class="col-sm-2">
			<input type="text" name="anak" id="anak" placeholder="Masukkan Anak Ke" value="<?php echo $anak; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-6">
			<textarea name="alamat" id="alamat" placeholder="Masukkan Alamat" class="col-xs-10 col-sm-5" value="<?php echo $alamat; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no" id="no" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Sekolah Asal</label>
		<div class="col-sm-2">
			<input type="text" name="sekolah" id="sekolah" placeholder="Masukkan Sekolah Asal" value="<?php echo $sekolah; ?>">
		</div>	
	</div>
	<input type="text" hidden id="id_tahunpelajaran" name="id_tahunpelajaran" value="<?php echo $id_tahunpelajaran?>">
	<input type="text" hidden id="kelas" name="kelas" value="<?php echo $kelas?>">
	
				<input hidden type="text" name="pada" id="pada" placeholder="Masukkan Pada Tanggal" value="<?php echo $pada; ?>">
	
	<hr>
	<h4 class="header blue"><strong>Data Orang Tua</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ayah</label>
		<div class="col-sm-2">
			<input type="text" name="ayah" id="ayah" placeholder="Masukkan Nama Ayah" value="<?php echo $ayah; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Ibu</label>
		<div class="col-sm-2">
			<input type="text" name="ibu" id="ibu" placeholder="Masukkan Nama Ibu" value="<?php echo $ibu; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Orang Tua</label>
		<div class="col-sm-6">
			<textarea name="alamat_ortu" id="alamat_ortu" placeholder="Masukkan Alamat Orang Tua" class="col-xs-10 col-sm-5" value="<?php echo $alamat_ortu; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no_ortu" id="no_ortu" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no_ortu; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ayah</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_ayah" id="pekerjaan_ayah" placeholder="Masukkan Pekerjaan Ayah" value="<?php echo $pekerjaan_ayah; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Ibu</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_ibu" id="pekerjaan_ibu" placeholder="Masukkan Pekerjaan Ibu" value="<?php echo $pekerjaan_ibu; ?>">
		</div>	
	</div>
	<hr>
	<h4 class="header blue"><strong>Data Wali</strong></h4>
	<div class="form-group">
		<label class="col-sm-3 control-label">Nama Wali</label>
		<div class="col-sm-2">
			<input type="text" name="wali" id="wali" placeholder="Masukkan Nama Wali" value="<?php echo $wali; ?>">
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Alamat Wali</label>
		<div class="col-sm-6">
			<textarea name="alamat_wali" id="alamat_wali" placeholder="Masukkan Alamat Wali" class="col-xs-10 col-sm-5" value="<?php echo $alamat_wali; ?>"></textarea>
		</div>	
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">No Telepon/HP</label>
		<div class="col-xs-8 col-sm-4">
			<div class="input-group">
				<span class="input-group-addon"><i class="ace-icon fa fa-phone"></i>
				</span>
				<input type="text" name="no_wali" id="no_wali" placeholder="Masukkan No Telepon/HP" class="col-xs-10 col-sm-5" value="<?php echo $no_wali; ?>">
			</div>	
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label">Pekerjaan Wali</label>
		<div class="col-sm-2">
			<input type="text" name="pekerjaan_wali" id="pekerjaan_wali" placeholder="Masukkan Pekerjaan Wali" value="<?php echo $pekerjaan_wali; ?>">
		</div>	
	</div>
	
	<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9">
						<button class="btn btn-info" type="submit">
						<i class="ace-icon fa fa-check bigger-110"></i>
							Simpan
						</button> &nbsp; &nbsp;
						<a href="<?php echo base_url();?>home_siswa" class="btn">
						<i class="ace-icon fa fa-undo bigger-110"></i>
							Tutup
						</a>
					</div>
				</div>		
		</div>	
		</form>		
		<div id="edit-password" class="tab-pane">
			<form class="form-horizontal" method="post" action="<?php echo site_url();?>/home_siswa/password">
			<div class="space-10"></div>
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right" for="form-field-pass1">Username Baru</label>	
					<div class="col-sm-9">
						<input type="text" id="user" name="user" placeholder="Masukkan Username" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right" for="form-field-pass1">Password Lama</label>
					<div class="col-sm-9">
						<input type="password" id="pass_lama" name="pass_lama" placeholder="Password Lama" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right" for="form-field-pass1">Password Baru</label>
					<div class="col-sm-9">
						<input type="password" id="pass_baru" name="pass_baru" placeholder="Password Baru" required>
					</div>
				</div>
			
				<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9">
						<button class="btn btn-info" type="submit">
						<i class="ace-icon fa fa-check bigger-110"></i>
							Simpan
						</button> &nbsp; &nbsp;
						<a href="<?php echo base_url();?>home_siswa" class="btn">
						<i class="ace-icon fa fa-undo bigger-110"></i>
							Tutup
						</a>
					</div>
				</div>												
			</form>
		</div>

		<div id="edit-foto" class="tab-pane">
			<form class="form-horizontal" method="post" action="<?php echo base_url();?>home_siswa/foto" enctype="multipart/form-data">
			<div class="space-10"></div>
			<div class="form-group">						
				<div class="center">
				<div class="col-sm-9">
			<span class="profile-picture">
			<img class="editable img-responsive" height="200" width="200" src="<?php echo base_url();?>assets/avatars/<?=$this->session->userdata('foto')?>" />
			</span>
		</div>
		</div>
		</div>
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right" >Foto</label>
					<div class="col-sm-9">
						<input type="file" class="col-xs-10 col-sm-5" name="foto" id="foto">
					</div>
					<div class="col-sm-9">
					<LABEL class="col-xs-10 col-sm-5">*) Maksimal foto yang di upload 200kb</LABEL></div>
					<input type="text" hidden class="col-xs-10 col-sm-5" name="id_pengguna" id="id_pengguna" value="<?php echo $this->session->userdata('id_pengguna')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="username" id="username" value="<?php echo $this->session->userdata('username')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="Password" id="Password" value="<?php echo $this->session->userdata('Password')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="nama" id="nama" value="<?php echo $this->session->userdata('nama')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="nis" id="nis" value="<?php echo $this->session->userdata('nis')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="nip" id="nip" value="<?php echo $this->session->userdata('nip')?>">
					<input type="text" hidden class="col-xs-10 col-sm-5" name="id_jabatan" id="id_jabatan" value="<?php echo $this->session->userdata('id_jabatan')?>">
				</div>
			
				<div class="clearfix form-actions">
					<div class="col-md-offset-3 col-md-9">
						<button class="btn btn-info" type="submit">
						<i class="ace-icon fa fa-check bigger-110"></i>
							Simpan
						</button> &nbsp; &nbsp;
						<a href="<?php echo base_url();?>home_siswa" class="btn">
						<i class="ace-icon fa fa-undo bigger-110"></i>
							Tutup
						</a>
					</div>
				</div>												
			</form>
		</div>

	</div>
	</div> 
</form>